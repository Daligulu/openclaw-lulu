#!/bin/bash
# 测试时区设置

echo "🕐 时区设置测试"
echo ""

# 1. 当前系统时间
echo "1. 系统时间设置："
echo "   当前时区: $(date +%Z)"
echo "   当前时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "   UTC时间: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo ""

# 2. 备份脚本时间格式
echo "2. 备份脚本时间格式："
export TZ='Asia/Shanghai'
echo "   中国时区时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 3. 定时任务时间对应
echo "3. 定时任务时间对应表："
echo "   ┌─────────────┬─────────────┐"
echo "   │ 北京时间   │ UTC时间     │"
echo "   ├─────────────┼─────────────┤"
echo "   │ 07:00       │ 23:00 (前日)│"
echo "   │ 12:00       │ 04:00       │"
echo "   │ 17:00       │ 09:00       │"
echo "   │ 20:00       │ 12:00       │"
echo "   └─────────────┴─────────────┘"
echo ""

# 4. 下次备份时间
echo "4. 下次备份时间："
NEXT_UTC_TIMES=("23:00" "04:00" "09:00" "12:00")
CURRENT_UTC=$(date -u '+%H:%M')

for time in "${NEXT_UTC_TIMES[@]}"; do
    if [[ "$time" > "$CURRENT_UTC" ]]; then
        echo "   下次备份: UTC $time (北京时间 $(date -d "$time UTC" '+%H:%M'))"
        break
    fi
done
echo ""

# 5. 检查crontab配置
echo "5. Crontab配置："
crontab -l | grep backup-openclaw
echo ""

echo "✅ 时区设置测试完成"
echo "所有时间现在使用中国上海时区 (GMT+8)"