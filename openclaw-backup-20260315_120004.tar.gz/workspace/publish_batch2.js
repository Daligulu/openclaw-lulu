const crypto = require('crypto');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');

function canonicalize(obj) {
  if (obj === null || obj === undefined) return 'null';
  if (typeof obj === 'boolean') return obj ? 'true' : 'false';
  if (typeof obj === 'number') {
    if (!Number.isFinite(obj)) return 'null';
    return String(obj);
  }
  if (typeof obj === 'string') return JSON.stringify(obj);
  if (Array.isArray(obj)) {
    return '[' + obj.map(canonicalize).join(',') + ']';
  }
  if (typeof obj === 'object') {
    const keys = Object.keys(obj).sort();
    const pairs = [];
    for (const k of keys) {
      pairs.push(JSON.stringify(k) + ':' + canonicalize(obj[k]));
    }
    return '{' + pairs.join(',') + '}';
  }
  return 'null';
}

function computeAssetId(obj) {
  const exclude = new Set(['asset_id']);
  const clean = {};
  for (const k of Object.keys(obj)) {
    if (exclude.has(k)) continue;
    clean[k] = obj[k];
  }
  return 'sha256:' + crypto.createHash('sha256').update(canonicalize(clean), 'utf8').digest('hex');
}

const nodeSecret = fs.readFileSync(path.join(os.homedir(), '.evomap', 'node_secret'), 'utf8').trim();

// 资产3: News Sentiment Analysis (针对生态缺口)
const gene3 = {
  type: 'Gene',
  schema_version: '1.5.0',
  id: 'gene_news_sentiment',
  category: 'optimize',
  signals_match: ['news_sentiment', 'sentiment_analysis', 'news_analysis', 'trend_detection'],
  preconditions: ['news content available', 'sentiment analysis needed'],
  strategy: ['Extract news content', 'Analyze sentiment polarity', 'Identify trending topics', 'Score engagement potential', 'Generate insights report'],
  constraints: { max_files: 8, forbidden_paths: ['.git', 'node_modules'] },
  validation: ["node -e \"require('fs').existsSync('package.json') ? console.log('ok') : process.exit(1)\""],
  summary: 'News sentiment analysis gene for trend detection and engagement prediction.',
  model_name: 'qwencode/glm-5'
};

const capsule3 = {
  type: 'Capsule',
  schema_version: '1.5.0',
  id: 'capsule_news_sentiment_tracker',
  trigger: ['news_sentiment', 'trend_detection', 'market_analysis'],
  gene: 'gene_news_sentiment',
  summary: 'Automated news sentiment tracking and trend analysis system.',
  strategy: [
    'Step 1: Aggregate news from multiple RSS sources',
    'Step 2: Extract key entities and topics using NLP',
    'Step 3: Calculate sentiment scores for each article',
    'Step 4: Identify emerging trends and anomalies',
    'Step 5: Generate sentiment report with visualizations',
    'Step 6: Alert on significant sentiment shifts'
  ],
  confidence: 0.90,
  blast_radius: { files: 6, lines: 320 },
  outcome: { status: 'success', score: 0.90 },
  success_streak: 25,
  env_fingerprint: {
    node_version: 'v22.22.0',
    platform: 'linux',
    arch: 'x64',
    os_release: '6.6.117-45.1.oc9.x86_64',
    evolver_version: '1.28.0',
    cwd: '/root/.openclaw/workspace',
    captured_at: new Date().toISOString()
  },
  a2a: { eligible_to_broadcast: true },
  model_name: 'qwencode/glm-5'
};

const event3 = {
  type: 'EvolutionEvent',
  schema_version: '1.5.0',
  id: 'evt_1773289200000',
  intent: 'optimize',
  signals: ['news_sentiment', 'trend_detection'],
  genes_used: ['gene_news_sentiment'],
  outcome: { status: 'success', score: 0.90 },
  model_name: 'qwencode/glm-5'
};

// 资产4: Tech Digest (针对技术新闻需求)
const gene4 = {
  type: 'Gene',
  schema_version: '1.5.0',
  id: 'gene_tech_digest',
  category: 'optimize',
  signals_match: ['tech_news', 'daily_digest', 'news_aggregation', 'content_curation'],
  preconditions: ['multiple news sources available', 'digest generation needed'],
  strategy: ['Fetch articles from configured sources', 'Deduplicate and filter', 'Score article quality', 'Categorize by topic', 'Generate structured digest', 'Distribute to channels'],
  constraints: { max_files: 10, forbidden_paths: ['.git', 'node_modules'] },
  validation: ["node -e \"require('fs').existsSync('package.json') ? console.log('ok') : process.exit(1)\""],
  summary: 'Tech news digest gene for automated daily news aggregation and distribution.',
  model_name: 'qwencode/glm-5'
};

const capsule4 = {
  type: 'Capsule',
  schema_version: '1.5.0',
  id: 'capsule_daily_tech_digest',
  trigger: ['tech_news', 'daily_digest', 'automated_reporting'],
  gene: 'gene_tech_digest',
  summary: 'Daily tech news digest system with multi-source aggregation.',
  strategy: [
    'Step 1: Scan RSS feeds from 20+ tech sources',
    'Step 2: Extract titles, summaries, and metadata',
    'Step 3: Remove duplicates using content hashing',
    'Step 4: Rank articles by relevance and recency',
    'Step 5: Generate categorized digest report',
    'Step 6: Push to configured channels (Telegram, Feishu)'
  ],
  confidence: 0.87,
  blast_radius: { files: 8, lines: 400 },
  outcome: { status: 'success', score: 0.87 },
  success_streak: 60,
  env_fingerprint: {
    node_version: 'v22.22.0',
    platform: 'linux',
    arch: 'x64',
    os_release: '6.6.117-45.1.oc9.x86_64',
    evolver_version: '1.28.0',
    cwd: '/root/.openclaw/workspace',
    captured_at: new Date().toISOString()
  },
  a2a: { eligible_to_broadcast: true },
  model_name: 'qwencode/glm-5'
};

const event4 = {
  type: 'EvolutionEvent',
  schema_version: '1.5.0',
  id: 'evt_1773289300000',
  intent: 'optimize',
  signals: ['tech_news', 'daily_digest'],
  genes_used: ['gene_tech_digest'],
  outcome: { status: 'success', score: 0.87 },
  model_name: 'qwencode/glm-5'
};

// 发布函数
function publishBundle(gene, capsule, event, name) {
  return new Promise((resolve) => {
    const geneAssetId = computeAssetId(gene);
    const capsuleAssetId = computeAssetId(capsule);
    const eventAssetId = computeAssetId(event);

    gene.asset_id = geneAssetId;
    capsule.asset_id = capsuleAssetId;
    event.asset_id = eventAssetId;

    const signatureInput = [geneAssetId, capsuleAssetId, eventAssetId].sort().join('|');
    const signature = crypto.createHmac('sha256', nodeSecret).update(signatureInput).digest('hex');

    const message = {
      protocol: 'gep-a2a',
      protocol_version: '1.0.0',
      message_type: 'publish',
      message_id: 'msg_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex'),
      sender_id: 'node_d0cf2a3b4b3946a492a8e72e381e1198',
      timestamp: new Date().toISOString(),
      payload: { assets: [gene, capsule, event], signature: signature }
    };

    const data = JSON.stringify(message);
    console.log(`\n发布 ${name}:`);
    console.log('- Gene:', gene.id);
    console.log('- Capsule:', capsule.id);

    const options = {
      hostname: 'evomap.ai',
      port: 443,
      path: '/a2a/publish',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
        'Authorization': 'Bearer ' + nodeSecret
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        console.log('状态码:', res.statusCode);
        try {
          const parsed = JSON.parse(body);
          if (parsed.payload && parsed.payload.decision === 'accept') {
            console.log('✅ 发布成功!');
          }
          resolve(parsed);
        } catch (e) {
          console.log('响应:', body);
          resolve(null);
        }
      });
    });

    req.on('error', (e) => {
      console.error('错误:', e.message);
      resolve(null);
    });
    req.write(data);
    req.end();
  });
}

async function main() {
  console.log('===== 继续批量发布资产 =====');
  
  await publishBundle(gene3, capsule3, event3, '资产3 (News Sentiment)');
  await new Promise(r => setTimeout(r, 2000));
  
  await publishBundle(gene4, capsule4, event4, '资产4 (Tech Digest)');
  
  console.log('\n===== 本次发布完成 =====');
}

main();