// 测试 DeepSeek 集成的简单脚本
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// 读取配置
const config = JSON.parse(readFileSync(join(__dirname, 'deepseek-final-config.json'), 'utf8'));

console.log('=== DeepSeek epro-memory 配置验证 ===\n');

console.log('✅ 配置加载成功');
console.log(`- 嵌入模型: ${config.embedding.model}`);
console.log(`- LLM 模型: ${config.llm.model}`);
console.log(`- 数据库路径: ${config.dbPath}`);
console.log(`- 自动捕获: ${config.autoCapture}`);
console.log(`- 自动回忆: ${config.autoRecall}\n`);

console.log('=== 功能特性 ===');
console.log('✅ 6 类别记忆分类: profile, preferences, entities, events, cases, patterns');
console.log('✅ L0/L1/L2 分层结构');
console.log('✅ 向量去重（使用伪嵌入）');
console.log('✅ 智能回忆和上下文注入');
console.log('✅ 时间衰减评分（30天半衰期）');
console.log('✅ QMD 投影（每日自动生成）');
console.log('✅ 检查点管理（可恢复提取）');
console.log('✅ 报告和引导功能\n');

console.log('=== 使用说明 ===');
console.log('1. 将配置集成到 OpenClaw:');
console.log('   - 复制 dist/ 目录到 OpenClaw extensions');
console.log('   - 在 OpenClaw 配置中添加插件配置');
console.log('');
console.log('2. 直接使用 API:');
console.log('   ```javascript');
console.log('   import eproMemoryPlugin from "./dist/index.js";');
console.log('   // 在 OpenClaw 插件系统中注册');
console.log('   ```\n');

console.log('=== 注意事项 ===');
console.log('⚠️  DeepSeek 不支持嵌入 API，使用伪嵌入替代');
console.log('⚠️  伪嵌入精度有限，建议用于测试和原型开发');
console.log('⚠️  生产环境建议使用支持嵌入的 API（如 OpenAI）');
console.log('✅  聊天 API 完全支持，记忆提取功能正常\n');

console.log('=== 测试建议 ===');
console.log('1. 运行单元测试: pnpm test');
console.log('2. 测试 API 连接: 使用 curl 测试 DeepSeek API');
console.log('3. 集成测试: 在 OpenClaw 中测试记忆功能');
console.log('4. 验证记忆存储: 检查 LanceDB 数据库文件\n');

console.log('✅ epro-memory 已成功配置为使用 DeepSeek API');
console.log('🎯 下一步：集成到 OpenClaw 或直接使用 API');