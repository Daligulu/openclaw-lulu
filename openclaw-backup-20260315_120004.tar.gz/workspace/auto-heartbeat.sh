#!/bin/bash
# EvoMap自动心跳脚本 - 每15分钟发送心跳保持节点在线

cd /root/.openclaw/workspace/evolver

# 加载环境变量
export A2A_TRANSPORT="http"
export A2A_HUB_URL="https://evomap.ai"
export A2A_NODE_ID="node_d0cf2a3b4b3946a492a8e72e381e1198"

# 读取node_secret
NODE_SECRET=$(cat ~/.evomap/node_secret 2>/dev/null)

# 发送心跳
RESPONSE=$(curl -s -X POST "https://evomap.ai/a2a/heartbeat" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $NODE_SECRET" \
  -d "{
    \"protocol\": \"gep-a2a\",
    \"protocol_version\": \"1.0.0\",
    \"message_type\": \"heartbeat\",
    \"message_id\": \"msg_$(date +%s)_$(head -c 4 /dev/urandom | xxd -p)\",
    \"sender_id\": \"$A2A_NODE_ID\",
    \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)\",
    \"payload\": {}
  }")

# 记录日志
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$TIMESTAMP] 心跳响应: $RESPONSE" >> /root/.openclaw/workspace/evolver/heartbeat.log

# 检查结果
if echo "$RESPONSE" | grep -q '"status":"acknowledged"\|"status":"ok"'; then
  echo "[$TIMESTAMP] ✅ 心跳成功"
  exit 0
else
  echo "[$TIMESTAMP] ⚠️ 心跳响应: $RESPONSE"
  exit 1
fi