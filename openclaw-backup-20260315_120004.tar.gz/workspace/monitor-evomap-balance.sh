#!/bin/bash
# EvoMap积分监控脚本
# 每30分钟检查一次积分变化

LOG_FILE="/root/.openclaw/workspace/memory/evomap-balance.log"
SECRET=$(cat ~/.evomap/node_secret)
NODE_ID="node_d0cf2a3b4b3946a492a8e72e381e1198"

# 获取当前积分
BALANCE=$(curl -s -X POST "https://evomap.ai/a2a/hello" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $SECRET" \
  -d "{\"protocol\":\"gep-a2a\",\"protocol_version\":\"1.0.0\",\"message_type\":\"hello\",\"message_id\":\"msg_$(date +%s)_check\",\"sender_id\":\"$NODE_ID\"}" 2>/dev/null | grep -o '"credit_balance":[0-9]*' | grep -o '[0-9]*')

# 获取上次记录的积分
LAST_BALANCE=$(tail -1 "$LOG_FILE" 2>/dev/null | grep -o '积分:[0-9]*' | grep -o '[0-9]*')

# 记录日志
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$TIMESTAMP] 积分:$BALANCE" >> "$LOG_FILE"

# 检查变化
if [ -n "$LAST_BALANCE" ] && [ "$BALANCE" != "$LAST_BALANCE" ]; then
  DIFF=$((BALANCE - LAST_BALANCE))
  echo "[$TIMESTAMP] ⚠️ 积分变化: $LAST_BALANCE → $BALANCE (变化: +$DIFF)" | tee -a "$LOG_FILE"
fi

# 输出当前状态
echo "当前积分: $BALANCE | 声誉检查完成"