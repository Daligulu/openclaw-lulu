#!/bin/bash
# Simple Todo Management CLI
# Usage: todo.sh entry <command> [args]

set -euo pipefail

DB_PATH="${TODO_DB:-$HOME/.openclaw/workspace/todo.db}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Initialize database if not exists
init_db() {
    if [ ! -f "$DB_PATH" ]; then
        sqlite3 "$DB_PATH" << 'EOF'
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    priority INTEGER DEFAULT 5,
    "group" TEXT DEFAULT 'default',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
EOF
        echo "✅ Database initialized: $DB_PATH"
    fi
}

# Create a new task
create_task() {
    local description="$1"
    local group="${2:-default}"
    local priority="${3:-5}"
    
    init_db
    
    local id=$(sqlite3 "$DB_PATH" "INSERT INTO tasks (description, \"group\", priority) VALUES ('$description', '$group', $priority); SELECT last_insert_rowid();")
    echo "✅ Task #$id created: $description [group: $group, priority: $priority]"
}

# List all tasks
list_tasks() {
    init_db
    
    echo "📋 Task List:"
    echo "─────────────────────────────────────────────────────────────"
    sqlite3 "$DB_PATH" -header -column << 'EOF'
SELECT id, status, priority, "group", description 
FROM tasks 
WHERE status != 'done' AND status != 'skipped'
ORDER BY priority DESC, created_at ASC;
EOF
}

# Update task status
update_status() {
    local id="$1"
    local status="$2"
    
    init_db
    
    sqlite3 "$DB_PATH" "UPDATE tasks SET status = '$status', updated_at = CURRENT_TIMESTAMP WHERE id = $id;"
    echo "✅ Task #$id status updated to: $status"
}

# Delete a task
delete_task() {
    local id="$1"
    
    sqlite3 "$DB_PATH" "DELETE FROM tasks WHERE id = $id;"
    echo "✅ Task #$id deleted"
}

# Main command dispatcher
case "${1:-}" in
    init)
        init_db
        ;;
    entry)
        case "${2:-}" in
            create)
                description="${3:-}"
                shift 3
                
                # Parse named arguments
                while [ $# -gt 0 ]; do
                    case "$1" in
                        --group=*)
                            group="${1#--group=}"
                            shift
                            ;;
                        --priority=*)
                            priority="${1#--priority=}"
                            shift
                            ;;
                        --group)
                            group="$2"
                            shift 2
                            ;;
                        --priority)
                            priority="$2"
                            shift 2
                            ;;
                        *)
                            shift
                            ;;
                    esac
                done
                
                group="${group:-default}"
                priority="${priority:-5}"
                
                if [ -z "$description" ]; then
                    echo "❌ Error: Task description required"
                    echo "Usage: todo.sh entry create \"Task description\" [--group=NAME] [--priority=N]"
                    exit 1
                fi
                
                create_task "$description" "$group" "$priority"
                ;;
            list)
                list_tasks
                ;;
            status)
                id="${3:-}"
                status="${4#--status=}"
                
                if [ -z "$id" ] || [ -z "$status" ]; then
                    echo "❌ Error: ID and status required"
                    echo "Usage: todo.sh entry status <ID> --status=pending|in_progress|done|skipped"
                    exit 1
                fi
                
                update_status "$id" "$status"
                ;;
            delete)
                id="${3:-}"
                
                if [ -z "$id" ]; then
                    echo "❌ Error: Task ID required"
                    echo "Usage: todo.sh entry delete <ID>"
                    exit 1
                fi
                
                delete_task "$id"
                ;;
            *)
                echo "Usage: todo.sh entry <create|list|status|delete> [args]"
                exit 1
                ;;
        esac
        ;;
    *)
        echo "Usage: todo.sh <init|entry> [args]"
        echo ""
        echo "Commands:"
        echo "  init                    Initialize todo database"
        echo "  entry create DESC       Create a new task"
        echo "  entry list              List all active tasks"
        echo "  entry status ID STATUS  Update task status"
        echo "  entry delete ID         Delete a task"
        exit 1
        ;;
esac