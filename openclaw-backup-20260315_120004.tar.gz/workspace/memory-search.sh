#!/bin/bash
# 记忆搜索工具
# 支持按类别、标签、关键词搜索记忆

set -e

MEMORY_DIR="/root/.openclaw/workspace/memory"
CATEGORIES=("profile" "preferences" "entities" "events" "cases" "patterns")

# 颜色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

show_help() {
    echo -e "${GREEN}记忆搜索工具${NC}"
    echo "用法: $0 [选项] [搜索词]"
    echo ""
    echo "选项:"
    echo "  -c, --category CATEGORY  按类别搜索 (${CATEGORIES[*]})"
    echo "  -t, --tag TAG            按标签搜索"
    echo "  -k, --keyword KEYWORD    按关键词搜索"
    echo "  -l, --list-categories    列出所有类别"
    echo "  -r, --recent NUM         显示最近N个记忆"
    echo "  -s, --summary            显示统计摘要"
    echo "  -h, --help               显示帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 -c events -k \"决策\""
    echo "  $0 -t \"#重要\""
    echo "  $0 --recent 10"
    echo "  $0 --summary"
}

# 按类别搜索
search_by_category() {
    local category="$1"
    local keyword="$2"
    
    echo -e "${BLUE}在类别 '$category' 中搜索:${NC} $keyword"
    echo "========================================"
    
    if [ ! -d "$MEMORY_DIR/categories/$category" ]; then
        echo "类别 '$category' 不存在"
        return
    fi
    
    if [ -z "$keyword" ]; then
        # 显示该类别所有记忆
        find "$MEMORY_DIR/categories/$category" -name "*.md" -exec basename {} \; | sort
    else
        # 搜索关键词
        grep -l -i "$keyword" "$MEMORY_DIR/categories/$category"/*.md 2>/dev/null | \
            xargs -I {} basename {} | sort
    fi
    
    echo ""
}

# 按标签搜索
search_by_tag() {
    local tag="$1"
    
    echo -e "${PURPLE}搜索标签:${NC} $tag"
    echo "========================================"
    
    for category in "${CATEGORIES[@]}"; do
        if [ -d "$MEMORY_DIR/categories/$category" ]; then
            files=$(grep -l "$tag" "$MEMORY_DIR/categories/$category"/*.md 2>/dev/null)
            if [ -n "$files" ]; then
                echo -e "${YELLOW}类别: $category${NC}"
                echo "$files" | xargs -I {} basename {}
                echo ""
            fi
        fi
    done
}

# 按关键词搜索（跨类别）
search_by_keyword() {
    local keyword="$1"
    
    echo -e "${GREEN}全局搜索:${NC} $keyword"
    echo "========================================"
    
    for category in "${CATEGORIES[@]}"; do
        if [ -d "$MEMORY_DIR/categories/$category" ]; then
            count=$(grep -l -i "$keyword" "$MEMORY_DIR/categories/$category"/*.md 2>/dev/null | wc -l)
            if [ "$count" -gt 0 ]; then
                echo -e "${YELLOW}类别: $category ($count 个结果)${NC}"
                grep -l -i "$keyword" "$MEMORY_DIR/categories/$category"/*.md 2>/dev/null | \
                    xargs -I {} basename {}
                echo ""
            fi
        fi
    done
}

# 显示最近记忆
show_recent() {
    local num=${1:-10}
    
    echo -e "${BLUE}最近 $num 个记忆:${NC}"
    echo "========================================"
    
    # 查找所有记忆文件，按修改时间排序
    find "$MEMORY_DIR/categories" -name "*.md" -type f -exec ls -lt {} + 2>/dev/null | \
        head -$num | awk '{print $6" "$7" "$8" "$9}' | while read line; do
        date_part=$(echo "$line" | awk '{print $1" "$2" "$3}')
        file=$(echo "$line" | awk '{print $4}')
        
        # 提取标题和L0摘要
        title=$(head -1 "$file" 2>/dev/null | sed 's/^# //')
        l0=$(grep -A 1 "## L0:" "$file" 2>/dev/null | tail -1 | cut -c1-60)
        
        echo -e "${YELLOW}$date_part${NC}"
        echo "  文件: $(basename "$file")"
        echo "  标题: $title"
        echo "  摘要: $l0..."
        echo ""
    done
}

# 显示统计摘要
show_summary() {
    echo -e "${GREEN}记忆系统统计摘要${NC}"
    echo "========================================"
    
    total=0
    for category in "${CATEGORIES[@]}"; do
        if [ -d "$MEMORY_DIR/categories/$category" ]; then
            count=$(find "$MEMORY_DIR/categories/$category" -name "*.md" 2>/dev/null | wc -l)
            total=$((total + count))
            echo -e "${YELLOW}$category:${NC} $count 个记忆"
        fi
    done
    
    echo -e "\n${GREEN}总计:${NC} $total 个记忆文件"
    
    # 显示最新摘要
    latest_summary=$(find "$MEMORY_DIR/summaries" -name "*.md" -type f -exec ls -t {} + 2>/dev/null | head -1)
    if [ -n "$latest_summary" ]; then
        echo -e "\n${GREEN}最新摘要:${NC} $(basename "$latest_summary")"
        echo "内容预览:"
        head -10 "$latest_summary" | grep -v "^#" | sed 's/^/  /'
    fi
}

# 列出所有类别
list_categories() {
    echo -e "${GREEN}可用类别:${NC}"
    echo "========================================"
    
    for category in "${CATEGORIES[@]}"; do
        count=$(find "$MEMORY_DIR/categories/$category" -name "*.md" 2>/dev/null | wc -l)
        echo -e "${YELLOW}$category${NC} ($count 个记忆)"
        
        # 显示该类别的最新记忆
        latest=$(find "$MEMORY_DIR/categories/$category" -name "*.md" -type f -exec ls -t {} + 2>/dev/null | head -1)
        if [ -n "$latest" ]; then
            title=$(head -1 "$latest" 2>/dev/null | sed 's/^# //')
            echo "  最新: $(basename "$latest") - $title"
        fi
        echo ""
    done
}

# 显示记忆详情
show_memory_detail() {
    local filename="$1"
    
    # 在所有类别中查找文件
    for category in "${CATEGORIES[@]}"; do
        file="$MEMORY_DIR/categories/$category/$filename"
        if [ -f "$file" ]; then
            echo -e "${GREEN}记忆详情:${NC} $filename"
            echo -e "${YELLOW}类别:${NC} $category"
            echo "========================================"
            
            # 显示文件内容
            cat "$file"
            return
        fi
    done
    
    echo "未找到记忆文件: $filename"
}

# 主函数
main() {
    # 解析参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -c|--category)
                CATEGORY="$2"
                shift 2
                ;;
            -t|--tag)
                TAG="$2"
                shift 2
                ;;
            -k|--keyword)
                KEYWORD="$2"
                shift 2
                ;;
            -l|--list-categories)
                list_categories
                exit 0
                ;;
            -r|--recent)
                NUM="$2"
                shift 2
                show_recent "$NUM"
                exit 0
                ;;
            -s|--summary)
                show_summary
                exit 0
                ;;
            -h|--help)
                show_help
                exit 0
                ;;
            *)
                # 如果没有选项，可能是文件名或搜索词
                if [[ "$1" == *.md ]]; then
                    show_memory_detail "$1"
                    exit 0
                else
                    # 默认作为关键词搜索
                    KEYWORD="$1"
                    shift
                fi
                ;;
        esac
    done
    
    # 执行搜索
    if [ -n "$CATEGORY" ] && [ -n "$KEYWORD" ]; then
        search_by_category "$CATEGORY" "$KEYWORD"
    elif [ -n "$CATEGORY" ]; then
        search_by_category "$CATEGORY" ""
    elif [ -n "$TAG" ]; then
        search_by_tag "$TAG"
    elif [ -n "$KEYWORD" ]; then
        search_by_keyword "$KEYWORD"
    else
        show_help
    fi
}

# 执行主函数
main "$@"