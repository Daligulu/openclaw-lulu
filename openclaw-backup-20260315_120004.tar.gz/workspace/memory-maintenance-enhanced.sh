#!/bin/bash
# 增强版记忆维护脚本
# 基于 epro-memory 理念改进的记忆系统

set -e

MEMORY_DIR="/root/.openclaw/workspace/memory"
CATEGORIES=("profile" "preferences" "entities" "events" "cases" "patterns")
TODAY=$(date +%Y-%m-%d)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 1. 检查目录结构
ensure_directories() {
    log_info "检查记忆目录结构..."
    
    for category in "${CATEGORIES[@]}"; do
        if [ ! -d "$MEMORY_DIR/categories/$category" ]; then
            mkdir -p "$MEMORY_DIR/categories/$category"
            log_success "创建目录: categories/$category"
        fi
    done
    
    for dir in daily summaries; do
        if [ ! -d "$MEMORY_DIR/$dir" ]; then
            mkdir -p "$MEMORY_DIR/$dir"
            log_success "创建目录: $dir"
        fi
    done
}

# 2. 处理每日记忆文件
process_daily_memory() {
    log_info "处理每日记忆文件..."
    
    DAILY_FILE="$MEMORY_DIR/daily/$TODAY.md"
    YESTERDAY_FILE="$MEMORY_DIR/daily/$YESTERDAY.md"
    
    # 创建今天的每日记忆文件
    if [ ! -f "$DAILY_FILE" ]; then
        cat > "$DAILY_FILE" << EOF
# 每日记忆 - $TODAY

## 系统状态
- **记忆系统**: 增强版运行中
- **分类数量**: ${#CATEGORIES[@]} 个类别
- **最后维护**: $(date)

## 重要事件
<!-- 记录今天的重要事件 -->

## 学习收获
<!-- 记录今天学到的知识 -->

## 待办事项
<!-- 记录需要跟进的事项 -->

## 原始记录
<!-- 原始的对话和观察记录 -->
EOF
        log_success "创建每日记忆文件: $TODAY.md"
    fi
    
    # 处理昨天的记忆文件（如果有）
    if [ -f "$YESTERDAY_FILE" ]; then
        log_info "处理昨日记忆文件: $YESTERDAY.md"
        extract_important_memories "$YESTERDAY_FILE"
    fi
}

# 3. 从每日记忆中提取重要信息
extract_important_memories() {
    local file="$1"
    local date=$(basename "$file" .md)
    
    log_info "从 $date 的记忆中提取重要信息..."
    
    # 这里可以添加更智能的提取逻辑
    # 目前使用简单规则
    
    # 提取可能的事件
    if grep -q -i "决定\|决策\|里程碑\|完成\|开始" "$file"; then
        create_event_from_daily "$file" "$date"
    fi
    
    # 提取可能的偏好
    if grep -q -i "喜欢\|偏好\|习惯\|通常\|总是" "$file"; then
        create_preference_from_daily "$file" "$date"
    fi
    
    # 提取可能的问题解决方案
    if grep -q -i "问题\|解决\|修复\|bug\|错误" "$file"; then
        create_case_from_daily "$file" "$date"
    fi
}

# 4. 创建事件记忆
create_event_from_daily() {
    local file="$1"
    local date="$2"
    local event_id="event_$(date +%s)"
    local event_file="$MEMORY_DIR/categories/events/${event_id}.md"
    
    # 提取事件相关内容
    local content=$(grep -A 5 -B 2 -i "决定\|决策\|里程碑" "$file" | head -20)
    
    if [ -n "$content" ]; then
        cat > "$event_file" << EOF
# [events] 事件 - $date

## L0: 摘要
从 $date 的对话中提取的重要事件

## L1: 概述
- **时间**: $date
- **上下文**: 日常对话和决策
- **来源**: 每日记忆文件 $date.md
- **重要性**: 中

## L2: 详细内容
$content

## 元数据
- **创建时间**: $(date)
- **事件时间**: $date
- **类型**: 日常决策
- **来源**: $file
- **提取方式**: 自动规则匹配

## 后续处理
- [ ] 需要人工审核和补充
- [ ] 可能需要合并到其他事件
- [ ] 考虑添加到长期记忆
EOF
        log_success "创建事件记忆: ${event_id}.md"
    fi
}

# 5. 创建偏好记忆
create_preference_from_daily() {
    local file="$1"
    local date="$2"
    local pref_id="pref_$(date +%s)"
    local pref_file="$MEMORY_DIR/categories/preferences/${pref_id}.md"
    
    local content=$(grep -i "喜欢\|偏好\|习惯" "$file" | head -5)
    
    if [ -n "$content" ]; then
        cat > "$pref_file" << EOF
# [preferences] 偏好观察 - $date

## L0: 摘要
从 $date 的对话中观察到的用户偏好

## L1: 概述
- **观察时间**: $date
- **偏好类型**: 沟通/行为习惯
- **强度**: 待确认
- **稳定性**: 待观察
- **来源**: 每日记忆文件 $date.md

## L2: 详细内容
观察到的偏好表现：
$content

## 元数据
- **创建时间**: $(date)
- **验证次数**: 1
- **置信度**: 低（需要更多验证）
- **来源**: $file

## 验证计划
- [ ] 需要后续观察确认
- [ ] 可能需要合并到现有偏好
- [ ] 评估偏好的稳定性和强度
EOF
        log_success "创建偏好记忆: ${pref_id}.md"
    fi
}

# 6. 创建案例记忆
create_case_from_daily() {
    local file="$1"
    local date="$2"
    local case_id="case_$(date +%s)"
    local case_file="$MEMORY_DIR/categories/cases/${case_id}.md"
    
    local content=$(grep -A 3 -B 1 -i "问题\|解决\|修复" "$file" | head -15)
    
    if [ -n "$content" ]; then
        cat > "$case_file" << EOF
# [cases] 问题记录 - $date

## L0: 摘要
从 $date 的对话中记录的问题和解决方案

## L1: 概述
- **问题时间**: $date
- **问题类型**: 待分类
- **解决状态**: 待确认
- **解决时间**: 待确认
- **效果评估**: 待评估

## L2: 详细内容
问题和解决记录：
$content

## 元数据
- **创建时间**: $(date)
- **记录时间**: $date
- **复杂度**: 待评估
- **可复用性**: 待评估
- **来源**: $file

## 待完善信息
- [ ] 确认问题是否已解决
- [ ] 补充解决方案细节
- [ ] 评估解决方案的可复用性
- [ ] 总结经验教训
EOF
        log_success "创建案例记忆: ${case_id}.md"
    fi
}

# 7. 生成记忆摘要
generate_summary() {
    log_info "生成记忆摘要..."
    
    SUMMARY_FILE="$MEMORY_DIR/summaries/$TODAY-summary.md"
    
    cat > "$SUMMARY_FILE" << EOF
# 记忆系统摘要 - $TODAY

## 系统概览
- **维护时间**: $(date)
- **总类别数**: ${#CATEGORIES[@]}
- **今日处理**: 每日记忆文件提取

## 各类别统计
EOF
    
    # 统计每个类别的文件数量
    for category in "${CATEGORIES[@]}"; do
        count=$(find "$MEMORY_DIR/categories/$category" -name "*.md" 2>/dev/null | wc -l)
        echo "- **$category**: $count 个记忆" >> "$SUMMARY_FILE"
    done
    
    # 添加最近的重要记忆
    echo -e "\n## 最近添加的记忆" >> "$SUMMARY_FILE"
    
    for category in "${CATEGORIES[@]}"; do
        recent_file=$(find "$MEMORY_DIR/categories/$category" -name "*.md" -type f -exec ls -t {} + | head -1 2>/dev/null)
        if [ -n "$recent_file" ]; then
            local title=$(head -1 "$recent_file" | sed 's/^# //')
            local l0=$(grep -A 1 "## L0:" "$recent_file" | tail -1)
            echo -e "\n### $category" >> "$SUMMARY_FILE"
            echo "- **文件**: $(basename "$recent_file")" >> "$SUMMARY_FILE"
            echo "- **标题**: $title" >> "$SUMMARY_FILE"
            echo "- **摘要**: $l0" >> "$SUMMARY_FILE"
        fi
    done
    
    echo -e "\n## 维护建议" >> "$SUMMARY_FILE"
    echo "1. 审核自动提取的记忆，补充详细信息" >> "$SUMMARY_FILE"
    echo "2. 合并相似的记忆条目" >> "$SUMMARY_FILE"
    echo "3. 清理过时或低质量的记忆" >> "$SUMMARY_FILE"
    echo "4. 更新长期记忆文件 (MEMORY.md)" >> "$SUMMARY_FILE"
    
    log_success "生成摘要文件: $TODAY-summary.md"
}

# 8. 更新长期记忆
update_long_term_memory() {
    log_info "更新长期记忆..."
    
    # 这里可以添加从分类记忆中提取重要信息到 MEMORY.md 的逻辑
    # 目前只是记录维护状态
    
    echo -e "\n## $TODAY - 记忆系统增强" >> "$MEMORY_DIR/../MEMORY.md"
    echo "- **记忆系统升级**: 基于 epro-memory 理念实施分类记忆系统" >> "$MEMORY_DIR/../MEMORY.md"
    echo "- **新增功能**: 6类别分类、L0/L1/L2分层、自动提取" >> "$MEMORY_DIR/../MEMORY.md"
    echo "- **维护时间**: $(date)" >> "$MEMORY_DIR/../MEMORY.md"
    
    log_success "长期记忆已更新"
}

# 9. 清理旧文件
cleanup_old_files() {
    log_info "清理旧文件..."
    
    # 清理30天前的每日记忆文件
    find "$MEMORY_DIR/daily" -name "*.md" -mtime +30 -delete 2>/dev/null && \
        log_success "清理30天前的每日记忆文件"
    
    # 清理30天前的摘要文件
    find "$MEMORY_DIR/summaries" -name "*.md" -mtime +30 -delete 2>/dev/null && \
        log_success "清理30天前的摘要文件"
}

# 主函数
main() {
    log_info "开始增强版记忆维护 ($(date))"
    log_info "========================================"
    
    ensure_directories
    process_daily_memory
    generate_summary
    update_long_term_memory
    cleanup_old_files
    
    log_info "========================================"
    log_success "记忆维护完成 ($(date))"
    
    # 显示统计信息
    echo -e "\n${GREEN}记忆系统统计:${NC}"
    echo "总记忆文件: $(find "$MEMORY_DIR/categories" -name "*.md" 2>/dev/null | wc -l)"
    for category in "${CATEGORIES[@]}"; do
        count=$(find "$MEMORY_DIR/categories/$category" -name "*.md" 2>/dev/null | wc -l)
        echo "- $category: $count"
    done
}

# 执行主函数
main "$@"