#!/bin/bash
# 发送AI热点到Telegram

echo "📱 AI热点Telegram推送"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 配置
SUMMARY_FILE="$1"
CHANNEL="telegram"
TARGET="personal"

# 如果没有提供文件，使用最新的摘要
if [ -z "$SUMMARY_FILE" ] || [ ! -f "$SUMMARY_FILE" ]; then
    SUMMARY_DIR="/root/.openclaw/workspace/ai-hotspots/optimized"
    LATEST_SUMMARY=$(ls -t "$SUMMARY_DIR"/summary-*.md 2>/dev/null | head -1)
    
    if [ -n "$LATEST_SUMMARY" ]; then
        SUMMARY_FILE="$LATEST_SUMMARY"
        echo "使用最新摘要: $(basename "$SUMMARY_FILE")"
    else
        echo "❌ 错误: 未找到摘要文件"
        echo ""
        echo "用法: $0 [摘要文件]"
        echo ""
        echo "示例:"
        echo "  $0  # 使用最新摘要"
        echo "  $0 /path/to/summary.md  # 使用指定文件"
        exit 1
    fi
fi

# 读取内容
CONTENT=$(cat "$SUMMARY_FILE")
CONTENT_LENGTH=${#CONTENT}

if [ "$CONTENT_LENGTH" -eq 0 ]; then
    echo "❌ 错误: 摘要内容为空"
    exit 1
fi

echo "📊 推送内容:"
echo "  • 文件: $(basename "$SUMMARY_FILE")"
echo "  • 字符数: $CONTENT_LENGTH"
echo "  • 行数: $(wc -l < "$SUMMARY_FILE")"
echo ""

# Telegram消息限制处理（约4000字符）
MAX_LENGTH=3900
if [ "$CONTENT_LENGTH" -gt "$MAX_LENGTH" ]; then
    echo "⚠️  注意: 内容超过Telegram限制，进行优化..."
    
    # 优化内容：保留前部分
    OPTIMIZED_CONTENT=$(head -15 "$SUMMARY_FILE")
    OPTIMIZED_CONTENT="${OPTIMIZED_CONTENT%\\n}...\\n[内容优化，显示主要热点]"
    
    CONTENT="$OPTIMIZED_CONTENT"
    CONTENT_LENGTH=${#CONTENT}
    echo "  • 优化后字符数: $CONTENT_LENGTH"
fi

echo "🚀 准备发送到Telegram..."
echo ""

# 方法1: 使用OpenClaw的message工具
echo "尝试方法1: OpenClaw message工具..."
if command -v openclaw &> /dev/null; then
    echo "  ✅ OpenClaw已安装"
    
    # 测试发送
    TEST_MESSAGE="🤖 AI热点测试 $(date '+%H:%M')"
    if timeout 5 openclaw message send --channel telegram --to personal --message "$TEST_MESSAGE" 2>/dev/null; then
        echo "  ✅ OpenClaw message工具可用"
        
        # 发送实际内容
        echo "  发送AI热点摘要..."
        if timeout 10 openclaw message send --channel telegram --to personal --message "$CONTENT" 2>/dev/null; then
            echo "  ✅ AI热点已发送到Telegram"
            echo ""
            echo "🎉 推送成功！"
            exit 0
        else
            echo "  ❌ 发送失败"
        fi
    else
        echo "  ⚠️  OpenClaw message工具不可用或配置问题"
    fi
else
    echo "  ⚠️  OpenClaw未安装"
fi

echo ""

# 方法2: 使用OpenClaw API
echo "尝试方法2: OpenClaw API..."
API_URL="http://localhost:3000/api/message"

if timeout 2 curl -s "$API_URL" > /dev/null 2>&1; then
    echo "  ✅ OpenClaw API可访问"
    
    # 转义JSON特殊字符
    ESCAPED_CONTENT=$(echo "$CONTENT" | sed 's/"/\\"/g' | sed ':a;N;$!ba;s/\\n/\\\\n/g')
    
    JSON_PAYLOAD="{
      \"channel\": \"$CHANNEL\",
      \"to\": \"$TARGET\",
      \"message\": \"$ESCAPED_CONTENT\"
    }"
    
    if timeout 5 curl -X POST "$API_URL" \
      -H "Content-Type: application/json" \
      -d "$JSON_PAYLOAD" 2>/dev/null; then
        echo "  ✅ 通过API发送成功"
        echo ""
        echo "🎉 推送成功！"
        exit 0
    else
        echo "  ❌ API发送失败"
    fi
else
    echo "  ⚠️  OpenClaw API不可访问"
fi

echo ""

# 方法3: 使用Telegram Bot API
echo "尝试方法3: Telegram Bot API..."
TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-}"

if [ -n "$TELEGRAM_BOT_TOKEN" ] && [ -n "$TELEGRAM_CHAT_ID" ]; then
    echo "  ✅ Telegram Bot配置可用"
    
    TELEGRAM_API="https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage"
    
    # 发送消息
    if timeout 10 curl -s -X POST "$TELEGRAM_API" \
      -d "chat_id=$TELEGRAM_CHAT_ID" \
      -d "text=$(echo "$CONTENT" | sed 's/"/\\"/g')" \
      -d "parse_mode=Markdown" > /dev/null 2>&1; then
        echo "  ✅ 通过Telegram Bot API发送成功"
        echo ""
        echo "🎉 推送成功！"
        exit 0
    else
        echo "  ❌ Telegram Bot API发送失败"
    fi
else
    echo "  ⚠️  Telegram Bot Token未配置"
    echo "    设置环境变量:"
    echo "    export TELEGRAM_BOT_TOKEN='你的Bot Token'"
    echo "    export TELEGRAM_CHAT_ID='你的Chat ID'"
fi

echo ""
echo "❌ 所有自动发送方法都失败"
echo ""

# 显示内容供手动发送
echo "📋 请手动发送以下内容到Telegram:"
echo "=" * 60
echo "$CONTENT"
echo "=" * 60
echo ""
echo "💡 手动发送步骤:"
echo "1. 复制上方内容"
echo "2. 打开Telegram"
echo "3. 粘贴并发送"
echo ""
echo "🔧 配置建议:"
cat << 'CONFIG'
配置Telegram推送的三种方法:

1. 配置OpenClaw Telegram插件:
   - 安装: openclaw plugins install telegram
   - 配置: 编辑 ~/.openclaw/config.json
   - 重启: openclaw gateway restart

2. 设置环境变量:
   export TELEGRAM_BOT_TOKEN='你的Token'
   export TELEGRAM_CHAT_ID='你的ChatID'

3. 获取凭证:
   - Bot Token: 联系 @BotFather
   - Chat ID: 联系 @userinfobot

配置完成后重新运行此脚本。
CONFIG

echo ""
echo "📁 相关文件:"
echo "  • 配置指南: /root/.openclaw/workspace/ai-hotspots/telegram-setup-summary.md"
echo "  • 测试脚本: /root/.openclaw/workspace/scripts/test-telegram-push.sh"
echo ""
echo "⏰ 下次运行: 配置完成后执行 $0"

exit 1