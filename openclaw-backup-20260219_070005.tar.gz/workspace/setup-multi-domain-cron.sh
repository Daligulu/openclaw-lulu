#!/bin/bash
# 设置多领域热点定时任务（每天8:00）

echo "⏰ 配置多领域热点定时任务（8:00）..."
echo ""

# 配置
WORKFLOW_SCRIPT="/root/.openclaw/workspace/scripts/multi-domain-workflow.sh"
LOG_DIR="/var/log/multi-domain-hotspots"
CRON_USER="root"

# 创建日志目录
mkdir -p "$LOG_DIR"
chmod 755 "$LOG_DIR"

echo "1. 检查工作流脚本..."
if [ ! -f "$WORKFLOW_SCRIPT" ]; then
    echo "❌ 工作流脚本不存在: $WORKFLOW_SCRIPT"
    exit 1
fi

chmod +x "$WORKFLOW_SCRIPT"
echo "   ✅ 脚本权限已设置"

echo ""
echo "2. 配置定时任务..."
echo "   运行时间: 每天 8:00 (北京时间)"
echo "   UTC时间: 0:00 (北京时间 = UTC+8)"
echo ""

# 移除旧的AI热点任务
echo "3. 移除旧的定时任务..."
TEMP_CRON=$(mktemp)
crontab -l 2>/dev/null | grep -v "daily-ai-hotspots-workflow" | grep -v "AI热点" | grep -v "final-optimized-workflow" > "$TEMP_CRON"

# 添加新的多领域任务
echo "" >> "$TEMP_CRON"
echo "# =========================================" >> "$TEMP_CRON"
echo "# 多领域热点自动收集任务" >> "$TEMP_CRON"
echo "# 配置时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$TEMP_CRON"
echo "# 配置者: 璐璐" >> "$TEMP_CRON"
echo "# 领域: AI + 篮球 + 宠物" >> "$TEMP_CRON"
echo "# 推送时间: 每天8:00 (北京时间)" >> "$TEMP_CRON"
echo "# =========================================" >> "$TEMP_CRON"

# 主要运行：每天8:00（北京时间）= UTC 0:00
echo "0 0 * * * $WORKFLOW_SCRIPT >> $LOG_DIR/daily-\$(date +%Y%m%d).log 2>&1  # 每天8:00" >> "$TEMP_CRON"

# 备用运行：每天12:00（北京时间）= UTC 4:00
echo "0 4 * * * $WORKFLOW_SCRIPT --backup >> $LOG_DIR/backup-\$(date +%Y%m%d).log 2>&1  # 每天12:00" >> "$TEMP_CRON"

# 测试运行：每天20:00（北京时间）= UTC 12:00
echo "0 12 * * * $WORKFLOW_SCRIPT --test >> $LOG_DIR/test-\$(date +%Y%m%d).log 2>&1  # 每天20:00" >> "$TEMP_CRON"

echo "" >> "$TEMP_CRON"
echo "# 日志轮转（每天清理7天前的日志）" >> "$TEMP_CRON"
echo "0 1 * * * find $LOG_DIR -name \"*.log\" -mtime +7 -delete 2>/dev/null" >> "$TEMP_CRON"

# 应用新的crontab
crontab "$TEMP_CRON"
rm -f "$TEMP_CRON"

echo "   ✅ 定时任务已配置"
echo ""

echo "4. 验证配置..."
crontab -l | grep -A5 -B5 "多领域热点"

echo ""
echo "5. 创建监控脚本..."
cat > /root/.openclaw/workspace/scripts/monitor-multi-domain.sh << 'EOF'
#!/bin/bash
# 多领域热点系统监控脚本

echo "📊 多领域热点系统监控"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 1. 检查定时任务
echo "1. 定时任务状态:"
crontab -l | grep -E "(multi-domain|多领域热点)" | while read line; do
    echo "   ✅ $line"
done
echo ""

# 2. 检查日志文件
echo "2. 日志文件状态:"
LOG_DIR="/var/log/multi-domain-hotspots"
if [ -d "$LOG_DIR" ]; then
    echo "   日志目录: $LOG_DIR"
    LATEST_LOG=$(ls -t "$LOG_DIR"/*.log 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "   最新日志: $LATEST_LOG"
        echo "   文件大小: $(du -h "$LATEST_LOG" | cut -f1)"
        echo "   最后修改: $(stat -c %y "$LATEST_LOG" | cut -d'.' -f1)"
        
        # 检查最近运行状态
        if tail -5 "$LATEST_LOG" | grep -q "执行完成"; then
            echo "   ✅ 最近运行成功"
        else
            echo "   ⚠️  最近运行状态未知"
        fi
    else
        echo "   ⚠️  暂无日志文件"
    fi
else
    echo "   ❌ 日志目录不存在"
fi
echo ""

# 3. 检查输出文件
echo "3. 输出文件状态:"
OUTPUT_DIR="/root/.openclaw/workspace/multi-domain-hotspots"
if [ -d "$OUTPUT_DIR" ]; then
    echo "   输出目录: $OUTPUT_DIR"
    
    # 检查各领域
    for domain in ai basketball pets combined; do
        DOMAIN_DIR="$OUTPUT_DIR/$domain"
        if [ -d "$DOMAIN_DIR" ]; then
            LATEST_FILE=$(ls -t "$DOMAIN_DIR"/*.md 2>/dev/null | head -1)
            if [ -n "$LATEST_FILE" ]; then
                COUNT=$(grep -c "热点数量" "$LATEST_FILE" 2>/dev/null || echo "0")
                echo "   $domain: $(basename "$LATEST_FILE") ($COUNT条)"
            else
                echo "   $domain: 暂无文件"
            fi
        fi
    done
    
    # 检查归档
    ARCHIVE_COUNT=$(find "$OUTPUT_DIR/archive" -name "*.gz" 2>/dev/null | wc -l)
    echo "   归档文件: $ARCHIVE_COUNT 个"
else
    echo "   ❌ 输出目录不存在"
fi
echo ""

# 4. 检查配置
echo "4. 配置状态:"
CONFIG_DIR="/root/.openclaw/workspace/configs"
for domain in ai-digest-optimized basketball-digest pets-digest; do
    if [ -d "$CONFIG_DIR/$domain" ]; then
        CONFIG_COUNT=$(find "$CONFIG_DIR/$domain" -name "*.json" | wc -l)
        echo "   $domain: ✅ ($CONFIG_COUNT个配置文件)"
    else
        echo "   $domain: ❌ 未配置"
    fi
done
echo ""

# 5. Telegram状态
echo "5. Telegram状态:"
if [ -n "$TELEGRAM_BOT_TOKEN" ]; then
    echo "   ✅ Bot Token已配置"
    echo "   密钥: ${TELEGRAM_BOT_TOKEN:0:10}..."
else
    echo "   ⚠️  Bot Token未设置"
fi

if [ -n "$TELEGRAM_CHAT_ID" ]; then
    echo "   ✅ Chat ID已配置: $TELEGRAM_CHAT_ID"
else
    echo "   ⚠️  Chat ID未设置"
fi
echo ""

# 6. 系统资源
echo "6. 系统资源:"
echo "   磁盘空间:"
df -h /root | tail -1
echo "   内存使用:"
free -h | grep Mem
echo ""

echo "📋 总结:"
echo "运行 'crontab -l' 查看定时任务"
echo "运行 'tail -f /var/log/multi-domain-hotspots/daily-*.log' 查看实时日志"
echo "运行 '/root/.openclaw/workspace/scripts/multi-domain-workflow.sh' 手动运行"
EOF

chmod +x /root/.openclaw/workspace/scripts/monitor-multi-domain.sh

echo "   监控脚本: /root/.openclaw/workspace/scripts/monitor-multi-domain.sh"
echo ""

echo "6. 创建手动测试脚本..."
cat > /root/.openclaw/workspace/scripts/test-multi-domain.sh << 'EOF'
#!/bin/bash
# 手动测试多领域热点系统

echo "🧪 手动测试多领域热点系统..."
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 运行测试
/root/.openclaw/workspace/scripts/multi-domain-workflow.sh

echo ""
echo "📝 测试完成"
echo "查看输出: ls -la /root/.openclaw/workspace/multi-domain-hotspots/"
echo "查看日志: tail -20 /var/log/multi-domain-*.log"
echo "查看Telegram是否收到推送"
EOF

chmod +x /root/.openclaw/workspace/scripts/test-multi-domain.sh

echo "   测试脚本: /root/.openclaw/workspace/scripts/test-multi-domain.sh"
echo ""

echo "7. 使用说明..."
cat << 'EOF'
🎯 多领域热点系统使用指南:

1. 手动运行测试:
   ./test-multi-domain.sh

2. 查看系统状态:
   ./monitor-multi-domain.sh

3. 查看定时任务:
   crontab -l

4. 查看最新热点:
   cat /root/.openclaw/workspace/multi-domain-hotspots/combined/summary-*.md

5. 查看运行日志:
   tail -f /var/log/multi-domain-hotspots/daily-*.log

6. 修改配置:
   • AI配置: /root/.openclaw/workspace/configs/ai-digest-optimized/
   • 篮球配置: /root/.openclaw/workspace/configs/basketball-digest/
   • 宠物配置: /root/.openclaw/workspace/configs/pets-digest/
   • 工作流: /root/.openclaw/workspace/scripts/multi-domain-workflow.sh

⏰ 定时任务安排:
   • 主要运行: 每天 8:00 (北京时间) - UTC 0:00
   • 备用运行: 每天 12:00 (北京时间) - UTC 4:00
   • 测试运行: 每天 20:00 (北京时间) - UTC 12:00

📁 文件位置:
   • 配置: /root/.openclaw/workspace/configs/
   • 脚本: /root/.openclaw/workspace/scripts/
   • 输出: /root/.openclaw/workspace/multi-domain-hotspots/
   • 日志: /var/log/multi-domain-hotspots/
   • 归档: /root/.openclaw/workspace/multi-domain-hotspots/archive/

🌐 覆盖领域:
   • 🤖 AI科技热点
   • 🏀 篮球热点 (NBA/CBA/FIBA/街球)
   • 🐕 宠物热点 (狗狗健康/训练/产品)
EOF

echo ""
echo "✅ 多领域热点定时任务配置完成"
echo "系统将在每天8:00自动运行"
echo "立即测试: ./test-multi-domain.sh"