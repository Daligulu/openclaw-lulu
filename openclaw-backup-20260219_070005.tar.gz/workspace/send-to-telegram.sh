#!/bin/bash
# 发送AI热点到Telegram

echo "📱 配置Telegram发送..."
echo ""

# 配置
SUMMARY_FILE="$1"
CHANNEL="telegram"  # 默认通道
TARGET="personal"   # 发送目标

if [ -z "$SUMMARY_FILE" ] || [ ! -f "$SUMMARY_FILE" ]; then
    echo "❌ 需要提供摘要文件路径"
    echo "用法: $0 <摘要文件> [channel] [target]"
    exit 1
fi

if [ -n "$2" ]; then
    CHANNEL="$2"
fi

if [ -n "$3" ]; then
    TARGET="$3"
fi

echo "发送配置:"
echo "  • 文件: $SUMMARY_FILE"
echo "  • 通道: $CHANNEL"
echo "  • 目标: $TARGET"
echo ""

# 检查文件内容
CONTENT=$(cat "$SUMMARY_FILE")
CONTENT_LENGTH=${#CONTENT}

if [ "$CONTENT_LENGTH" -eq 0 ]; then
    echo "❌ 摘要文件为空"
    exit 1
fi

echo "📊 内容统计:"
echo "  • 字符数: $CONTENT_LENGTH"
echo "  • 行数: $(wc -l < "$SUMMARY_FILE")"
echo ""

# Telegram消息限制（约4000字符）
if [ "$CONTENT_LENGTH" -gt 3900 ]; then
    echo "⚠️  内容超过Telegram限制，进行截断..."
    CONTENT="${CONTENT:0:3900}"
    CONTENT="${CONTENT%\\n}...\\n[内容截断]"
    CONTENT_LENGTH=${#CONTENT}
    echo "  • 截断后: $CONTENT_LENGTH 字符"
fi

echo "🚀 准备发送..."
echo ""

# 这里使用OpenClaw的message工具发送
# 实际发送需要根据OpenClaw配置调整

cat > /tmp/telegram-send-script.py << 'EOF'
#!/usr/bin/env python3
"""
Telegram发送脚本 - 通过OpenClaw的message工具
"""

import sys
import os

def send_to_telegram(content, channel="telegram", target="personal"):
    """通过OpenClaw发送消息到Telegram"""
    
    print(f"准备发送到 {channel}/{target}")
    print(f"内容长度: {len(content)} 字符")
    print("")
    
    # 这里应该是实际的OpenClaw message工具调用
    # 由于在OpenClaw环境中，我们可以直接使用message工具
    
    # 模拟发送
    print("📤 发送消息...")
    print("=" * 40)
    print(content[:500] + "..." if len(content) > 500 else content)
    print("=" * 40)
    
    # 在实际环境中，这里应该是：
    # from openclaw_tools import message
    # message.send(
    #     channel=channel,
    #     to=target,
    #     message=content
    # )
    
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 telegram-send-script.py <内容文件> [channel] [target]")
        sys.exit(1)
    
    filepath = sys.argv[1]
    channel = sys.argv[2] if len(sys.argv) > 2 else "telegram"
    target = sys.argv[3] if len(sys.argv) > 3 else "personal"
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if not content.strip():
            print("❌ 文件内容为空")
            sys.exit(1)
        
        success = send_to_telegram(content, channel, target)
        
        if success:
            print("✅ 发送成功（模拟）")
            print("")
            print("💡 实际环境中，需要:")
            print("1. 确保OpenClaw Telegram插件已配置")
            print("2. 使用message工具发送:")
            print("   message.send(channel='telegram', to='personal', message=content)")
        else:
            print("❌ 发送失败")
            
    except Exception as e:
        print(f"❌ 错误: {e}")
        sys.exit(1)
EOF

# 运行发送脚本
python3 /tmp/telegram-send-script.py "$SUMMARY_FILE" "$CHANNEL" "$TARGET"

echo ""
echo "📝 实际集成步骤:"
cat << 'EOF'
1. 确保OpenClaw Telegram通道已配置
2. 在daily-ai-hotspots-workflow.sh中添加:
   
   # 发送到Telegram
   if command -v openclaw &> /dev/null; then
       openclaw message send \
         --channel telegram \
         --to personal \
         --message "$(cat $SUMMARY_FILE)"
   fi

3. 或者使用OpenClaw的API:
   
   curl -X POST http://localhost:3000/api/message \
     -H "Content-Type: application/json" \
     -d '{
       "channel": "telegram",
       "to": "personal", 
       "message": "'"$(cat $SUMMARY_FILE | sed 's/\"/\\\\\"/g')"'"
     }'

4. 测试发送权限和配置
EOF

echo ""
echo "✅ Telegram发送配置完成"
echo "将发送脚本集成到工作流中即可实现自动推送"