---
title: 测试Obsidian Skill
date: 2026-02-26
tags:
  - obsidian
  - test
  - skill
status: in-progress
priority: high
---

# 测试Obsidian Skill

这是一个测试Obsidian Markdown功能的笔记。

## Obsidian特色功能测试

### 1. Wikilinks内部链接
这是一个内部链接：[[test-note]]
这是带显示文本的链接：[[test-note|测试笔记]]
这是链接到标题：[[test-note#章节标题]]

### 2. Callouts（标注框）
> [!note]
> 这是一个note标注框

> [!tip] 提示标题
> 这是一个带自定义标题的tip标注框

> [!warning]- 可折叠警告
> 这个标注框默认是折叠的

### 3. 任务列表
- [x] 已完成任务
- [ ] 待办任务1
- [ ] 待办任务2
  - [ ] 子任务1
  - [x] 子任务2

### 4. 表格
| 姓名 | 年龄 | 状态 |
|------|------|------|
| 张三 | 25 | 活跃 |
| 李四 | 30 | 离线 |
| 王五 | 28 | 活跃 |

### 5. 数学公式
行内公式：$E = mc^2$

块级公式：
$$
\int_a^b f(x) dx = F(b) - F(a)
$$

### 6. 代码块
```python
def hello_world():
    print("Hello, Obsidian!")
    return True
```

### 7. 高亮文本
这是一个==高亮显示==的文本

### 8. 脚注
这是一个带脚注的句子[^1]

[^1]: 这是脚注的内容

### 9. 评论
这是可见文本%%这是隐藏的评论%%

%%
这是多行隐藏评论
不会在阅读视图中显示
%%

## 总结
这个测试文件展示了Obsidian Markdown的主要功能。