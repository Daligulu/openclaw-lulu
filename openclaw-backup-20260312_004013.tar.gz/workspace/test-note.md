---
title: 测试笔记
date: 2026-02-25
tags:
  - test
  - obsidian
  - skill
priority: high
status: in-progress
---

# 测试笔记

这是另一个测试笔记，用于测试Obsidian Base的链接功能。

## 章节标题

这是测试章节，可以被链接到。

## 内容

测试Obsidian的各种功能：
- Wikilinks
- Callouts
- 任务列表
- 表格

> [!info] 信息标注框
> 这是一个信息标注框，用于测试callouts功能。

## 任务列表
- [x] 任务1
- [ ] 任务2
- [ ] 任务3

## 相关链接
- [[test-obsidian]]
- [[test-obsidian#Obsidian特色功能测试]]

这个笔记有`test`标签，应该会被Base文件过滤到。