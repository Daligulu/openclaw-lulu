---
title: "{{title}}"
created: "{{date}} {{time}}"
updated: "{{date}} {{time}}"
tags: [note, {{category}}]
type: note
related: []
---

# {{title}}

## 内容
{{content}}

## 关键信息
- 

## 相关概念
- 

## 应用场景
- 

## 参考资料
- 

---
*创建时间: {{date}} {{time}}*