---
title: "{{title}}"
created: "{{date}} {{time}}"
updated: "{{date}} {{time}}"
tags: [article, {{category}}]
source: "AI Agent"
status: draft
word_count: {{word_count}}
reading_time: {{reading_time}}
---

# {{title}}

## 摘要
{{summary}}

## 正文
{{content}}

## 关键要点
- 

## 相关链接
- 

## 后续行动
- [ ] 

---
*本文由AI Agent自动生成*
*生成时间: {{date}} {{time}}*
*字数: {{word_count}}*
*预计阅读时间: {{reading_time}}*