---
title: "{{date:YYYY-MM-DD}}"
created: "{{date}} {{time}}"
tags: [daily]
type: daily
---

# {{date:YYYY年MM月DD日}} 星期四

## 📅 今日计划
- [ ] 

## 📝 今日记录
- 

## 💡 今日想法
- 

## 📚 今日学习
- 

## 🔗 相关链接
- 

## 📊 今日总结
**完成事项:**
- 

**未完成事项:**
- 

**明日计划:**
- 

---
*自动生成时间: {{date}} {{time}}*