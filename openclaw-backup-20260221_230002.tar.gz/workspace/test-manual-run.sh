#!/bin/bash
# 手动测试AI热点收集

echo "🧪 手动测试AI热点系统..."
echo ""

# 运行测试
/root/.openclaw/workspace/scripts/daily-ai-hotspots-workflow.sh

echo ""
echo "📝 测试完成"
echo "查看报告: ls -la /root/.openclaw/workspace/ai-hotspots/"
echo "查看日志: tail -20 /var/log/ai-hotspots-*.log"
