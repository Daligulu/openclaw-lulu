#!/bin/bash
# AI热点报告查看脚本

echo "🤖 AI热点报告查看工具"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 查找最新报告
LATEST_REPORT=$(find /root/.openclaw/workspace/ai-hotspots-only -name "daily-*.md" -type f 2>/dev/null | sort -r | head -1)

if [ -f "$LATEST_REPORT" ]; then
    REPORT_NAME=$(basename "$LATEST_REPORT")
    REPORT_SIZE=$(du -h "$LATEST_REPORT" | cut -f1)
    REPORT_TIME=$(stat -c %y "$LATEST_REPORT" 2>/dev/null | cut -d'.' -f1)
    
    echo "📄 最新报告: $REPORT_NAME"
    echo "📏 文件大小: $REPORT_SIZE"
    echo "🕐 生成时间: $REPORT_TIME"
    echo "📁 文件路径: $LATEST_REPORT"
    echo ""
    
    echo "🔧 查看选项:"
    echo "1. 查看前50行"
    echo "2. 查看统计信息"
    echo "3. 查看高评分热点"
    echo "4. 复制到剪贴板"
    echo "5. 启动HTTP服务器"
    echo ""
    
    read -p "请选择 (1-5): " choice
    
    case $choice in
        1)
            echo ""
            echo "📋 前50行内容:"
            echo "----------------------------------------"
            head -50 "$LATEST_REPORT"
            echo "----------------------------------------"
            ;;
        2)
            echo ""
            echo "📊 统计信息:"
            grep -E "(热点数量|高评分|生成时间)" "$LATEST_REPORT" | head -5
            ;;
        3)
            echo ""
            echo "⭐ 高评分热点(≥8分):"
            grep -B1 -A2 "评分.*[89]\|10\.0" "$LATEST_REPORT" | head -30
            ;;
        4)
            if command -v xclip >/dev/null 2>&1; then
                cat "$LATEST_REPORT" | xclip -selection clipboard
                echo "✅ 报告内容已复制到剪贴板"
            elif command -v pbcopy >/dev/null 2>&1; then
                cat "$LATEST_REPORT" | pbcopy
                echo "✅ 报告内容已复制到剪贴板"
            else
                echo "❌ 未找到剪贴板工具 (安装xclip或pbcopy)"
            fi
            ;;
        5)
            echo ""
            echo "🚀 启动HTTP服务器..."
            python3 -m http.server 8888 --directory /root/.openclaw/workspace/ai-hotspots-only &
            SERVER_PID=$!
            echo "✅ HTTP服务器已启动 (PID: $SERVER_PID)"
            echo "🔗 访问地址: http://localhost:8888"
            echo "🛑 按 Ctrl+C 停止服务器"
            wait $SERVER_PID
            ;;
        *)
            echo "❌ 无效选择"
            ;;
    esac
else
    echo "❌ 未找到AI热点报告"
    echo "   运行以下命令生成报告:"
    echo "   /root/.openclaw/workspace/scripts/ai-hotspots-only.sh"
fi
