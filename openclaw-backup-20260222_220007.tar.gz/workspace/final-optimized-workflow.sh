#!/bin/bash
# 最终优化工作流 - 集成优化评分算法

echo "🎯 AI热点系统 - 最终优化版本"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 配置
CONFIG_DIR="/root/.openclaw/workspace/configs/ai-digest-optimized"
OUTPUT_DIR="/root/.openclaw/workspace/ai-hotspots"
LOG_FILE="/var/log/ai-hotspots-optimized-$(date +%Y%m%d).log"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 创建目录
mkdir -p "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR/optimized"
mkdir -p "$(dirname "$LOG_FILE")"

# 记录开始
echo "=== AI热点优化工作流开始 ===" >> "$LOG_FILE"
echo "开始时间: $(date)" >> "$LOG_FILE"
echo "配置版本: v2.0 (优化评分)" >> "$LOG_FILE"

# 1. 环境设置
echo "1. 设置环境..." | tee -a "$LOG_FILE"
export BRAVE_API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
export TZ='Asia/Shanghai'

cd /root/.openclaw/workspace/skills/tech-news-digest || {
    echo "❌ 无法进入技能目录" | tee -a "$LOG_FILE"
    exit 1
}

# 2. 数据收集
echo "2. 收集AI热点数据..." | tee -a "$LOG_FILE"
DATA_FILE="/tmp/ai-optimized-$TIMESTAMP.json"

python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_DIR" \
  --hours 24 \
  --output "$DATA_FILE" \
  2>&1 | tee -a "$LOG_FILE"

if [ ! -f "$DATA_FILE" ]; then
    echo "❌ 数据收集失败" | tee -a "$LOG_FILE"
    exit 1
fi

DATA_SIZE=$(wc -c < "$DATA_FILE")
echo "✅ 数据收集完成: $DATA_SIZE 字节" | tee -a "$LOG_FILE"

# 3. 应用优化评分算法
echo "3. 应用优化评分算法..." | tee -a "$LOG_FILE"

REPORT_FILE="$OUTPUT_DIR/optimized/daily-$TIMESTAMP.md"
SUMMARY_FILE="$OUTPUT_DIR/optimized/summary-$TIMESTAMP.md"

# 生成详细报告
python3 /root/.openclaw/workspace/scripts/optimized-scoring-report.py "$DATA_FILE" "$REPORT_FILE" 2>&1 | tee -a "$LOG_FILE"

if [ ! -f "$REPORT_FILE" ]; then
    echo "❌ 报告生成失败" | tee -a "$LOG_FILE"
    exit 1
fi

# 生成简洁摘要
cat > /tmp/generate-optimized-summary.py << 'EOF'
import json
import sys
from datetime import datetime

def generate_summary(data_file, output_file):
    with open(data_file, 'r') as f:
        data = json.load(f)
    
    # 简单提取热点
    hotspots = []
    topics = data.get('topics', {})
    
    for topic_name, topic_data in topics.items():
        articles = topic_data.get('articles', [])
        for article in articles[:3]:  # 每个主题取前3条
            title = article.get('title', '')
            if title:
                hotspots.append({
                    'title': title[:60],
                    'source': article.get('source_name', article.get('source', '未知'))
                })
    
    now = datetime.now()
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"🤖 AI热点摘要 {now.strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"共{len(hotspots)}条热点\n\n")
        
        for i, hotspot in enumerate(hotspots[:8], 1):
            f.write(f"{i}. {hotspot['title']}\n")
            f.write(f"   来源: {hotspot['source']}\n\n")
        
        f.write("---\n")
        f.write("#AI热点 #优化评分v2.0\n")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python3 generate-summary.py <数据文件> <输出文件>")
        sys.exit(1)
    
    generate_summary(sys.argv[1], sys.argv[2])
EOF

python3 /tmp/generate-optimized-summary.py "$DATA_FILE" "$SUMMARY_FILE" 2>&1 | tee -a "$LOG_FILE"

echo "✅ 报告生成完成" | tee -a "$LOG_FILE"

# 4. 统计信息
echo "4. 生成统计信息..." | tee -a "$LOG_FILE"

STATS_FILE="$OUTPUT_DIR/optimized/stats-$TIMESTAMP.json"

python3 -c "
import json
from datetime import datetime

with open('$DATA_FILE', 'r') as f:
    data = json.load(f)

# 应用评分算法
sys.path.append('/root/.openclaw/workspace/scripts')
from optimized_scoring_report import AIScoringOptimizer

scorer = AIScoringOptimizer()
hotspots = scorer.filter_and_score_articles(data)

stats = {
    'timestamp': datetime.now().isoformat(),
    'config_version': 'v2.0',
    'data_file': '$DATA_FILE',
    'report_file': '$REPORT_FILE',
    'summary_file': '$SUMMARY_FILE',
    'collection_stats': data.get('output_stats', {}),
    'scoring_stats': {
        'total_articles': len(hotspots),
        'avg_score': sum(h['score'] for h in hotspots) / len(hotspots) if hotspots else 0,
        'score_distribution': {},
        'topic_distribution': {},
        'source_distribution': {}
    }
}

# 评分分布
score_dist = {}
for h in hotspots:
    score_range = int(h['score'])
    score_dist[score_range] = score_dist.get(score_range, 0) + 1
stats['scoring_stats']['score_distribution'] = score_dist

# 主题分布
topic_dist = {}
for h in hotspots:
    topic = h['topic']
    topic_dist[topic] = topic_dist.get(topic, 0) + 1
stats['scoring_stats']['topic_distribution'] = topic_dist

# 来源分布
source_dist = {}
for h in hotspots:
    source = h['source']
    source_dist[source] = source_dist.get(source, 0) + 1
stats['scoring_stats']['source_distribution'] = source_dist

with open('$STATS_FILE', 'w') as f:
    json.dump(stats, f, indent=2, ensure_ascii=False)

print(f'统计文件: $STATS_FILE')
print(f'热点数量: {len(hotspots)}')
if hotspots:
    avg_score = sum(h['score'] for h in hotspots) / len(hotspots)
    print(f'平均评分: {avg_score:.1f}')
" 2>&1 | tee -a "$LOG_FILE"

# 5. 归档处理
echo "5. 归档处理..." | tee -a "$LOG_FILE"

ARCHIVE_FILE="$OUTPUT_DIR/optimized/archive/ai-data-$TIMESTAMP.json.gz"
mkdir -p "$(dirname "$ARCHIVE_FILE")"

gzip -c "$DATA_FILE" > "$ARCHIVE_FILE" 2>/dev/null && \
    echo "✅ 数据已归档: $ARCHIVE_FILE" | tee -a "$LOG_FILE"

# 6. 清理临时文件
find /tmp -name "ai-optimized-*" -mtime +1 -delete 2>/dev/null
find /tmp -name "td-*.json" -mtime +1 -delete 2>/dev/null

# 7. 完成
echo "" | tee -a "$LOG_FILE"
echo "=== AI热点优化工作流完成 ===" | tee -a "$LOG_FILE"
echo "完成时间: $(date)" | tee -a "$LOG_FILE"
echo "总耗时: ${SECONDS}秒" | tee -a "$LOG_FILE"
echo "输出文件:" | tee -a "$LOG_FILE"
echo "  • 详细报告: $REPORT_FILE" | tee -a "$LOG_FILE"
echo "  • 简洁摘要: $SUMMARY_FILE" | tee -a "$LOG_FILE"
echo "  • 统计信息: $STATS_FILE" | tee -a "$LOG_FILE"
echo "  • 归档数据: $ARCHIVE_FILE" | tee -a "$LOG_FILE"
echo "  • 运行日志: $LOG_FILE" | tee -a "$LOG_FILE"

echo ""
echo "🎉 AI热点系统 - 优化版本部署完成！"
echo ""
echo "📊 系统特性:"
echo "  ✅ 优化评分算法 v2.0"
echo "  ✅ 基础分5.0 + 来源权重"
echo "  ✅ 关键词加分机制"
echo "  ✅ 中文内容优先"
echo "  ✅ 时效性奖励"
echo "  ✅ 最低6分阈值"
echo ""
echo "🚀 使用命令:"
echo "  查看报告: cat $REPORT_FILE | head -40"
echo "  查看摘要: cat $SUMMARY_FILE"
echo "  查看统计: cat $STATS_FILE | jq ."
echo "  查看日志: tail -20 $LOG_FILE"
echo ""
echo "⏰ 下一步: 设置定时任务和Telegram集成"