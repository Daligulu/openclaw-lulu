const https = require('https');

const hubUrl = 'https://evomap.ai';
const nodeId = 'node_d11440709e39';
const claimCode = 'L5KD-XQRX';

// 读取资产数据
const fs = require('fs');
const path = require('path');

// 读取Capsule资产
const capsulesPath = path.join(__dirname, 'assets/gep/capsules.json');
const capsulesData = JSON.parse(fs.readFileSync(capsulesPath, 'utf8'));

// 读取Gene资产
const genesPath = path.join(__dirname, 'assets/gep/genes.json');
const genesData = JSON.parse(fs.readFileSync(genesPath, 'utf8'));

// 读取EvolutionEvent资产
const eventsPath = path.join(__dirname, 'assets/gep/events.jsonl');
const eventsContent = fs.readFileSync(eventsPath, 'utf8');
const events = eventsContent.trim().split('\n').map(line => JSON.parse(line));

console.log('准备发送资产到EvoMap Hub:');
console.log(`- Gene数量: ${genesData.genes.length}`);
console.log(`- Capsule数量: ${capsulesData.capsules.length}`);
console.log(`- EvolutionEvent数量: ${events.length}`);

// 发送HTTP请求到EvoMap Hub
function sendToHub(messages) {
  const data = JSON.stringify({
    messages: messages,
    node_id: nodeId,
    claim_code: claimCode
  });

  const options = {
    hostname: 'evomap.ai',
    port: 443,
    path: '/a2a/receive',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  };

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      res.on('end', () => {
        console.log(`响应状态码: ${res.statusCode}`);
        if (res.statusCode === 200) {
          try {
            const result = JSON.parse(responseData);
            resolve(result);
          } catch (e) {
            resolve({ success: true, raw: responseData });
          }
        } else {
          reject(new Error(`HTTP ${res.statusCode}: ${responseData}`));
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.write(data);
    req.end();
  });
}

// 生成协议消息
function generateMessage(type, payload) {
  const timestamp = new Date().toISOString();
  const messageId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  return {
    protocol: "gep-a2a",
    protocol_version: "1.0.0",
    message_type: type,
    message_id: messageId,
    sender_id: nodeId,
    timestamp: timestamp,
    payload: payload
  };
}

async function main() {
  try {
    // 创建hello消息
    const helloMessage = generateMessage("hello", {
      capabilities: {},
      gene_count: genesData.genes.length,
      capsule_count: capsulesData.capsules.length,
      env_fingerprint: {
        device_id: "62287cfa5f20fb8409799d4f659fc767",
        node_version: process.version,
        platform: process.platform,
        arch: process.arch,
        os_release: require('os').release(),
        evolver_version: "1.15.0",
        cwd: process.cwd(),
        container: false
      }
    });

    // 创建Gene发布消息
    const geneMessages = genesData.genes.map(gene => {
      return generateMessage("publish", {
        asset_type: "Gene",
        asset_id: gene.asset_id,
        local_id: gene.id,
        asset: gene
      });
    });

    // 创建Capsule发布消息
    const capsuleMessages = capsulesData.capsules.map(capsule => {
      return generateMessage("publish", {
        asset_type: "Capsule",
        asset_id: capsule.asset_id,
        local_id: capsule.id,
        asset: capsule
      });
    });

    // 创建EvolutionEvent发布消息
    const eventMessages = events.map(event => {
      return generateMessage("publish", {
        asset_type: "EvolutionEvent",
        asset_id: event.asset_id,
        local_id: event.id,
        asset: event
      });
    });

    // 合并所有消息
    const allMessages = [helloMessage, ...geneMessages, ...capsuleMessages, ...eventMessages];

    console.log(`\n发送 ${allMessages.length} 条消息到EvoMap Hub...`);
    
    const result = await sendToHub(allMessages);
    console.log('✅ 资产发送成功！');
    console.log('响应:', JSON.stringify(result, null, 2));
    
  } catch (error) {
    console.error('❌ 发送资产失败:', error.message);
  }
}

main();
