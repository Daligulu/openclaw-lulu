// 修复Evolver使用正确的sender_id
const fs = require('fs');
const path = require('path');

const evolverDir = '/root/.openclaw/workspace/evolver';
const a2aProtocolFile = path.join(evolverDir, 'src/gep/a2aProtocol.js');

console.log('🔧 修复Evolver sender_id配置...');

// 读取文件
let content = fs.readFileSync(a2aProtocolFile, 'utf8');

// 修改getNodeId函数，优先使用A2A_SENDER_ID
const oldFunction = `function getNodeId() {
  if (process.env.A2A_NODE_ID) return String(process.env.A2A_NODE_ID);
  const deviceId = getDeviceId();
  const agentName = process.env.AGENT_NAME || 'default';
  // Include cwd so multiple evolver instances in different directories
  // on the same machine get distinct nodeIds without manual config.
  const raw = deviceId + '|' + agentName + '|' + process.cwd();
  return 'node_' + crypto.createHash('sha256').update(raw).digest('hex').slice(0, 12);
}`;

const newFunction = `function getNodeId() {
  // 优先使用A2A_SENDER_ID，这是EvoMap要求的固定节点ID
  if (process.env.A2A_SENDER_ID) return String(process.env.A2A_SENDER_ID);
  if (process.env.A2A_NODE_ID) return String(process.env.A2A_NODE_ID);
  const deviceId = getDeviceId();
  const agentName = process.env.AGENT_NAME || 'default';
  // Include cwd so multiple evolver instances in different directories
  // on the same machine get distinct nodeIds without manual config.
  const raw = deviceId + '|' + agentName + '|' + process.cwd();
  return 'node_' + crypto.createHash('sha256').update(raw).digest('hex').slice(0, 12);
}`;

if (content.includes(oldFunction)) {
    content = content.replace(oldFunction, newFunction);
    fs.writeFileSync(a2aProtocolFile, content, 'utf8');
    console.log('✅ 已修复getNodeId函数，优先使用A2A_SENDER_ID');
} else {
    console.log('⚠️  未找到getNodeId函数，可能文件结构已变化');
}

console.log('');
console.log('📋 修复后的配置：');
console.log('1. 环境变量 A2A_SENDER_ID=node_d11440709e39');
console.log('2. 环境变量 A2A_NODE_ID=node_d11440709e39');
console.log('3. 环境变量 A2A_HUB_URL=https://evomap.ai');
console.log('');
console.log('🚀 现在可以正确使用节点ID: node_d11440709e39');