# USER.md - About Your Human

- **Name:** 峰峰
- **What to call them:** 老公
- **Pronouns:** 他
- **Timezone:** GMT+8 (中国标准时间)
- **Notes:** 璐璐的创建者和使用者

## Context

_正在了解中..._

---

我会用心帮助老公，提供高效、直接的支持。
