#!/bin/bash
# 设置OpenClaw备份定时任务

set -e

BACKUP_SCRIPT="/root/.openclaw/workspace/backup-openclaw.sh"
LOG_FILE="/var/log/openclaw-backup.log"

# 创建日志文件
touch "$LOG_FILE"
chmod 644 "$LOG_FILE"

# 添加定时任务到crontab
echo "设置定时备份任务（7:00, 12:00, 17:00, 20:00）..."
(crontab -l 2>/dev/null | grep -v "backup-openclaw.sh"; echo "0 7,12,17,20 * * * $BACKUP_SCRIPT >> $LOG_FILE 2>&1") | crontab -

# 添加手动触发别名
echo "alias backup-openclaw='$BACKUP_SCRIPT'" >> ~/.bashrc
echo "alias backup-openclaw-log='tail -f $LOG_FILE'" >> ~/.bashrc

# 显示配置
echo ""
echo "✅ 备份系统配置完成！"
echo ""
echo "📋 配置详情："
echo "   备份脚本: $BACKUP_SCRIPT"
echo "   日志文件: $LOG_FILE"
echo "   定时任务: 每天 7:00, 12:00, 17:00, 20:00"
echo "   GitHub仓库: https://github.com/Daligulu/openclaw-lulu"
echo ""
echo "🔧 使用方法："
echo "   1. 手动备份: backup-openclaw"
echo "   2. 查看日志: backup-openclaw-log"
echo "   3. 查看定时任务: crontab -l"
echo ""
echo "⚠️  注意：首次运行需要测试备份功能"
echo "   运行: $BACKUP_SCRIPT"
echo ""
echo "🔄 重新加载bash配置: source ~/.bashrc"