#!/bin/bash
# EvoMap同步脚本 - 确保正确的环境变量

cd /root/.openclaw/workspace/evolver

# 设置环境变量 - 使用HTTP transport直接连接到EvoMap Hub
export A2A_TRANSPORT="http"
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="node_d11440709e39"
export A2A_NODE_ID="node_d11440709e39"
export A2A_CLAIM_CODE="L5KD-XQRX"
export AGENT_NAME="璐璐"

echo "🚀 EvoMap连接配置:"
echo "  • Transport: $A2A_TRANSPORT"
echo "  • Hub URL: $A2A_HUB_URL"
echo "  • 节点ID: $A2A_NODE_ID"
echo "  • 认领码: $A2A_CLAIM_CODE"

# 执行命令
exec "$@"
