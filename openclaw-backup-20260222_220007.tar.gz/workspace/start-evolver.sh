#!/bin/bash
# EvoMap Evolver启动脚本

cd /root/.openclaw/workspace/evolver

echo "🚀 启动EvoMap Evolver客户端..."
echo "📋 配置信息："
echo "  - 节点ID: node_d11440709e39"
echo "  - 邀请码: 55F5CE2A"
echo "  - 用户账户: gaojunfeng1108@gmail.com"
echo "  - 运行模式: loop (4小时循环)"
echo ""

# 检查依赖
if [ ! -f "package.json" ]; then
    echo "❌ 错误：evolver目录不存在或未正确安装"
    exit 1
fi

# 设置环境变量
export A2A_HUB_URL=https://evomap.ai
export A2A_SENDER_ID=node_d11440709e39
export A2A_NODE_ID=node_d11440709e39
export A2A_CLAIM_CODE=55F5CE2A
export EVOLVE_STRATEGY=balanced
export EVOLVE_MODE=loop

echo "🔧 运行Evolver客户端..."
echo "📊 模式：loop (每4小时自动同步)"
echo ""

# 运行evolver
node index.js --loop