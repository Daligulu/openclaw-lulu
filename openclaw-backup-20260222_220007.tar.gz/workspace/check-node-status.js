#!/usr/bin/env node

// 检查节点状态
const https = require('https');

const NODE_ID = 'node_d11440709e39';
const USER_EMAIL = 'gaojunfeng1108@gmail.com';

console.log('🔍 检查EvoMap节点状态');
console.log('========================================');
console.log('节点ID:', NODE_ID);
console.log('用户邮箱:', USER_EMAIL);
console.log('========================================\n');

// 方法1: 检查节点信息
console.log('1. 检查节点信息...');
const options1 = {
  hostname: 'evomap.ai',
  port: 443,
  path: `/a2a/nodes/${NODE_ID}`,
  method: 'GET',
  headers: {
    'User-Agent': 'EvoMap-Node-Checker/1.0'
  },
  timeout: 30000
};

const req1 = https.request(options1, (res) => {
  console.log('状态码:', res.statusCode);
  console.log('状态消息:', res.statusMessage);
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('响应:');
    try {
      const parsed = JSON.parse(data);
      console.log(JSON.stringify(parsed, null, 2));
      
      if (res.statusCode === 200) {
        console.log('\n✅ 节点信息获取成功');
        if (parsed.status) {
          console.log('节点状态:', parsed.status);
        }
        if (parsed.reputation !== undefined) {
          console.log('声誉分数:', parsed.reputation);
        }
        if (parsed.credits !== undefined) {
          console.log('积分:', parsed.credits);
        }
        if (parsed.last_seen) {
          console.log('最后在线:', parsed.last_seen);
        }
      } else if (res.statusCode === 404) {
        console.log('\n❌ 节点不存在或未找到');
      } else {
        console.log('\n⚠️ 无法获取节点信息');
      }
    } catch (e) {
      console.log('原始响应:', data);
    }
    
    // 方法2: 检查Hub状态
    console.log('\n2. 检查EvoMap Hub状态...');
    const options2 = {
      hostname: 'evomap.ai',
      port: 443,
      path: '/a2a/stats',
      method: 'GET',
      timeout: 30000
    };
    
    const req2 = https.request(options2, (res2) => {
      console.log('状态码:', res2.statusCode);
      let data2 = '';
      res2.on('data', (chunk) => data2 += chunk);
      res2.on('end', () => {
        try {
          const stats = JSON.parse(data2);
          console.log('Hub状态:', JSON.stringify(stats, null, 2));
          
          if (res2.statusCode === 200) {
            console.log('\n✅ EvoMap Hub运行正常');
          }
        } catch (e) {
          console.log('Hub状态响应:', data2);
        }
        
        console.log('\n========================================');
        console.log('诊断完成');
        console.log('\n🔧 问题分析:');
        console.log('1. 节点ID已被认领 → 需要新节点ID或确认所有权');
        console.log('2. 用户邮箱已绑定 → 检查绑定状态');
        console.log('3. 节点可能处于休眠状态 → 需要激活');
        console.log('\n🎯 解决方案:');
        console.log('1. 生成新节点ID并重新注册');
        console.log('2. 联系EvoMap支持确认节点所有权');
        console.log('3. 使用正确认领码激活节点');
      });
    });
    
    req2.on('error', (err) => {
      console.log('检查Hub状态错误:', err.message);
    });
    
    req2.end();
  });
});

req1.on('error', (err) => {
  console.log('检查节点信息错误:', err.message);
  console.log('可能网络连接有问题');
});

req1.end();