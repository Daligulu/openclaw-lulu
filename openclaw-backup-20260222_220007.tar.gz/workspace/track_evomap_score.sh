#!/bin/bash
# EvoMap积分追踪脚本

NODE_ID="node_d80158479a5d"
TRACK_FILE="/root/.openclaw/workspace/evolver/score_tracking/score_history.json"
LOG_FILE="/root/.openclaw/workspace/evolver/score_tracking/tracking.log"

echo "=== EvoMap积分追踪 $(date) ===" | tee -a "$LOG_FILE"

# 尝试获取节点状态
echo "获取节点 $NODE_ID 状态..." | tee -a "$LOG_FILE"

# 使用Evolver的API查询
cd /root/.openclaw/workspace/evolver
SCORE_INFO=$(./run-with-env.sh node -e "
const https = require('https');

const fetchMessage = {
  protocol: 'gep-a2a',
  protocol_version: '1.0.0',
  message_type: 'fetch',
  message_id: 'track_score_' + Date.now(),
  sender_id: process.env.A2A_SENDER_ID,
  timestamp: new Date().toISOString(),
  payload: {
    asset_type: 'Capsule',
    limit: 1,
    filters: {}
  }
};

const data = JSON.stringify(fetchMessage);

const options = {
  hostname: 'evomap.ai',
  port: 443,
  path: '/a2a/fetch',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = https.request(options, (res) => {
  let responseData = '';
  res.on('data', (chunk) => {
    responseData += chunk;
  });
  res.on('end', () => {
    try {
      const result = JSON.parse(responseData);
      console.log('节点状态: 网络连接正常');
      console.log('消息ID:', result.message_id);
      console.log('发送者:', result.sender_id);
      console.log('时间:', result.timestamp);
    } catch (error) {
      console.log('网络响应:', responseData.substring(0, 200));
    }
  });
});

req.on('error', (error) => {
  console.log('网络错误:', error.message);
});

req.write(data);
req.end();
" 2>&1 | tail -10)

echo "$SCORE_INFO" | tee -a "$LOG_FILE"

# 记录追踪数据
TIMESTAMP=$(date -Iseconds)
TRACK_DATA="{
  \"timestamp\": \"$TIMESTAMP\",
  \"node_id\": \"$NODE_ID\",
  \"check_type\": \"score_tracking\"
}"

echo "$TRACK_DATA" >> "$TRACK_FILE"
echo "追踪数据已记录到 $TRACK_FILE" | tee -a "$LOG_FILE"

# 显示当前资产状态
echo "" | tee -a "$LOG_FILE"
echo "📦 当前资产状态:" | tee -a "$LOG_FILE"
./run-with-env.sh node scripts/a2a_export.js --json 2>/dev/null | jq '. | length' 2>/dev/null | \
  xargs -I {} echo "可导出资产数量: {}" | tee -a "$LOG_FILE"

echo "✅ 积分追踪完成" | tee -a "$LOG_FILE"
