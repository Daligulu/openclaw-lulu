# 📱 Telegram推送 - 快速配置指南

## 🎯 已完成的工作

### ✅ 脚本和工具就绪
1. **推送脚本**: `/root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh`
2. **工作流集成**: 已添加到`final-optimized-workflow.sh`
3. **测试摘要**: `/root/.openclaw/workspace/ai-hotspots/optimized/test-telegram-summary.md`
4. **配置指南**: 完整文档已创建

### ✅ 系统功能
- 自动从AI热点系统获取最新摘要
- 处理Telegram消息长度限制（≤4000字符）
- 支持多种发送方式（OpenClaw/API/Bot API）
- 错误处理和重试机制

## 🔧 需要你配置的内容

### 方法A: 使用OpenClaw Telegram插件（推荐）

#### 步骤1: 获取Bot Token
1. 在Telegram中联系 **@BotFather**
2. 发送 `/newbot` 创建新Bot
3. 设置Bot名称（如: `AI热点助手`）
4. 设置Bot用户名（如: `ai_hotspots_bot`）
5. **保存最后的Bot Token**（类似: `1234567890:ABCdefGhIJKlmNoPQRsTUVwxyZ`）

#### 步骤2: 获取Chat ID
1. 在Telegram中联系 **@userinfobot**
2. 发送任意消息
3. 获取你的 **Chat ID**（数字，如: `123456789`）

#### 步骤3: 配置OpenClaw
```bash
# 编辑配置文件
nano ~/.openclaw/config.json

# 添加Telegram配置
{
  "plugins": {
    "telegram": {
      "enabled": true,
      "botToken": "你的Bot Token",
      "allowedChatIds": ["你的Chat ID"]
    }
  }
}

# 重启服务
openclaw gateway restart
```

### 方法B: 使用环境变量（简单）

```bash
# 添加到 ~/.bashrc
export TELEGRAM_BOT_TOKEN="你的Bot Token"
export TELEGRAM_CHAT_ID="你的Chat ID"

# 立即生效
source ~/.bashrc
```

## 🧪 测试推送

### 测试命令
```bash
# 1. 测试脚本权限
chmod +x /root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh

# 2. 使用测试摘要
/root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh \
  /root/.openclaw/workspace/ai-hotspots/optimized/test-telegram-summary.md

# 3. 使用最新AI热点摘要
/root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh
```

### 测试完整工作流
```bash
# 运行完整优化工作流（包含Telegram推送）
/root/.openclaw/workspace/scripts/final-optimized-workflow.sh
```

## ⏰ 集成到定时任务

### 设置每天自动运行
```bash
# 进入脚本目录
cd /root/.openclaw/workspace/scripts

# 设置定时任务
chmod +x setup-cron-jobs.sh
./setup-cron-jobs.sh

# 查看定时任务
crontab -l | grep -A5 "AI热点"
```

### 定时任务时间（北京时间）
- **主要运行**: 每天 9:00 (UTC 1:00)
- **备用运行**: 每天 12:00 (UTC 4:00)
- **测试运行**: 每天 18:00 (UTC 10:00)

## 🔍 故障排除

### 如果推送失败

#### 1. 检查配置
```bash
# 检查环境变量
echo $TELEGRAM_BOT_TOKEN
echo $TELEGRAM_CHAT_ID

# 检查OpenClaw配置
cat ~/.openclaw/config.json | grep -i telegram
```

#### 2. 测试连接
```bash
# 测试Telegram API
curl -I https://api.telegram.org

# 测试Bot（替换YOUR_TOKEN）
curl "https://api.telegram.org/botYOUR_TOKEN/getMe"
```

#### 3. 查看日志
```bash
# OpenClaw日志
tail -f /var/log/openclaw.log

# AI热点日志
tail -f /var/log/ai-hotspots-*.log

# 推送脚本日志
/root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh 2>&1
```

### 常见问题

#### Q: Bot Token无效
- 重新从 @BotFather 获取
- 确保Bot已启动（发送 `/start`）
- 检查Token格式是否正确

#### Q: Chat ID错误
- 重新从 @userinfobot 获取
- 确保是数字格式
- 尝试发送消息给Bot看是否能收到

#### Q: 消息太长
- 脚本已自动截断（≤4000字符）
- 可以调整摘要长度
- 或启用分片发送

## 🚀 立即行动建议

### 第一步: 获取凭证（5分钟）
1. 联系 @BotFather 获取Bot Token
2. 联系 @userinfobot 获取Chat ID

### 第二步: 配置（2分钟）
```bash
# 方法A: 环境变量（简单）
export TELEGRAM_BOT_TOKEN="你的Token"
export TELEGRAM_CHAT_ID="你的ChatID"

# 或方法B: OpenClaw配置
编辑 ~/.openclaw/config.json
```

### 第三步: 测试（3分钟）
```bash
# 测试推送
/root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh
```

### 第四步: 自动化（2分钟）
```bash
# 设置定时任务
cd /root/.openclaw/workspace/scripts
./setup-cron-jobs.sh
```

## 📊 系统当前状态

### ✅ 已就绪
- AI热点收集系统（优化评分v2.0）
- 每日88+条高质量AI热点
- Telegram推送脚本
- 完整工作流自动化

### ⏰ 待完成
- [ ] 配置Telegram Bot Token
- [ ] 配置Chat ID
- [ ] 测试推送功能
- [ ] 设置定时任务

### 🎯 预期效果
- 每天9:00自动收集AI热点
- 自动生成优化评分报告
- 自动推送到Telegram
- 支持中文内容优先

## 💡 提示

### 消息格式优化
Telegram推送的内容来自`summary-*.md`文件，你可以调整报告生成脚本来优化格式。

### 多接收者支持
可以配置多个Chat ID，让多个用户/群组接收AI热点。

### 错误通知
可以配置当系统出错时发送错误通知到Telegram。

---
*配置时间: $(date '+%Y-%m-%d %H:%M:%S')*
*系统版本: AI热点系统 v2.0*
*下一步: 获取Bot Token和Chat ID后测试推送*