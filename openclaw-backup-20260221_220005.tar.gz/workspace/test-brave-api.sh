#!/bin/bash
# 测试Brave Search API

echo "🔍 测试Brave Search API..."
echo ""

API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
TEST_QUERY="AI breakthrough 2026"

echo "1. 测试API密钥有效性..."
curl -s -H "X-Subscription-Token: $API_KEY" \
  "https://api.search.brave.com/res/v1/web/search?q=test&count=1" \
  -o /tmp/brave-test.json

if [ $? -eq 0 ]; then
    echo "   ✅ API请求成功"
    # 检查响应
    if grep -q "search" /tmp/brave-test.json; then
        echo "   ✅ API响应正常"
        echo "   响应预览:"
        jq '.web.results[0].title' /tmp/brave-test.json 2>/dev/null || head -3 /tmp/brave-test.json
    else
        echo "   ⚠️  API响应异常:"
        head -5 /tmp/brave-test.json
    fi
else
    echo "   ❌ API请求失败"
fi
echo ""

echo "2. 测试技能中的Web搜索..."
cd /root/.openclaw/workspace/skills/tech-news-digest

# 创建最小测试配置
cat > /tmp/test-brave-config.yaml << 'EOF'
name: "test-brave"
sources:
  search:
    enabled: true
    provider: "brave"
    queries: ["AI breakthrough"]
    count: 3
EOF

# 运行Web搜索测试
echo "   运行Web搜索脚本..."
timeout 10 python3 scripts/fetch-web.py --config /tmp/test-brave-config.yaml --output /tmp/web-test.json 2>&1 | tail -10

if [ -f "/tmp/web-test.json" ]; then
    echo "   Web搜索结果文件已生成"
    ITEM_COUNT=$(jq '.items | length' /tmp/web-test.json 2>/dev/null || echo "0")
    echo "   获取到 $ITEM_COUNT 条Web结果"
else
    echo "   ⚠️  Web搜索可能失败"
fi
echo ""

echo "3. 检查技能配置..."
echo "   当前工作目录: $(pwd)"
echo "   Brave API密钥: ${BRAVE_API_KEY:0:10}..."
echo ""

echo "4. 手动测试搜索..."
cat > /tmp/test-brave-manual.py << 'EOF'
import os
import requests
import json

api_key = os.getenv("BRAVE_API_KEY", "BSAGhr7xYgJZubiYo6EW2SzTaXvifq_")
query = "AI最新进展 2026"

headers = {
    "X-Subscription-Token": api_key,
    "Accept": "application/json"
}

params = {
    "q": query,
    "count": 3,
    "country": "cn",
    "search_lang": "zh",
    "freshness": "pd"
}

try:
    response = requests.get(
        "https://api.search.brave.com/res/v1/web/search",
        headers=headers,
        params=params,
        timeout=10
    )
    
    print(f"状态码: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"找到 {data.get('web', {}).get('results', [])} 条结果")
        for i, result in enumerate(data.get('web', {}).get('results', [])[:3]):
            print(f"{i+1}. {result.get('title', '无标题')}")
            print(f"   {result.get('url', '无链接')}")
    else:
        print(f"错误: {response.text[:200]}")
        
except Exception as e:
    print(f"异常: {e}")
EOF

python3 /tmp/test-brave-manual.py
echo ""

echo "✅ 测试完成"
echo "如果Web搜索失败，可能需要:"
echo "1. 检查API密钥权限"
echo "2. 确认API密钥未过期"
echo "3. 检查网络连接"
echo "4. 验证技能配置格式"