# 第一阶段：AI科技新闻摘要实施计划

## 目标
建立AI领域的自动热点追踪系统，为内容创作提供实时热点信息。

## 时间安排
**预计完成时间**: 3-5天

## 具体步骤

### Day 1: 基础配置和API获取

#### 1.1 获取Brave Search API密钥
**目的**: 启用搜索功能，补充RSS源的不足
**步骤**:
1. 访问 https://brave.com/search/api/
2. 注册账户（免费层足够使用）
3. 获取API密钥
4. 设置环境变量:
```bash
export BRAVE_API_KEY="your_api_key_here"
# 永久保存到 ~/.bashrc
echo 'export BRAVE_API_KEY="your_api_key_here"' >> ~/.bashrc
```

#### 1.2 配置核心AI数据源
创建AI专用配置文件:

```yaml
# /root/.openclaw/workspace/ai-tech-config.yaml
name: "fengfeng-ai-digest"
schedule: "daily-9am"  # 每天9点运行
topics: ["ai", "llm", "tech"]

sources:
  rss:
    # 国际AI源
    - id: "openai-blog"
      url: "https://openai.com/blog/feed"
      name: "OpenAI Blog"
      priority: true
      topics: ["ai", "llm"]
      
    - id: "deepmind-blog"  
      url: "https://deepmind.google/blog/feed.xml"
      name: "DeepMind Blog"
      priority: true
      topics: ["ai"]
      
    - id: "anthropic-blog"
      url: "https://www.anthropic.com/index.xml"
      name: "Anthropic Blog"
      priority: true
      topics: ["ai", "llm"]
      
    - id: "hacker-news"
      url: "https://news.ycombinator.com/rss"
      name: "Hacker News"
      priority: true
      topics: ["ai", "tech"]
      
    # 国内AI源
    - id: "36kr"
      url: "https://36kr.com/feed"
      name: "36氪"
      priority: true
      topics: ["ai", "tech"]
      
    - id: "jiqizhixin"
      url: "https://www.jiqizhixin.com/rss"
      name: "机器之心"
      priority: true
      topics: ["ai"]
      
    - id: "leiphone"
      url: "https://www.leiphone.com/feed"
      name: "雷峰网"
      priority: true
      topics: ["ai", "tech"]
      
    - id: "aiyanxishe"
      url: "https://www.atyun.com/feed"
      name: "AI研习社"
      priority: true
      topics: ["ai"]

  search:
    queries:
      - "AI最新突破 2026"
      - "大语言模型发布"
      - "人工智能融资"
      - "AI创业公司"
      - "机器学习新算法"
    provider: "brave"
    region: "CN"  # 中国区结果

output:
  format: "markdown"
  channels:
    - type: "telegram"
      target: "personal"
    - type: "file"
      path: "/root/.openclaw/workspace/ai-hotspots/daily-{{date}}.md"

processing:
  max_items: 15
  min_score: 5
  deduplication: true
```

### Day 2: 测试和调试

#### 2.1 手动测试运行
```bash
cd /root/.openclaw/workspace/skills/tech-news-digest

# 测试运行
python3 scripts/run-pipeline.py \
  --config /root/.openclaw/workspace/ai-tech-config.yaml \
  --hours 24 \
  --output /tmp/ai-digest-test.json \
  --verbose
```

#### 2.2 验证输出
检查生成的文件:
1. `/tmp/ai-digest-test.json` - 原始数据
2. 转换为可读格式测试:
```bash
python3 scripts/generate-report.py \
  --input /tmp/ai-digest-test.json \
  --format markdown \
  --output /tmp/ai-digest-test.md
```

#### 2.3 发送到Telegram测试
创建测试发送脚本:
```bash
#!/bin/bash
# 发送测试摘要到Telegram
CONTENT=$(cat /tmp/ai-digest-test.md)
# 使用OpenClaw的message工具发送
```

### Day 3: 自动化调度

#### 3.1 创建每日运行脚本
```bash
#!/bin/bash
# /root/.openclaw/workspace/scripts/run-ai-digest.sh

# 设置环境
export BRAVE_API_KEY="your_key"
cd /root/.openclaw/workspace/skills/tech-news-digest

# 运行摘要
python3 scripts/run-pipeline.py \
  --config /root/.openclaw/workspace/ai-tech-config.yaml \
  --hours 24 \
  --output /tmp/ai-digest-$(date +%Y%m%d).json

# 生成报告
python3 scripts/generate-report.py \
  --input /tmp/ai-digest-$(date +%Y%m%d).json \
  --format markdown \
  --output /root/.openclaw/workspace/ai-hotspots/daily-$(date +%Y%m%d).md

# 发送到Telegram
# ... 发送逻辑
```

#### 3.2 设置定时任务
```bash
# 每天9:00运行（北京时间）
crontab -l | grep -v "run-ai-digest.sh"
(crontab -l 2>/dev/null; echo "0 1 * * * /root/.openclaw/workspace/scripts/run-ai-digest.sh >> /var/log/ai-digest.log 2>&1") | crontab -
```
*注意: UTC时间1:00 = 北京时间9:00*

### Day 4: 优化和扩展

#### 4.1 添加更多数据源
根据测试结果添加:
- GitHub AI项目releases
- AI论文预印本网站（arXiv）
- AI行业报告网站

#### 4.2 优化评分算法
调整`processing`配置:
```yaml
processing:
  scoring:
    priority_source: 3    # 优先源加分
    multi_source: 5       # 多源报道加分  
    recency: 2           # 时效性加分
    engagement: 1         # 互动量加分
    chinese_source: 2     # 中文源额外加分（针对国内读者）
```

#### 4.3 添加分类标签
```yaml
topics:
  - id: "ai-breakthrough"
    label: "AI突破"
    emoji: "🚀"
    
  - id: "llm-release"  
    label: "大模型发布"
    emoji: "🧠"
    
  - id: "ai-funding"
    label: "AI融资"
    emoji: "💰"
    
  - id: "ai-product"
    label: "AI产品"
    emoji: "🛠️"
```

### Day 5: 集成到内容创作流程

#### 5.1 创建热点分析脚本
```python
# 分析热点趋势，生成内容选题建议
# 输入: 每日摘要数据
# 输出: 3-5个内容选题建议
```

#### 5.2 集成到Content Agent
修改Content Agent的选题流程:
1. 先读取AI热点摘要
2. 基于热点生成选题
3. 优先处理高热度话题

#### 5.3 创建热点看板
```bash
# 生成热点趋势图表
# 显示过去7天热点变化
# 识别上升趋势话题
```

## 预期输出

### 每日AI热点摘要示例
```
📰 AI热点日报 | 2026-02-17

🔥 热点话题 (评分>8)
1. OpenAI发布GPT-5 API
   • 来源: OpenAI博客 + 36氪 + 机器之心
   • 热度: 9.5/10
   • 摘要: 支持128K上下文，价格降低50%
   
2. 中国AI公司深度求索获6亿美元融资
   • 来源: 36氪 + 雷峰网 + 搜索
   • 热度: 8.2/10
   • 摘要: 创今年AI领域最大单笔融资

📈 趋势上升 (评分6-8)
3. AI制药临床试验数量翻倍
4. 多模态大模型新突破

📊 数据统计
• 今日热点数: 15
• 高热度话题: 3
• 国内报道占比: 60%
• 国际报道占比: 40%
```

### 内容选题建议
基于热点自动生成:
```
基于今日热点，建议创作:

1. 【深度分析】GPT-5 API全面评测：128K上下文实战体验
   热点来源: OpenAI发布GPT-5
   内容方向: 技术细节 + 使用体验 + 成本分析
   
2. 【行业观察】6亿美元融资背后的中国AI崛起
   热点来源: 深度求索融资
   内容方向: 融资分析 + 行业趋势 + 竞争格局
   
3. 【技术解读】多模态大模型的最新突破与应用
   热点来源: 多模态研究进展
   内容方向: 技术原理 + 应用场景 + 未来展望
```

## 成功指标

### 技术指标
- [ ] 每日摘要自动生成成功率 > 95%
- [ ] 热点覆盖源数量 > 10个
- [ ] 数据处理时间 < 5分钟
- [ ] 系统正常运行时间 > 99%

### 内容指标  
- [ ] 热点发现及时性 < 2小时延迟
- [ ] 选题相关性评分 > 8/10
- [ ] 内容创作效率提升 > 50%
- [ ] 读者互动率提升 > 30%

## 风险与应对

### 技术风险
1. **API限制**: Brave Search免费版有调用限制
   - 应对: 缓存结果，合理设置查询频率
   
2. **源失效**: RSS源可能变更或失效
   - 应对: 定期检查源健康状态，备用源列表
   
3. **网络问题**: 国外源访问可能不稳定
   - 应对: 重试机制，使用代理（如需要）

### 内容风险
1. **信息过时**: 热点可能已过时
   - 应对: 强调时效性，快速处理高热度话题
   
2. **质量波动**: 自动摘要质量不稳定
   - 应对: 人工审核层，质量评分阈值调整

## 下一步准备

### 第二阶段（篮球领域）预研
开始收集篮球相关数据源:
- NBA官网RSS
- ESPN篮球新闻
- 虎扑篮球社区
- 国内篮球媒体

### 第三阶段（宠物领域）预研  
开始收集宠物相关数据源:
- 宠物行业媒体
- 动物保护组织
- 宠物食品品牌
- 兽医专业网站

## 总结

第一阶段聚焦AI领域，建立可用的热点追踪系统。成功后可以快速复制到篮球和宠物领域，最终形成完整的多领域热点监控网络。

**关键成功因素**:
1. 可靠的Brave Search API接入
2. 精心挑选的核心数据源
3. 合理的评分和过滤机制
4. 与现有工作流的顺畅集成

建议从获取Brave Search API密钥开始，这是启用搜索功能的关键一步。