#!/bin/bash
# Tech-News-Digest 心跳监控测试脚本

echo "=== Tech-News-Digest 心跳监控测试 ==="
echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"

# 切换到技能目录
cd /root/.openclaw/workspace/skills/tech-news-digest

# 运行pipeline（12小时窗口）
echo "运行tech-news-digest pipeline..."
python3 scripts/run-pipeline.py \
  --defaults config/defaults \
  --hours 12 \
  --freshness pd \
  --output /tmp/td-heartbeat-test.json \
  --verbose --force 2>&1 | tail -20

# 检查结果
if [ -f "/tmp/td-heartbeat-test.json" ]; then
    echo -e "\n=== 分析结果 ==="
    python3 -c "
import json
import sys
try:
    with open('/tmp/td-heartbeat-test.json', 'r') as f:
        data = json.load(f)
    
    total = data.get('output_stats', {}).get('total_articles', 0)
    topics = data.get('topics', [])
    
    print(f'总文章数: {total}')
    print(f'主题分布:')
    
    ai_count = 0
    crypto_count = 0
    other_count = 0
    
    for topic in topics:
        topic_id = topic.get('id', '')
        articles = topic.get('articles', [])
        count = len(articles)
        
        if topic_id in ['llm', 'ai-agent', 'frontier-tech']:
            ai_count += count
            print(f'  - AI相关 ({topic_id}): {count}篇')
        elif topic_id == 'crypto':
            crypto_count += count
            print(f'  - 加密货币: {count}篇')
        else:
            other_count += count
            print(f'  - 其他 ({topic_id}): {count}篇')
    
    print(f'\\n📊 热点统计:')
    print(f'  AI领域: {ai_count}条热点')
    print(f'  加密货币: {crypto_count}条热点')
    print(f'  其他领域: {other_count}条热点')
    
    # 检查是否有近12小时的热点
    if ai_count >= 3 or crypto_count >= 3:
        print('✅ 发现值得关注的选题热点')
        sys.exit(0)
    else:
        print('📝 无显著热点，继续监控')
        sys.exit(1)
        
except Exception as e:
    print(f'错误分析结果: {e}')
    sys.exit(1)
"
else
    echo "错误: 未生成输出文件"
    exit 1
fi

echo -e "\n完成时间: $(date '+%Y-%m-%d %H:%M:%S')"