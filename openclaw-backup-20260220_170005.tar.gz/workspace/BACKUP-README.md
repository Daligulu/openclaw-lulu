# OpenClaw 备份系统

## 概述
自动备份OpenClaw配置到GitHub仓库，支持定时备份和手动触发。

## 配置详情
- **备份脚本**: `/root/.openclaw/workspace/backup-openclaw.sh`
- **日志文件**: `/var/log/openclaw-backup.log`
- **GitHub仓库**: `https://github.com/Daligulu/openclaw-lulu`
- **时区设置**: 中国上海 (GMT+8)
- **定时任务**: 每天 7:00, 12:00, 17:00, 20:00 (北京时间)
  - UTC时间: 23:00, 4:00, 9:00, 12:00

## 使用方法

### 1. 手动备份
```bash
backup-openclaw
```

### 2. 查看备份日志
```bash
backup-openclaw-log  # 实时查看
tail -f /var/log/openclaw-backup.log  # 另一种方式
```

### 3. 管理定时任务
```bash
crontab -l  # 查看定时任务
crontab -e  # 编辑定时任务
```

### 4. 测试备份系统
```bash
/root/.openclaw/workspace/test-backup.sh
```

## 备份内容
### 包含的文件
- 所有配置文件 (`*.json`, `*.md`, `*.js`, `*.ts`, `*.sh`)
- 工作空间 (`workspace/`)
- 扩展配置 (`extensions/` 中的配置文件)
- 记忆文件 (`memory/`, `MEMORY.md`)
- 身份文件 (`SOUL.md`, `USER.md`, `IDENTITY.md`)
- 技能配置 (`skills/`)
- 其他关键目录

### 排除的文件（科学备份策略）
- 缓存文件 (`node_modules/`, `.cache/`, `tmp/`)
- 日志文件 (`*.log`)
- 大文件（超过10MB）
- 版本控制目录 (`.git/`)
- 临时文件

## 版本差异报告
每次备份推送时，脚本会自动生成版本差异报告，包括：

### 报告内容
1. **备份统计**
   - 前次备份时间和大小
   - 本次备份时间和大小  
   - 大小变化百分比

2. **关键文件状态**
   - 最近24小时修改的配置文件
   - 今日记忆记录行数
   - 身份文件更新状态

### 查看差异报告
- GitHub提交信息中包含完整差异报告
- 备份日志中记录变更概述
- 可通过Git历史查看详细变化

## 恢复OpenClaw
每个备份包都包含恢复脚本：

1. 下载备份文件从GitHub
2. 解压备份包
3. 运行恢复脚本：
```bash
cd /path/to/backup
./restore-openclaw.sh
```

恢复脚本会：
- 备份现有配置到 `/tmp/openclaw-pre-restore-时间戳.tar.gz`
- 恢复所有配置文件
- 提示重启OpenClaw服务

## 故障排除

### 1. 备份失败
```bash
# 检查日志
tail -100 /var/log/openclaw-backup.log

# 手动运行查看详细错误
cd /root/.openclaw/workspace
./backup-openclaw.sh
```

### 2. GitHub推送失败
- 检查GitHub令牌是否有效
- 检查网络连接
- 检查仓库权限

### 3. 备份文件过大
备份脚本已自动排除大文件，如果备份仍然过大：
```bash
# 查看备份大小
du -sh /tmp/openclaw-backup-*.tar.gz

# 手动调整排除规则
vim /root/.openclaw/workspace/backup-openclaw.sh
```

## 安全注意事项
1. **GitHub令牌**：存储在脚本中，确保仓库为私有
2. **备份文件**：包含敏感配置，GitHub仓库应为私有
3. **恢复脚本**：需要root权限，谨慎使用

## 更新备份系统
如需修改备份策略，编辑：
```bash
vim /root/.openclaw/workspace/backup-openclaw.sh
```

修改后重新加载bash配置：
```bash
source ~/.bashrc
```

## 监控
- 每日检查备份日志：`grep -E "(完成|失败|错误)" /var/log/openclaw-backup.log`
- 监控备份频率：`grep "备份开始" /var/log/openclaw-backup.log | wc -l`
- 检查备份大小：`ls -lh /tmp/openclaw-backup-*.tar.gz 2>/dev/null | tail -5`

---
*备份系统配置时间：2026-02-16*
*配置者：璐璐*