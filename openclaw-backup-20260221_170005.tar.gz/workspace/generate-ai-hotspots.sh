#!/bin/bash
# 生成AI热点摘要 - 立即可用版本

echo "🤖 生成AI热点摘要..."
echo ""

# 1. 合并数据文件
echo "1. 合并数据源..."
DATA_DIR="/tmp"
OUTPUT_FILE="/root/.openclaw/workspace/ai-hotspots/$(date +%Y%m%d).md"

mkdir -p /root/.openclaw/workspace/ai-hotspots

# 创建Python脚本处理数据
cat > /tmp/process-hotspots.py << 'EOF'
import json
import sys
from datetime import datetime, timedelta
import re

def load_json_file(filepath):
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except:
        return {"items": []}

def is_ai_related(title, description=""):
    """判断内容是否与AI相关"""
    ai_keywords = [
        'AI', '人工智能', '机器学习', '深度学习', '神经网络',
        'GPT', 'Claude', 'LLM', '大语言模型', '大模型',
        'OpenAI', 'DeepMind', 'Anthropic', '生成式AI',
        '计算机视觉', '自然语言处理', 'NLP', 'CV',
        '强化学习', 'transformer', 'diffusion'
    ]
    
    text = (title + " " + description).lower()
    for keyword in ai_keywords:
        if keyword.lower() in text:
            return True
    return False

def filter_ai_content(data):
    """过滤出AI相关内容"""
    ai_items = []
    
    if isinstance(data, dict) and 'items' in data:
        items = data['items']
    elif isinstance(data, list):
        items = data
    else:
        return ai_items
    
    for item in items:
        if not isinstance(item, dict):
            continue
            
        title = item.get('title', '')
        description = item.get('description', item.get('summary', ''))
        
        if is_ai_related(title, description):
            # 添加来源信息
            if 'source' not in item:
                item['source'] = 'unknown'
            ai_items.append(item)
    
    return ai_items

def generate_report(ai_items, output_file):
    """生成Markdown报告"""
    now = datetime.now()
    yesterday = now - timedelta(days=1)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"# 🔔 AI热点日报 | {now.strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"**数据时间**: {yesterday.strftime('%Y-%m-%d')} 至 {now.strftime('%Y-%m-%d')}\n")
        f.write(f"**热点数量**: {len(ai_items)}条\n\n")
        
        # 按来源统计
        sources = {}
        for item in ai_items:
            source = item.get('source', 'unknown')
            sources[source] = sources.get(source, 0) + 1
        
        f.write("## 📊 数据来源统计\n")
        for source, count in sorted(sources.items(), key=lambda x: x[1], reverse=True):
            f.write(f"- **{source}**: {count}条\n")
        f.write("\n")
        
        # 显示热点内容
        f.write("## 🎯 今日AI热点\n")
        
        displayed = 0
        for i, item in enumerate(ai_items[:20]):  # 最多显示20条
            title = item.get('title', '无标题')
            link = item.get('link', item.get('url', ''))
            date = item.get('date', '')
            source = item.get('source', '未知')
            
            # 清理标题
            title = re.sub(r'\s+', ' ', title).strip()
            
            f.write(f"### {i+1}. {title}\n")
            if date:
                f.write(f"**时间**: {date}\n")
            f.write(f"**来源**: {source}\n")
            
            if link:
                f.write(f"🔗 [阅读原文]({link})\n")
            
            f.write("\n")
            displayed += 1
        
        f.write(f"\n---\n")
        f.write(f"*生成时间: {now.strftime('%Y-%m-%d %H:%M:%S')}*\n")
        f.write(f"*数据源: RSS + Reddit | 过滤后AI内容: {len(ai_items)}条*\n")
    
    return displayed

# 主程序
if __name__ == "__main__":
    # 加载数据文件
    data_files = [
        "/tmp/td-rss.json",
        "/tmp/td-reddit.json", 
        "/tmp/td-github.json"
    ]
    
    all_ai_items = []
    
    for filepath in data_files:
        print(f"处理文件: {filepath}")
        data = load_json_file(filepath)
        
        # 确定来源
        source = "unknown"
        if "rss" in filepath:
            source = "RSS"
        elif "reddit" in filepath:
            source = "Reddit"
        elif "github" in filepath:
            source = "GitHub"
        
        ai_items = filter_ai_content(data)
        
        # 添加来源信息
        for item in ai_items:
            item['source'] = source
        
        all_ai_items.extend(ai_items)
        print(f"  找到 {len(ai_items)} 条AI相关内容")
    
    print(f"\n总计找到 {len(all_ai_items)} 条AI热点")
    
    # 生成报告
    output_file = sys.argv[1] if len(sys.argv) > 1 else "/tmp/ai-hotspots-report.md"
    displayed = generate_report(all_ai_items, output_file)
    
    print(f"报告已生成: {output_file}")
    print(f"显示 {displayed} 条热点")
EOF

# 2. 运行处理脚本
echo "2. 处理AI热点数据..."
python3 /tmp/process-hotspots.py "$OUTPUT_FILE"

# 3. 显示结果
echo ""
echo "3. 生成结果:"
if [ -f "$OUTPUT_FILE" ]; then
    echo "   报告文件: $OUTPUT_FILE"
    echo "   报告预览:"
    head -30 "$OUTPUT_FILE"
    
    # 统计
    TOTAL_LINES=$(wc -l < "$OUTPUT_FILE")
    AI_COUNT=$(grep -c "### " "$OUTPUT_FILE")
    echo ""
    echo "   📈 统计:"
    echo "   • 报告行数: $TOTAL_LINES"
    echo "   • AI热点数: $AI_COUNT"
else
    echo "   ❌ 报告生成失败"
fi

# 4. 创建每日运行脚本
echo ""
echo "4. 创建每日运行脚本..."
DAILY_SCRIPT="/root/.openclaw/workspace/scripts/daily-ai-hotspots.sh"

cat > "$DAILY_SCRIPT" << 'EOF'
#!/bin/bash
# 每日AI热点摘要脚本

echo "🤖 开始每日AI热点收集..."
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"

# 设置环境
export BRAVE_API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
cd /root/.openclaw/workspace/skills/tech-news-digest

# 1. 运行数据收集
echo "收集数据..."
python3 scripts/run-pipeline.py \
  --defaults /root/.openclaw/workspace/configs/ai-digest \
  --hours 24 \
  --output /tmp/daily-ai-digest.json \
  --verbose 2>&1 | grep -E "(items|Done)"

# 2. 生成热点报告
echo "生成报告..."
/root/.openclaw/workspace/scripts/generate-ai-hotspots.sh

# 3. 发送到Telegram（可选）
REPORT_FILE="/root/.openclaw/workspace/ai-hotspots/$(date +%Y%m%d).md"
if [ -f "$REPORT_FILE" ]; then
    echo "报告已生成: $REPORT_FILE"
    # 这里可以添加Telegram发送逻辑
else
    echo "警告: 报告文件未生成"
fi

echo "✅ 每日AI热点收集完成"
EOF

chmod +x "$DAILY_SCRIPT"
echo "   每日脚本: $DAILY_SCRIPT"

# 5. 设置定时任务建议
echo ""
echo "5. 定时任务建议:"
cat << 'EOF'
    # 每天9:00运行（北京时间）
    # UTC时间1:00 = 北京时间9:00
    0 1 * * * /root/.openclaw/workspace/scripts/daily-ai-hotspots.sh >> /var/log/ai-hotspots.log 2>&1
    
    设置命令:
    (crontab -l 2>/dev/null; echo "0 1 * * * /root/.openclaw/workspace/scripts/daily-ai-hotspots.sh >> /var/log/ai-hotspots.log 2>&1") | crontab -
EOF

echo ""
echo "✅ AI热点摘要系统 - 基础版本就绪"
echo "立即测试: cat $OUTPUT_FILE"
echo "每日运行: $DAILY_SCRIPT"