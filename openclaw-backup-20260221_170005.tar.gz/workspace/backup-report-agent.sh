#!/bin/bash
# OpenClaw备份报告生成脚本（Agent版本）
# 生成详细备份报告，由agent通过message工具推送

set -e

# 配置
BACKUP_SOURCE="/root/.openclaw"
BACKUP_DIR="/tmp/openclaw-backup"

# 时区设置（中国上海 GMT+8）
export TZ='Asia/Shanghai'

# 生成详细备份报告
generate_detailed_report() {
    echo "生成详细备份报告..."
    
    # 获取备份文件信息
    local latest_backup=$(find /tmp -name "openclaw-backup-*.tar.gz" -type f -mtime -1 2>/dev/null | sort -r | head -1)
    
    # 构建报告
    local report="📊 OpenClaw 备份详细报告\n"
    report+="=======================\n\n"
    
    report+="📅 报告时间: $(date '+%Y-%m-%d %H:%M:%S %Z')\n"
    report+="🌐 时区: 中国上海 (GMT+8)\n\n"
    
    report+="📁 备份概览\n"
    report+="---------\n"
    report+="• 备份源目录: $BACKUP_SOURCE\n"
    report+="• 备份时间: $(date '+%Y-%m-%d %H:%M:%S')\n"
    report+="• 备份策略: 智能排除（排除缓存和大文件）\n\n"
    
    report+="📈 文件统计\n"
    report+="---------\n"
    
    # 统计各目录文件数量
    if [ -d "$BACKUP_DIR" ]; then
        local workspace_count=$(find "$BACKUP_DIR/workspace" -type f 2>/dev/null | wc -l)
        local extensions_count=$(find "$BACKUP_DIR/extensions" -type f 2>/dev/null | wc -l)
        local agents_count=$(find "$BACKUP_DIR/agents" -type f 2>/dev/null | wc -l)
        local config_count=$(find "$BACKUP_DIR/config" -type f 2>/dev/null | wc -l)
        local memory_count=$(find "$BACKUP_DIR/memory" -type f 2>/dev/null | wc -l)
        
        report+="• workspace目录: ${workspace_count} 个文件\n"
        report+="• extensions目录: ${extensions_count} 个文件\n"
        report+="• agents目录: ${agents_count} 个文件\n"
        report+="• config目录: ${config_count} 个文件\n"
        report+="• memory目录: ${memory_count} 个文件\n"
    else
        report+="• 备份目录不存在，可能备份尚未完成\n"
    fi
    
    # 备份大小信息
    if [ -n "$latest_backup" ] && [ -f "$latest_backup" ]; then
        local backup_size=$(du -h "$latest_backup" 2>/dev/null | cut -f1 || echo "未知")
        local backup_name=$(basename "$latest_backup")
        report+="\n💾 备份文件信息\n"
        report+="--------------\n"
        report+="• 备份文件: $backup_name\n"
        report+="• 文件大小: $backup_size\n"
        report+="• 存储位置: /tmp/\n"
    fi
    
    # 关键文件状态
    report+="\n🔍 关键文件状态\n"
    report+="--------------\n"
    
    # 检查重要文件
    local important_files=(
        "workspace/SOUL.md"
        "workspace/MEMORY.md"
        "workspace/AGENTS.md"
        "workspace/IDENTITY.md"
        "workspace/USER.md"
        "openclaw.json"
    )
    
    for file in "${important_files[@]}"; do
        if [ -f "$BACKUP_SOURCE/$file" ]; then
            local file_size=$(du -h "$BACKUP_SOURCE/$file" 2>/dev/null | cut -f1 || echo "未知")
            local file_mtime=$(stat -c%y "$BACKUP_SOURCE/$file" 2>/dev/null | cut -d' ' -f1 || echo "未知")
            report+="• $file: $file_size (修改: $file_mtime)\n"
        else
            report+="• $file: ❌ 不存在\n"
        fi
    done
    
    # 记忆文件统计
    report+="\n🧠 记忆文件统计\n"
    report+="--------------\n"
    
    local today_memory="$BACKUP_SOURCE/workspace/memory/$(date '+%Y-%m-%d').md"
    if [ -f "$today_memory" ]; then
        local memory_lines=$(wc -l < "$today_memory" 2>/dev/null || echo "0")
        report+="• 今日记忆文件: ${memory_lines} 行\n"
    else
        report+="• 今日记忆文件: 尚未创建\n"
    fi
    
    # 统计最近7天的记忆文件
    local memory_count=$(find "$BACKUP_SOURCE/workspace/memory" -name "*.md" -mtime -7 2>/dev/null | wc -l)
    report+="• 最近7天记忆文件: ${memory_count} 个\n"
    
    # 备份完整性检查
    report+="\n✅ 备份完整性检查\n"
    report+="----------------\n"
    
    local missing_count=0
    local check_dirs=("workspace" "extensions" "agents" "config" "memory")
    
    for dir in "${check_dirs[@]}"; do
        if [ -d "$BACKUP_SOURCE/$dir" ]; then
            local source_count=$(find "$BACKUP_SOURCE/$dir" -type f \( -name "*.md" -o -name "*.json" -o -name "*.js" -o -name "*.sh" \) 2>/dev/null | wc -l)
            local backup_count=$(find "$BACKUP_DIR/$dir" -type f 2>/dev/null | wc -l)
            
            if [ "$backup_count" -eq 0 ]; then
                report+="• $dir: ⚠️  备份可能不完整 (源: $source_count 文件)\n"
                ((missing_count++))
            else
                report+="• $dir: ✅ 已备份 $backup_count/$source_count 个文件\n"
            fi
        fi
    done
    
    # 恢复说明
    report+="\n🔄 恢复说明\n"
    report+="----------\n"
    report+="• 恢复脚本: restore-openclaw.sh (包含在备份中)\n"
    report+="• 恢复命令: ./restore-openclaw.sh\n"
    report+="• 注意事项: 恢复前会自动备份现有配置\n"
    
    # 总结
    report+="\n📋 总结\n"
    report+="------\n"
    
    if [ "$missing_count" -eq 0 ]; then
        report+="✅ 备份完整性: 优秀\n"
    elif [ "$missing_count" -le 2 ]; then
        report+="⚠️  备份完整性: 良好 (${missing_count}个目录可能不完整)\n"
    else
        report+="❌ 备份完整性: 需要检查 (${missing_count}个目录可能不完整)\n"
    fi
    
    report+="• 报告生成时间: $(date '+%H:%M:%S')\n"
    report+="• 下次备份: 根据cron配置自动执行\n"
    
    echo "$report"
}

# 主函数
main() {
    echo "开始生成备份报告..."
    
    # 检查备份目录是否存在
    if [ ! -d "$BACKUP_DIR" ]; then
        echo "警告：备份目录不存在，可能备份尚未完成"
        echo "⚠️ OpenClaw备份报告：备份目录不存在，请检查备份任务是否正常运行。"
        return 1
    fi
    
    # 生成详细报告
    local report=$(generate_detailed_report)
    
    if [ -z "$report" ]; then
        echo "错误：报告生成失败"
        echo "❌ OpenClaw备份报告：报告生成失败，请检查系统日志。"
        return 1
    fi
    
    # 输出报告（由agent捕获并推送）
    echo "=== 备份报告开始 ==="
    echo "$report"
    echo "=== 备份报告结束 ==="
    
    echo "备份报告生成完成"
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi