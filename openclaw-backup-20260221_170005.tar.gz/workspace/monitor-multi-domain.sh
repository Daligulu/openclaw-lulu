#!/bin/bash
# 多领域热点系统监控脚本

echo "📊 多领域热点系统监控"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 1. 检查定时任务
echo "1. 定时任务状态:"
crontab -l | grep -E "(multi-domain|多领域热点)" | while read line; do
    echo "   ✅ $line"
done
echo ""

# 2. 检查日志文件
echo "2. 日志文件状态:"
LOG_DIR="/var/log/multi-domain-hotspots"
if [ -d "$LOG_DIR" ]; then
    echo "   日志目录: $LOG_DIR"
    LATEST_LOG=$(ls -t "$LOG_DIR"/*.log 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "   最新日志: $LATEST_LOG"
        echo "   文件大小: $(du -h "$LATEST_LOG" | cut -f1)"
        echo "   最后修改: $(stat -c %y "$LATEST_LOG" | cut -d'.' -f1)"
    else
        echo "   ⚠️  暂无日志文件"
    fi
else
    echo "   ❌ 日志目录不存在"
fi
echo ""

# 3. 检查输出文件
echo "3. 输出文件状态:"
OUTPUT_DIR="/root/.openclaw/workspace/multi-domain-hotspots"
if [ -d "$OUTPUT_DIR" ]; then
    echo "   输出目录: $OUTPUT_DIR"
    
    # 检查各领域
    for domain in ai basketball pets combined; do
        DOMAIN_DIR="$OUTPUT_DIR/$domain"
        if [ -d "$DOMAIN_DIR" ]; then
            FILE_COUNT=$(find "$DOMAIN_DIR" -name "*.md" 2>/dev/null | wc -l)
            echo "   $domain: $FILE_COUNT 个文件"
        else
            echo "   $domain: 目录不存在"
        fi
    done
else
    echo "   ❌ 输出目录不存在"
fi
echo ""

# 4. 检查配置
echo "4. 配置状态:"
CONFIG_DIR="/root/.openclaw/workspace/configs"
for domain in ai-digest-optimized basketball-digest pets-digest; do
    if [ -d "$CONFIG_DIR/$domain" ]; then
        CONFIG_COUNT=$(find "$CONFIG_DIR/$domain" -name "*.json" | wc -l)
        echo "   $domain: ✅ ($CONFIG_COUNT个配置文件)"
    else
        echo "   $domain: ❌ 未配置"
    fi
done
echo ""

# 5. Telegram状态
echo "5. Telegram状态:"
if [ -n "$TELEGRAM_BOT_TOKEN" ]; then
    echo "   ✅ Bot Token已配置"
else
    echo "   ⚠️  Bot Token未设置"
fi

if [ -n "$TELEGRAM_CHAT_ID" ]; then
    echo "   ✅ Chat ID已配置: $TELEGRAM_CHAT_ID"
else
    echo "   ⚠️  Chat ID未设置"
fi
echo ""

echo "📋 总结:"
echo "运行 'crontab -l' 查看定时任务"
echo "运行 '/root/.openclaw/workspace/scripts/multi-domain-workflow.sh' 手动运行"
