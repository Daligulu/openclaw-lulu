#!/bin/bash
# AI热点系统监控脚本

echo "📊 AI热点系统监控"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 1. 检查定时任务
echo "1. 定时任务状态:"
crontab -l | grep -E "(daily-ai-hotspots|AI热点)" | while read line; do
    echo "   ✅ $line"
done
echo ""

# 2. 检查日志文件
echo "2. 日志文件状态:"
LOG_DIR="/var/log/ai-hotspots"
if [ -d "$LOG_DIR" ]; then
    echo "   日志目录: $LOG_DIR"
    LATEST_LOG=$(ls -t "$LOG_DIR"/*.log 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "   最新日志: $LATEST_LOG"
        echo "   文件大小: $(du -h "$LATEST_LOG" | cut -f1)"
        echo "   最后修改: $(stat -c %y "$LATEST_LOG" | cut -d'.' -f1)"
        
        # 检查最近运行状态
        if tail -5 "$LATEST_LOG" | grep -q "执行完成"; then
            echo "   ✅ 最近运行成功"
        else
            echo "   ⚠️  最近运行状态未知"
        fi
    else
        echo "   ⚠️  暂无日志文件"
    fi
else
    echo "   ❌ 日志目录不存在"
fi
echo ""

# 3. 检查输出文件
echo "3. 输出文件状态:"
OUTPUT_DIR="/root/.openclaw/workspace/ai-hotspots"
if [ -d "$OUTPUT_DIR" ]; then
    echo "   输出目录: $OUTPUT_DIR"
    LATEST_REPORT=$(ls -t "$OUTPUT_DIR"/daily-*.md 2>/dev/null | head -1)
    if [ -n "$LATEST_REPORT" ]; then
        echo "   最新报告: $LATEST_REPORT"
        echo "   生成时间: $(stat -c %y "$LATEST_REPORT" | cut -d'.' -f1)"
        echo "   热点数量: $(grep -c "### " "$LATEST_REPORT" 2>/dev/null || echo "0")"
    else
        echo "   ⚠️  暂无报告文件"
    fi
    
    # 检查归档
    ARCHIVE_COUNT=$(find "$OUTPUT_DIR/archive" -name "*.json.gz" 2>/dev/null | wc -l)
    echo "   归档文件: $ARCHIVE_COUNT 个"
else
    echo "   ❌ 输出目录不存在"
fi
echo ""

# 4. 检查技能状态
echo "4. 技能状态:"
SKILL_DIR="/root/.openclaw/workspace/skills/tech-news-digest"
if [ -d "$SKILL_DIR" ]; then
    echo "   技能目录: $SKILL_DIR"
    if [ -f "$SKILL_DIR/SKILL.md" ]; then
        VERSION=$(grep "version:" "$SKILL_DIR/SKILL.md" | head -1 | cut -d'"' -f2)
        echo "   技能版本: $VERSION"
    fi
    
    # 检查Python依赖
    if python3 -c "import feedparser; import requests; print('✅ Python依赖正常')" 2>/dev/null; then
        echo "   ✅ Python依赖正常"
    else
        echo "   ⚠️  Python依赖可能有问题"
    fi
else
    echo "   ❌ 技能未安装"
fi
echo ""

# 5. API状态
echo "5. API状态:"
if [ -n "$BRAVE_API_KEY" ]; then
    echo "   ✅ Brave API密钥已配置"
    echo "   密钥: ${BRAVE_API_KEY:0:10}..."
else
    echo "   ⚠️  Brave API密钥未设置"
fi
echo ""

# 6. 系统资源
echo "6. 系统资源:"
echo "   磁盘空间:"
df -h /root | tail -1
echo "   内存使用:"
free -h | grep Mem
echo ""

echo "📋 总结:"
echo "运行 'crontab -l' 查看定时任务"
echo "运行 'tail -f /var/log/ai-hotspots/daily-*.log' 查看实时日志"
echo "运行 'cat /root/.openclaw/workspace/ai-hotspots/daily-*.md | head -30' 查看最新热点"
