#!/bin/bash

# 观猹平台EvoMap邀请码监控脚本
# 定期检查 https://watcha.cn/products/1464 是否有邀请码

WATCHA_URL="https://watcha.cn/products/1464"
LOG_FILE="/root/.openclaw/workspace/watcha-monitor.log"
STATE_FILE="/root/.openclaw/workspace/watcha-state.json"
LAST_CHECK_FILE="/root/.openclaw/workspace/watcha-last-check.txt"

# 创建日志和状态文件
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$STATE_FILE")"

# 记录日志
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
    echo "$1"
}

# 检查页面是否有变化
check_page() {
    local current_hash
    local last_hash
    
    # 获取页面内容并计算哈希
    current_hash=$(curl -s "$WATCHA_URL" | md5sum | cut -d' ' -f1)
    
    # 读取上次的哈希值
    if [ -f "$LAST_CHECK_FILE" ]; then
        last_hash=$(cat "$LAST_CHECK_FILE")
    else
        last_hash=""
    fi
    
    # 保存当前哈希
    echo "$current_hash" > "$LAST_CHECK_FILE"
    
    # 检查是否有变化
    if [ "$current_hash" != "$last_hash" ]; then
        if [ -n "$last_hash" ]; then
            log "🔔 页面内容发生变化！可能更新了邀请码"
            return 0  # 有变化
        else
            log "📝 首次检查，记录基准哈希值"
        fi
    else
        log "📊 页面无变化"
    fi
    
    return 1  # 无变化
}

# 尝试提取邀请码（基于常见模式）
extract_invite_code() {
    local content
    local invite_code
    
    # 获取页面内容
    content=$(curl -s "$WATCHA_URL")
    
    # 尝试查找邀请码（常见格式：大写字母+数字，通常4-8位）
    invite_code=$(echo "$content" | grep -o -E '[A-Z0-9]{4,8}' | head -1)
    
    if [ -n "$invite_code" ]; then
        # 检查是否是常见的邀请码格式
        if [[ "$invite_code" =~ ^[A-Z0-9]{4,8}$ ]] && [[ "$invite_code" != "WATCHA" ]] && [[ "$invite_code" != "PRODUCTS" ]]; then
            log "🎉 发现可能的邀请码: $invite_code"
            echo "$invite_code"
            return 0
        fi
    fi
    
    # 尝试查找包含"邀请码"、"invite"、"code"的文本
    invite_code=$(echo "$content" | grep -i -o -E '邀请码[：:]\s*[A-Z0-9]{4,8}' | grep -o -E '[A-Z0-9]{4,8}' | head -1)
    
    if [ -n "$invite_code" ]; then
        log "🎉 发现邀请码文本: $invite_code"
        echo "$invite_code"
        return 0
    fi
    
    return 1
}

# 发送Telegram通知
send_notification() {
    local message="$1"
    local invite_code="$2"
    
    # 使用OpenClaw的message工具发送通知
    if [ -n "$invite_code" ]; then
        /usr/bin/node /root/.nvm/versions/node/v22.22.0/lib/node_modules/openclaw/dist/cli.js message send \
            --channel telegram \
            --to "telegram:8375286112" \
            --message "🚨 观猹平台发现EvoMap邀请码！

🔑 **邀请码**: $invite_code
🔗 **平台地址**: https://watcha.cn/products/1464
⏰ **发现时间**: $(date '+%Y-%m-%d %H:%M:%S')

💡 **立即使用**:
1. 访问 https://evomap.ai
2. 点击右上角'注册'
3. 输入邮箱和邀请码: $invite_code
4. 验证邮箱激活账户
5. 绑定你的节点: https://evomap.ai/claim/J4W8-ZX79

🎯 节点已就绪:
- 节点ID: node_3cc2e7d88f02
- Claim Code: J4W8-ZX79
- 能力: 数据分析、CSV处理、统计分析、趋势检测、异常检测、报告生成

立即注册，开始使用EvoMap的AI基因网络！"
    else
        /usr/bin/node /root/.nvm/versions/node/v22.22.0/lib/node_modules/openclaw/dist/cli.js message send \
            --channel telegram \
            --to "telegram:8375286112" \
            --message "🔔 观猹平台页面发生变化！

📊 **监控通知**:
- 平台: 观猹 (https://watcha.cn/products/1464)
- 状态: 页面内容已更新
- 时间: $(date '+%Y-%m-%d %H:%M:%S')

⚠️ **可能更新了邀请码**，请立即访问查看！

💡 **建议操作**:
1. 手动访问: https://watcha.cn/products/1464
2. 查看是否有新的邀请码
3. 如有邀请码，立即注册EvoMap
4. 绑定你的节点: https://evomap.ai/claim/J4W8-ZX79

监控将持续进行，发现邀请码会自动通知。"
    fi
}

# 更新状态文件
update_state() {
    local status="$1"
    local invite_code="$2"
    
    # 计算统计信息 - 使用更简单的方法
    local no_change_count=0
    local change_count=0
    local invite_count=0
    
    if [ -f "$LOG_FILE" ]; then
        no_change_count=$(grep -c "页面无变化" "$LOG_FILE" 2>/dev/null || echo 0)
        change_count=$(grep -c "页面内容发生变化" "$LOG_FILE" 2>/dev/null || echo 0)
        invite_count=$(grep -c "发现邀请码" "$LOG_FILE" 2>/dev/null || echo 0)
    fi
    
    # 移除可能的换行符
    no_change_count=$(echo "$no_change_count" | tr -d '\n')
    change_count=$(echo "$change_count" | tr -d '\n')
    invite_count=$(echo "$invite_count" | tr -d '\n')
    
    # 使用bc进行算术运算，避免bash算术问题
    local total_checks=$(echo "$no_change_count + $change_count" | bc)
    
    cat > "$STATE_FILE" << EOF
{
  "last_check": "$(date '+%Y-%m-%d %H:%M:%S')",
  "status": "$status",
  "invite_code": "$invite_code",
  "watcha_url": "$WATCHA_URL",
  "total_checks": "$total_checks",
  "changes_detected": "$change_count",
  "invite_codes_found": "$invite_count"
}
EOF
}

# 主监控函数
main() {
    log "🔍 开始检查观猹平台: $WATCHA_URL"
    
    # 检查页面是否有变化
    if check_page; then
        log "🔄 页面有变化，尝试提取邀请码"
        
        # 尝试提取邀请码
        invite_code=$(extract_invite_code)
        
        if [ -n "$invite_code" ]; then
            log "✅ 成功提取到邀请码: $invite_code"
            
            # 发送通知
            send_notification "found" "$invite_code"
            
            # 更新状态
            update_state "invite_code_found" "$invite_code"
            
            # 保存邀请码到文件
            echo "$invite_code" > "/root/.openclaw/workspace/evomap-invite-code.txt"
            
            log "📨 已发送邀请码通知"
        else
            log "⚠️ 页面有变化但未找到邀请码，发送变化通知"
            
            # 发送页面变化通知
            send_notification "changed" ""
            
            # 更新状态
            update_state "page_changed" ""
            
            log "📨 已发送页面变化通知"
        fi
    else
        log "📊 页面无变化，继续监控"
        update_state "no_change" ""
    fi
    
    log "✅ 监控检查完成"
}

# 执行主函数
main