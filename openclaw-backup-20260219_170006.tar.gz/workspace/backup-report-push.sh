#!/bin/bash
# OpenClaw备份报告推送脚本
# 在备份完成后自动生成详细报告并推送到Telegram

set -e

# 配置
LOG_FILE="/var/log/openclaw-backup.log"
TELEGRAM_CHAT_ID="8375286112"
BACKUP_SOURCE="/root/.openclaw"
BACKUP_DIR="/tmp/openclaw-backup"

# 时区设置（中国上海 GMT+8）
export TZ='Asia/Shanghai'

# 颜色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S %Z') - $1" | tee -a "$LOG_FILE"
}

# 生成详细备份报告
generate_detailed_report() {
    log "生成详细备份报告..."
    
    local report_file="/tmp/openclaw-backup-report-$(date '+%Y%m%d_%H%M%S').txt"
    
    # 获取备份文件信息
    local latest_backup=$(find /tmp -name "openclaw-backup-*.tar.gz" -type f -mtime -1 | sort -r | head -1)
    
    # 构建报告
    cat > "$report_file" << EOF
📊 OpenClaw 备份详细报告
=======================

📅 报告时间: $(date '+%Y-%m-%d %H:%M:%S %Z')
🌐 时区: 中国上海 (GMT+8)

📁 备份概览
---------
• 备份源目录: $BACKUP_SOURCE
• 备份时间: $(date '+%Y-%m-%d %H:%M:%S')
• 备份策略: 智能排除（排除缓存和大文件）

📈 文件统计
---------
EOF
    
    # 统计各目录文件数量
    if [ -d "$BACKUP_DIR" ]; then
        echo "• workspace目录: $(find "$BACKUP_DIR/workspace" -type f 2>/dev/null | wc -l) 个文件" >> "$report_file"
        echo "• extensions目录: $(find "$BACKUP_DIR/extensions" -type f 2>/dev/null | wc -l) 个文件" >> "$report_file"
        echo "• agents目录: $(find "$BACKUP_DIR/agents" -type f 2>/dev/null | wc -l) 个文件" >> "$report_file"
        echo "• config目录: $(find "$BACKUP_DIR/config" -type f 2>/dev/null | wc -l) 个文件" >> "$report_file"
        echo "• memory目录: $(find "$BACKUP_DIR/memory" -type f 2>/dev/null | wc -l) 个文件" >> "$report_file"
    fi
    
    # 备份大小信息
    if [ -n "$latest_backup" ] && [ -f "$latest_backup" ]; then
        local backup_size=$(du -h "$latest_backup" | cut -f1)
        local backup_name=$(basename "$latest_backup")
        echo "" >> "$report_file"
        echo "💾 备份文件信息" >> "$report_file"
        echo "--------------" >> "$report_file"
        echo "• 备份文件: $backup_name" >> "$report_file"
        echo "• 文件大小: $backup_size" >> "$report_file"
        echo "• 存储位置: /tmp/" >> "$report_file"
    fi
    
    # 关键文件状态
    echo "" >> "$report_file"
    echo "🔍 关键文件状态" >> "$report_file"
    echo "--------------" >> "$report_file"
    
    # 检查重要文件
    local important_files=(
        "workspace/SOUL.md"
        "workspace/MEMORY.md"
        "workspace/AGENTS.md"
        "workspace/IDENTITY.md"
        "workspace/USER.md"
        "openclaw.json"
    )
    
    for file in "${important_files[@]}"; do
        if [ -f "$BACKUP_SOURCE/$file" ]; then
            local file_size=$(du -h "$BACKUP_SOURCE/$file" | cut -f1)
            local file_mtime=$(stat -c%y "$BACKUP_SOURCE/$file" 2>/dev/null | cut -d' ' -f1)
            echo "• $file: $file_size (修改: $file_mtime)" >> "$report_file"
        else
            echo "• $file: ❌ 不存在" >> "$report_file"
        fi
    done
    
    # 记忆文件统计
    echo "" >> "$report_file"
    echo "🧠 记忆文件统计" >> "$report_file"
    echo "--------------" >> "$report_file"
    
    local today_memory="$BACKUP_SOURCE/workspace/memory/$(date '+%Y-%m-%d').md"
    if [ -f "$today_memory" ]; then
        local memory_lines=$(wc -l < "$today_memory")
        echo "• 今日记忆文件: ${memory_lines} 行" >> "$report_file"
    else
        echo "• 今日记忆文件: 尚未创建" >> "$report_file"
    fi
    
    # 统计最近7天的记忆文件
    local memory_count=$(find "$BACKUP_SOURCE/workspace/memory" -name "*.md" -mtime -7 2>/dev/null | wc -l)
    echo "• 最近7天记忆文件: ${memory_count} 个" >> "$report_file"
    
    # 备份完整性检查
    echo "" >> "$report_file"
    echo "✅ 备份完整性检查" >> "$report_file"
    echo "----------------" >> "$report_file"
    
    local missing_count=0
    local check_dirs=("workspace" "extensions" "agents" "config" "memory")
    
    for dir in "${check_dirs[@]}"; do
        if [ -d "$BACKUP_SOURCE/$dir" ]; then
            local source_count=$(find "$BACKUP_SOURCE/$dir" -type f -name "*.md" -o -name "*.json" -o -name "*.js" -o -name "*.sh" | wc -l)
            local backup_count=$(find "$BACKUP_DIR/$dir" -type f 2>/dev/null | wc -l)
            
            if [ "$backup_count" -eq 0 ]; then
                echo "• $dir: ⚠️  备份可能不完整 (源: $source_count 文件)" >> "$report_file"
                ((missing_count++))
            else
                echo "• $dir: ✅ 已备份 $backup_count/$source_count 个文件" >> "$report_file"
            fi
        fi
    done
    
    # 恢复说明
    echo "" >> "$report_file"
    echo "🔄 恢复说明" >> "$report_file"
    echo "----------" >> "$report_file"
    echo "• 恢复脚本: restore-openclaw.sh (包含在备份中)" >> "$report_file"
    echo "• 恢复命令: ./restore-openclaw.sh" >> "$report_file"
    echo "• 注意事项: 恢复前会自动备份现有配置" >> "$report_file"
    
    # 总结
    echo "" >> "$report_file"
    echo "📋 总结" >> "$report_file"
    echo "------" >> "$report_file"
    
    if [ "$missing_count" -eq 0 ]; then
        echo "✅ 备份完整性: 优秀" >> "$report_file"
    elif [ "$missing_count" -le 2 ]; then
        echo "⚠️  备份完整性: 良好 (${missing_count}个目录可能不完整)" >> "$report_file"
    else
        echo "❌ 备份完整性: 需要检查 (${missing_count}个目录可能不完整)" >> "$report_file"
    fi
    
    echo "• 报告生成时间: $(date '+%H:%M:%S')" >> "$report_file"
    echo "• 下次备份: 根据cron配置自动执行" >> "$report_file"
    
    echo "$report_file"
}

# 推送报告到Telegram
push_to_telegram() {
    local report_file="$1"
    
    if [ ! -f "$report_file" ]; then
        log "错误：报告文件不存在: $report_file"
        return 1
    fi
    
    log "推送报告到Telegram..."
    
    # 读取报告内容
    local report_content=$(cat "$report_file")
    
    # 由于Telegram消息长度限制（4096字符），我们需要分割长消息
    local max_length=4000
    local report_length=${#report_content}
    
    if [ "$report_length" -le "$max_length" ]; then
        # 单条消息发送
        /root/.nvm/versions/node/v22.22.0/bin/openclaw message send --channel telegram --to "$TELEGRAM_CHAT_ID" --message "$report_content"
    else
        # 分割消息发送
        local part_num=1
        local current_pos=0
        
        while [ "$current_pos" -lt "$report_length" ]; do
            local part_content="${report_content:$current_pos:$max_length}"
            
            # 添加分页标识
            local part_header="📄 备份报告 (第${part_num}部分)"
            local full_part="$part_header\n\n$part_content"
            
            /root/.nvm/versions/node/v22.22.0/bin/openclaw message send --channel telegram --to "$TELEGRAM_CHAT_ID" --message "$full_part"
            
            ((current_pos += max_length))
            ((part_num++))
            sleep 1  # 避免发送过快
        done
    fi
    
    log "报告已推送到Telegram"
    
    # 清理报告文件
    rm -f "$report_file"
}

# 主函数
main() {
    log "开始生成并推送备份报告..."
    
    # 检查备份目录是否存在
    if [ ! -d "$BACKUP_DIR" ]; then
        log "警告：备份目录不存在，可能备份尚未完成"
        /root/.nvm/versions/node/v22.22.0/bin/openclaw message send --channel telegram --to "$TELEGRAM_CHAT_ID" --message "⚠️ OpenClaw备份报告：备份目录不存在，请检查备份任务是否正常运行。"
        return 1
    fi
    
    # 生成详细报告
    local report_file=$(generate_detailed_report)
    
    if [ -z "$report_file" ] || [ ! -f "$report_file" ]; then
        log "错误：报告生成失败"
        /root/.nvm/versions/node/v22.22.0/bin/openclaw message send --channel telegram --to "$TELEGRAM_CHAT_ID" --message "❌ OpenClaw备份报告：报告生成失败，请检查系统日志。"
        return 1
    fi
    
    # 推送报告
    push_to_telegram "$report_file"
    
    log "备份报告推送完成"
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi