#!/bin/bash

# 快速状态检查
NODE_ID="node_d11440709e39"
echo "🚀 EvoMap节点快速状态检查"
echo "========================================"
echo "检查时间: $(date)"
echo "节点ID: $NODE_ID"
echo "========================================"

# 1. 检查节点信息
echo -e "\n1. 📡 检查节点信息..."
NODE_INFO=$(curl -s "https://evomap.ai/a2a/nodes/$NODE_ID" 2>/dev/null)

if [ -n "$NODE_INFO" ]; then
    LAST_SEEN=$(echo "$NODE_INFO" | grep -o '"last_seen_at":"[^"]*"' | cut -d'"' -f4)
    REPUTATION=$(echo "$NODE_INFO" | grep -o '"reputation_score":[0-9]*' | cut -d':' -f2)
    
    if [ -n "$LAST_SEEN" ]; then
        echo "✅ 最后在线时间: $LAST_SEEN"
        
        # 计算时间差
        LAST_SEEN_TS=$(date -d "$LAST_SEEN" +%s 2>/dev/null || echo "0")
        CURRENT_TS=$(date +%s)
        TIME_DIFF=$((CURRENT_TS - LAST_SEEN_TS))
        
        if [ "$TIME_DIFF" -lt 300 ]; then  # 5分钟内
            echo "🎉 状态: 在线 (${TIME_DIFF}秒前)"
        elif [ "$TIME_DIFF" -lt 1800 ]; then  # 30分钟内
            echo "⚠️  状态: 可能在线 (${TIME_DIFF}秒前)"
        else
            echo "❌ 状态: 离线 (${TIME_DIFF}秒前)"
        fi
    else
        echo "❌ 无法获取最后在线时间"
    fi
    
    if [ -n "$REPUTATION" ]; then
        echo "📊 声誉分数: $REPUTATION"
    fi
else
    echo "❌ 无法获取节点信息"
fi

# 2. 发送测试消息
echo -e "\n2. 📤 发送测试消息..."
cd /root/.openclaw/workspace/evolver
export A2A_TRANSPORT="http"
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="$NODE_ID"

TEST_OUTPUT=$(timeout 15 node scripts/a2a_export.js --hello --protocol --persist 2>&1 | tail -2)

if echo "$TEST_OUTPUT" | grep -q "protocol"; then
    echo "✅ 测试消息发送成功"
    MESSAGE_TIME=$(echo "$TEST_OUTPUT" | grep '"timestamp"' | tail -1 | grep -o '"timestamp":"[^"]*"' | cut -d'"' -f4)
    if [ -n "$MESSAGE_TIME" ]; then
        echo "   • 最后消息: $MESSAGE_TIME"
    fi
else
    echo "❌ 测试消息发送失败"
fi

# 3. 检查监控状态
echo -e "\n3. 📈 监控状态..."
if [ -f "/root/.openclaw/workspace/evolver/continuous-monitor.log" ]; then
    LAST_MONITOR=$(tail -5 "/root/.openclaw/workspace/evolver/continuous-monitor.log" | grep "检查 #" | tail -1)
    if [ -n "$LAST_MONITOR" ]; then
        echo "✅ 持续监控运行中"
        echo "   • $LAST_MONITOR"
    else
        echo "⚠️  监控日志存在但无最新记录"
    fi
else
    echo "❌ 监控日志文件不存在"
fi

# 4. 检查进程
echo -e "\n4. 🔄 进程状态..."
MONITOR_PID=$(ps aux | grep continuous-monitor | grep -v grep | awk '{print $2}')
if [ -n "$MONITOR_PID" ]; then
    echo "✅ 监控进程运行中 (PID: $MONITOR_PID)"
else
    echo "❌ 监控进程未运行"
fi

echo -e "\n========================================"
echo "🎯 建议:"
echo "1. 等待EvoMap Hub更新状态（可能需要几分钟）"
echo "2. 监控脚本将持续检查状态变化"
echo "3. 查看完整日志: /root/.openclaw/workspace/evolver/continuous-monitor.log"
echo "========================================"