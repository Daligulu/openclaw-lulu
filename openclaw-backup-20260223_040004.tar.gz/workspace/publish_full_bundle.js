const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// 读取Capsule资产
const capsulesPath = path.join(__dirname, 'assets/gep/capsules.json');
const capsulesData = JSON.parse(fs.readFileSync(capsulesPath, 'utf8'));

// 读取Gene资产
const genesPath = path.join(__dirname, 'assets/gep/genes.json');
const genesData = JSON.parse(fs.readFileSync(genesPath, 'utf8'));

// 读取EvolutionEvent资产
const eventsPath = path.join(__dirname, 'assets/gep/events.jsonl');
const eventsContent = fs.readFileSync(eventsPath, 'utf8');
const events = eventsContent.trim().split('\n').map(line => JSON.parse(line));

console.log(`准备发布完整资产包:`);
console.log(`- Gene数量: ${genesData.genes.length}`);
console.log(`- Capsule数量: ${capsulesData.capsules.length}`);
console.log(`- EvolutionEvent数量: ${events.length}`);

// 生成协议消息
function generateMessage(type, payload) {
  const timestamp = new Date().toISOString();
  const messageId = `msg_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  
  return {
    protocol: "gep-a2a",
    protocol_version: "1.0.0",
    message_type: type,
    message_id: messageId,
    sender_id: process.env.A2A_SENDER_ID || "node_d11440709e39",
    timestamp: timestamp,
    payload: payload
  };
}

// 发布Gene资产
console.log('\n=== 发布Gene资产 ===');
genesData.genes.forEach((gene, index) => {
  const message = generateMessage("publish", {
    asset_type: "Gene",
    asset_id: gene.asset_id,
    local_id: gene.id,
    asset: gene
  });
  console.log(JSON.stringify(message, null, 2));
  if (index < genesData.genes.length - 1) console.log(',');
});

// 发布Capsule资产
console.log('\n=== 发布Capsule资产 ===');
capsulesData.capsules.forEach((capsule, index) => {
  const message = generateMessage("publish", {
    asset_type: "Capsule",
    asset_id: capsule.asset_id,
    local_id: capsule.id,
    asset: capsule
  });
  console.log(JSON.stringify(message, null, 2));
  if (index < capsulesData.capsules.length - 1) console.log(',');
});

// 发布EvolutionEvent资产
console.log('\n=== 发布EvolutionEvent资产 ===');
events.forEach((event, index) => {
  const message = generateMessage("publish", {
    asset_type: "EvolutionEvent",
    asset_id: event.asset_id,
    local_id: event.id,
    asset: event
  });
  console.log(JSON.stringify(message, null, 2));
  if (index < events.length - 1) console.log(',');
});

console.log('\n✅ 完整资产包生成完成！');
