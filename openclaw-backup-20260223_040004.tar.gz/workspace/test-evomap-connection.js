#!/usr/bin/env node

// 测试与EvoMap Hub的直接连接
const https = require('https');

const NODE_ID = 'node_d11440709e39';
const CLAIM_CODE = '55F5CE2A';

// 生成消息ID
function generateMessageId() {
  return 'msg_' + Date.now() + '_' + require('crypto').randomBytes(4).toString('hex');
}

// 构建hello消息
const helloMessage = {
  protocol: 'gep-a2a',
  protocol_version: '1.0.0',
  message_type: 'hello',
  message_id: generateMessageId(),
  sender_id: NODE_ID,
  timestamp: new Date().toISOString(),
  payload: {
    capabilities: {},
    gene_count: 3,
    capsule_count: 2,
    env_fingerprint: {
      platform: 'linux',
      arch: 'x64',
      node_version: process.version,
      hostname: require('os').hostname()
    }
  }
};

console.log('🚀 测试连接到EvoMap Hub');
console.log('========================================');
console.log('节点ID:', NODE_ID);
console.log('认领码:', CLAIM_CODE);
console.log('Hub URL: https://evomap.ai');
console.log('========================================\n');

console.log('📤 发送hello消息到EvoMap Hub...');
console.log('消息内容:');
console.log(JSON.stringify(helloMessage, null, 2));

// 发送请求到EvoMap Hub
const postData = JSON.stringify(helloMessage);

const options = {
  hostname: 'evomap.ai',
  port: 443,
  path: '/a2a/hello',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  },
  timeout: 30000 // 30秒超时
};

console.log('\n🔗 发送请求到: https://evomap.ai/a2a/hello');

const req = https.request(options, (res) => {
  console.log('\n📥 收到响应:');
  console.log('状态码:', res.statusCode);
  console.log('状态消息:', res.statusMessage);
  console.log('响应头:', JSON.stringify(res.headers, null, 2));

  let data = '';
  
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('\n📋 响应体:');
    try {
      const parsed = JSON.parse(data);
      console.log(JSON.stringify(parsed, null, 2));
      
      if (res.statusCode === 200 || res.statusCode === 201) {
        console.log('\n✅ 连接成功！节点已注册到EvoMap Hub');
        if (parsed.claim_code) {
          console.log('🎯 认领码:', parsed.claim_code);
          console.log('🔗 认领URL:', parsed.claim_url || `https://evomap.ai/claim/${parsed.claim_code}`);
        }
        if (parsed.hub_node_id) {
          console.log('🏢 Hub节点ID:', parsed.hub_node_id);
        }
      } else {
        console.log('\n❌ 连接失败，状态码:', res.statusCode);
      }
    } catch (e) {
      console.log('原始响应:', data);
      console.log('\n⚠️ 无法解析JSON响应:', e.message);
    }
    
    console.log('\n========================================');
    console.log('连接测试完成');
  });
});

req.on('error', (err) => {
  console.log('\n❌ 请求错误:', err.message);
  console.log('可能的原因:');
  console.log('1. 网络连接问题');
  console.log('2. EvoMap Hub暂时不可用');
  console.log('3. 防火墙或代理设置');
  console.log('4. DNS解析问题');
  
  console.log('\n🔧 故障排除建议:');
  console.log('1. 检查网络连接: ping evomap.ai');
  console.log('2. 检查Hub状态: curl -I https://evomap.ai');
  console.log('3. 验证节点ID和认领码是否正确');
});

req.on('timeout', () => {
  console.log('\n⏰ 请求超时 (30秒)');
  req.destroy();
});

req.write(postData);
req.end();