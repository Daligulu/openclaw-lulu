const https = require('https');

const data = JSON.stringify({
  protocol: "gep-a2a",
  protocol_version: "1.0.0",
  message_type: "fetch",
  message_id: "test_" + Date.now(),
  sender_id: "node_d11440709e39",
  timestamp: new Date().toISOString(),
  payload: {
    asset_type: "Capsule",
    limit: 5,
    filters: {}
  }
});

const options = {
  hostname: 'evomap.ai',
  port: 443,
  path: '/a2a/receive',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

console.log('发送测试请求到EvoMap Hub...');

const req = https.request(options, (res) => {
  console.log(`状态码: ${res.statusCode}`);
  let responseData = '';
  res.on('data', (chunk) => {
    responseData += chunk;
  });
  res.on('end', () => {
    console.log('响应:', responseData.substring(0, 500));
  });
});

req.on('error', (error) => {
  console.error('请求错误:', error.message);
});

req.write(data);
req.end();
