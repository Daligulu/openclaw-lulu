#!/bin/bash
# EvoMap完整集成脚本

cd /root/.openclaw/workspace

echo "🔗 EvoMap集成脚本启动"
echo "================================"
echo "📋 账户信息："
echo "  - 用户邮箱: gaojunfeng1108@gmail.com"
echo "  - 节点ID: node_d11440709e39"
echo "  - 邀请码: 55F5CE2A"
echo "  - 认领码: J4W8-ZX79"
echo "  - 认领URL: https://evomap.ai/claim/J4W8-ZX79"
echo ""

# 1. 检查evolver
if [ ! -d "evolver" ]; then
    echo "❌ 错误：evolver目录不存在"
    exit 1
fi

cd evolver

# 2. 设置环境变量
export A2A_HUB_URL=https://evomap.ai
export A2A_SENDER_ID=node_d11440709e39
export A2A_NODE_ID=node_d11440709e39
export A2A_CLAIM_CODE=55F5CE2A
export AGENT_NAME=璐璐

# 3. 检查参数
MODE=${1:-"test"}
case $MODE in
    "test")
        echo "🧪 测试模式：验证EvoMap连接"
        echo ""
        echo "1. 发送hello消息注册节点..."
        node scripts/a2a_export.js --hello --json
        echo ""
        echo "2. 导出可发布的资产..."
        node scripts/a2a_export.js --json | head -5
        ;;
    "hello")
        echo "👋 发送hello消息注册节点"
        node scripts/a2a_export.js --hello --protocol --persist
        ;;
    "export")
        echo "📤 导出资产到EvoMap"
        node scripts/a2a_export.js --protocol --persist --include-events
        ;;
    "loop")
        echo "🔄 启动循环模式（每4小时）"
        echo "按Ctrl+C停止"
        while true; do
            echo ""
            echo "⏰ $(date '+%Y-%m-%d %H:%M:%S') - 开始EvoMap同步循环"
            echo "1. 发送hello消息..."
            node scripts/a2a_export.js --hello --protocol --persist
            echo "2. 导出资产..."
            node scripts/a2a_export.js --protocol --persist --include-events
            echo "3. 等待4小时..."
            sleep 14400  # 4小时
        done
        ;;
    "cron")
        echo "⏰ 单次cron执行"
        echo "1. 发送hello消息..."
        node scripts/a2a_export.js --hello --protocol --persist
        echo "2. 导出资产..."
        node scripts/a2a_export.js --protocol --persist --include-events
        ;;
    *)
        echo "用法: $0 [test|hello|export|loop|cron]"
        echo "  test   - 测试连接和配置"
        echo "  hello  - 发送hello消息注册节点"
        echo "  export - 导出资产到EvoMap"
        echo "  loop   - 启动4小时循环模式"
        echo "  cron   - 单次执行（用于cron job）"
        exit 1
        ;;
esac

echo ""
echo "✅ EvoMap集成脚本执行完成"