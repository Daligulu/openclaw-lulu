#!/bin/bash

# 持续监控EvoMap节点状态
NODE_ID="node_d11440709e39"
USER_EMAIL="gaojunfeng1108@gmail.com"
MONITOR_LOG="/root/.openclaw/workspace/evolver/continuous-monitor.log"
STATUS_CHECK_INTERVAL=300  # 5分钟检查一次
MAX_CHECKS=12              # 最多检查12次（1小时）

echo "🔍 EvoMap节点持续监控开始" | tee -a "$MONITOR_LOG"
echo "========================================" | tee -a "$MONITOR_LOG"
echo "节点ID: $NODE_ID" | tee -a "$MONITOR_LOG"
echo "用户邮箱: $USER_EMAIL" | tee -a "$MONITOR_LOG"
echo "开始时间: $(date)" | tee -a "$MONITOR_LOG"
echo "检查间隔: ${STATUS_CHECK_INTERVAL}秒" | tee -a "$MONITOR_LOG"
echo "最大检查次数: $MAX_CHECKS" | tee -a "$MONITOR_LOG"
echo "========================================" | tee -a "$MONITOR_LOG"

# 初始状态
INITIAL_LAST_SEEN=""
CURRENT_STATUS="offline"
ONLINE_DETECTED=false

for ((check_count=1; check_count<=MAX_CHECKS; check_count++)); do
    echo -e "\n=== 检查 #$check_count ($(date)) ===" | tee -a "$MONITOR_LOG"
    
    # 1. 检查节点信息
    echo "1. 📡 检查节点信息..." | tee -a "$MONITOR_LOG"
    NODE_INFO=$(curl -s "https://evomap.ai/a2a/nodes/$NODE_ID" 2>/dev/null)
    
    if [ -n "$NODE_INFO" ]; then
        echo "✅ 成功获取节点信息" | tee -a "$MONITOR_LOG"
        
        # 提取关键信息
        LAST_SEEN=$(echo "$NODE_INFO" | grep -o '"last_seen_at":"[^"]*"' | cut -d'"' -f4)
        REPUTATION=$(echo "$NODE_INFO" | grep -o '"reputation_score":[0-9]*' | cut -d':' -f2)
        TOTAL_PUBLISHED=$(echo "$NODE_INFO" | grep -o '"total_published":[0-9]*' | cut -d':' -f2)
        
        echo "   • 最后在线: ${LAST_SEEN:-未找到}" | tee -a "$MONITOR_LOG"
        echo "   • 声誉分数: ${REPUTATION:-未找到}" | tee -a "$MONITOR_LOG"
        echo "   • 发布资产: ${TOTAL_PUBLISHED:-未找到}" | tee -a "$MONITOR_LOG"
        
        # 记录初始状态
        if [ -z "$INITIAL_LAST_SEEN" ]; then
            INITIAL_LAST_SEEN="$LAST_SEEN"
            echo "   • 初始最后在线时间: $INITIAL_LAST_SEEN" | tee -a "$MONITOR_LOG"
        fi
        
        # 检查状态是否更新
        if [ -n "$LAST_SEEN" ] && [ "$LAST_SEEN" != "$INITIAL_LAST_SEEN" ]; then
            echo "🎉 状态已更新！最后在线时间从 $INITIAL_LAST_SEEN 变为 $LAST_SEEN" | tee -a "$MONITOR_LOG"
            ONLINE_DETECTED=true
            CURRENT_STATUS="online"
        fi
        
        # 检查时间差（如果最后在线时间存在）
        if [ -n "$LAST_SEEN" ]; then
            LAST_SEEN_TS=$(date -d "$LAST_SEEN" +%s 2>/dev/null || echo "0")
            CURRENT_TS=$(date +%s)
            TIME_DIFF=$((CURRENT_TS - LAST_SEEN_TS))
            
            if [ "$TIME_DIFF" -lt 600 ]; then  # 10分钟内
                echo "✅ 节点活跃（最后在线 ${TIME_DIFF} 秒前）" | tee -a "$MONITOR_LOG"
                CURRENT_STATUS="online"
                ONLINE_DETECTED=true
            elif [ "$TIME_DIFF" -lt 3600 ]; then  # 1小时内
                echo "⚠️  节点可能活跃（最后在线 ${TIME_DIFF} 秒前）" | tee -a "$MONITOR_LOG"
                CURRENT_STATUS="possibly_online"
            else
                echo "❌ 节点可能离线（最后在线 ${TIME_DIFF} 秒前）" | tee -a "$MONITOR_LOG"
                CURRENT_STATUS="offline"
            fi
        fi
    else
        echo "❌ 无法获取节点信息" | tee -a "$MONITOR_LOG"
    fi
    
    # 2. 发送测试消息保持活跃
    echo -e "\n2. 📤 发送测试消息保持活跃..." | tee -a "$MONITOR_LOG"
    cd /root/.openclaw/workspace/evolver
    
    # 设置环境变量
    export A2A_TRANSPORT="http"
    export A2A_HUB_URL="https://evomap.ai"
    export A2A_SENDER_ID="$NODE_ID"
    
    TEST_OUTPUT=$(timeout 30 node scripts/a2a_export.js --hello --protocol --persist 2>&1 | tail -3)
    
    if echo "$TEST_OUTPUT" | grep -q "protocol"; then
        echo "✅ 测试消息发送成功" | tee -a "$MONITOR_LOG"
        MESSAGE_COUNT=$(echo "$TEST_OUTPUT" | grep -c "protocol")
        echo "   • 发送消息数量: $MESSAGE_COUNT" | tee -a "$MONITOR_LOG"
        
        # 提取最后消息时间
        LAST_MSG_TIME=$(echo "$TEST_OUTPUT" | grep '"timestamp"' | tail -1 | grep -o '"timestamp":"[^"]*"' | cut -d'"' -f4)
        if [ -n "$LAST_MSG_TIME" ]; then
            echo "   • 最后消息时间: $LAST_MSG_TIME" | tee -a "$MONITOR_LOG"
        fi
    else
        echo "❌ 测试消息发送失败" | tee -a "$MONITOR_LOG"
        echo "错误信息: $TEST_OUTPUT" | tee -a "$MONITOR_LOG"
    fi
    
    # 3. 检查Hub状态
    echo -e "\n3. 🏢 检查EvoMap Hub状态..." | tee -a "$MONITOR_LOG"
    HUB_STATS=$(curl -s "https://evomap.ai/a2a/stats" 2>/dev/null)
    
    if [ -n "$HUB_STATS" ]; then
        echo "✅ Hub运行正常" | tee -a "$MONITOR_LOG"
        TOTAL_NODES=$(echo "$HUB_STATS" | grep -o '"total_nodes":[0-9]*' | cut -d':' -f2)
        TOTAL_ASSETS=$(echo "$HUB_STATS" | grep -o '"total_assets":[0-9]*' | cut -d':' -f2)
        echo "   • 总节点数: ${TOTAL_NODES:-未找到}" | tee -a "$MONITOR_LOG"
        echo "   • 总资产数: ${TOTAL_ASSETS:-未找到}" | tee -a "$MONITOR_LOG"
    else
        echo "❌ 无法获取Hub状态" | tee -a "$MONITOR_LOG"
    fi
    
    # 4. 状态总结
    echo -e "\n4. 📊 当前状态总结:" | tee -a "$MONITOR_LOG"
    echo "   • 节点状态: $CURRENT_STATUS" | tee -a "$MONITOR_LOG"
    echo "   • 最后在线: ${LAST_SEEN:-未知}" | tee -a "$MONITOR_LOG"
    echo "   • 在线检测: $ONLINE_DETECTED" | tee -a "$MONITOR_LOG"
    echo "   • 检查次数: $check_count/$MAX_CHECKS" | tee -a "$MONITOR_LOG"
    
    # 如果已经检测到在线，可以提前结束
    if [ "$ONLINE_DETECTED" = true ] && [ "$check_count" -ge 3 ]; then
        echo -e "\n🎉 节点已确认在线！监控任务完成。" | tee -a "$MONITOR_LOG"
        break
    fi
    
    # 如果不是最后一次检查，等待间隔
    if [ "$check_count" -lt "$MAX_CHECKS" ]; then
        echo -e "\n⏳ 等待 ${STATUS_CHECK_INTERVAL} 秒后进行下一次检查..." | tee -a "$MONITOR_LOG"
        sleep "$STATUS_CHECK_INTERVAL"
    fi
done

# 最终总结
echo -e "\n========================================" | tee -a "$MONITOR_LOG"
echo "📋 监控任务完成总结" | tee -a "$MONITOR_LOG"
echo "========================================" | tee -a "$MONITOR_LOG"
echo "监控开始时间: $(grep "开始时间" "$MONITOR_LOG" | head -1)" | tee -a "$MONITOR_LOG"
echo "监控结束时间: $(date)" | tee -a "$MONITOR_LOG"
echo "总检查次数: $check_count" | tee -a "$MONITOR_LOG"
echo "最终节点状态: $CURRENT_STATUS" | tee -a "$MONITOR_LOG"
echo "在线检测结果: $ONLINE_DETECTED" | tee -a "$MONITOR_LOG"
echo "初始最后在线: $INITIAL_LAST_SEEN" | tee -a "$MONITOR_LOG"
echo "最终最后在线: ${LAST_SEEN:-未更新}" | tee -a "$MONITOR_LOG"

if [ "$ONLINE_DETECTED" = true ]; then
    echo -e "\n✅ 监控结果: 节点已成功上线！" | tee -a "$MONITOR_LOG"
    echo "建议: 现在可以登录EvoMap Web客户端确认状态。" | tee -a "$MONITOR_LOG"
else
    echo -e "\n⚠️  监控结果: 节点状态未更新或仍然离线" | tee -a "$MONITOR_LOG"
    echo "可能原因:" | tee -a "$MONITOR_LOG"
    echo "1. EvoMap Hub状态更新延迟" | tee -a "$MONITOR_LOG"
    echo "2. 节点所有权或认领码问题" | tee -a "$MONITOR_LOG"
    echo "3. 网络或配置问题" | tee -a "$MONITOR_LOG"
    echo "建议:" | tee -a "$MONITOR_LOG"
    echo "1. 等待更长时间（几小时）" | tee -a "$MONITOR_LOG"
    echo "2. 联系EvoMap支持" | tee -a "$MONITOR_LOG"
    echo "3. 检查节点绑定状态" | tee -a "$MONITOR_LOG"
fi

echo "========================================" | tee -a "$MONITOR_LOG"
echo "监控日志文件: $MONITOR_LOG" | tee -a "$MONITOR_LOG"
echo "节点ID: $NODE_ID" | tee -a "$MONITOR_LOG"
echo "用户邮箱: $USER_EMAIL" | tee -a "$MONITOR_LOG"