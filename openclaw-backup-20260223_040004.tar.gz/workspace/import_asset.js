const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 要导入的资产ID
const assetIds = [
  'sha256:3788de88cc227ec0e34d8212dccb9e5d333b3ee7ef626c06017db9ef52386baa', // 1. Agent错误自动修复
  'sha256:22e00475cc06d59c44f55beb3a623f43c347ac39f1342e62bce5cfcd5593a63c', // 2. 飞书文档错误修复
  'sha256:3f57493702df5c7db38a75862c421fab8fc2330c11b84d3ba9a59ee6139485ea'  // 3. JSON解析错误修复
];

// 获取资产数据
function fetchAsset(assetId) {
  return new Promise((resolve, reject) => {
    const fetchMessage = {
      protocol: 'gep-a2a',
      protocol_version: '1.0.0',
      message_type: 'fetch',
      message_id: 'fetch_asset_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      sender_id: process.env.A2A_SENDER_ID || 'node_d80158479a5d',
      timestamp: new Date().toISOString(),
      payload: {
        content_hash: assetId
      }
    };

    const data = JSON.stringify(fetchMessage);

    const options = {
      hostname: 'evomap.ai',
      port: 443,
      path: '/a2a/fetch',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      res.on('end', () => {
        try {
          const result = JSON.parse(responseData);
          if (result.payload && result.payload.results && result.payload.results.length > 0) {
            resolve(result.payload.results[0]);
          } else {
            reject(new Error('未找到资产: ' + assetId));
          }
        } catch (error) {
          reject(error);
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.write(data);
    req.end();
  });
}

// 导入资产
function importAsset(assetData, index) {
  return new Promise((resolve, reject) => {
    try {
      // 创建临时文件
      const tempDir = path.join(__dirname, 'temp_import');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      const tempFile = path.join(tempDir, `asset_${index}.json`);
      fs.writeFileSync(tempFile, JSON.stringify(assetData, null, 2));
      
      console.log(`  资产数据已保存到: ${tempFile}`);
      
      // 使用a2a_ingest.js导入
      const command = `./run-with-env.sh node scripts/a2a_ingest.js ${tempFile}`;
      console.log(`  执行导入命令: ${command}`);
      
      const result = execSync(command, { 
        cwd: __dirname,
        encoding: 'utf8',
        stdio: ['pipe', 'pipe', 'pipe']
      });
      
      console.log(`  导入结果: ${result.trim()}`);
      resolve(true);
      
    } catch (error) {
      console.error(`  导入失败: ${error.message}`);
      reject(error);
    }
  });
}

async function main() {
  console.log('开始导入推荐的EvoMap网络资产...');
  console.log('要导入的资产数量:', assetIds.length);
  
  for (let i = 0; i < assetIds.length; i++) {
    const assetId = assetIds[i];
    console.log(`\\n${i + 1}. 导入资产: ${assetId.substring(0, 30)}...`);
    
    try {
      // 获取资产数据
      console.log('  从EvoMap Hub获取资产数据...');
      const assetData = await fetchAsset(assetId);
      
      console.log('  资产信息:');
      console.log(`    类型: ${assetData.asset_type}`);
      console.log(`    状态: ${assetData.status}`);
      console.log(`    来源节点: ${assetData.source_node_id}`);
      console.log(`    触发信号: ${(assetData.trigger_text || '无').substring(0, 80)}...`);
      
      // 导入资产
      await importAsset(assetData, i);
      
      console.log(`  ✅ 资产 ${i + 1} 导入完成`);
      
    } catch (error) {
      console.error(`  ❌ 资产 ${i + 1} 导入失败: ${error.message}`);
    }
  }
  
  console.log('\\n=== 导入总结 ===');
  console.log('所有推荐资产导入尝试完成。');
  console.log('\\n💡 下一步:');
  console.log('1. 检查 assets/gep/ 目录查看导入的资产');
  console.log('2. 当遇到类似错误信号时，Evolver会自动应用这些修复方案');
  console.log('3. 可以在 memory_graph.jsonl 中查看资产使用记录');
  
  // 清理临时文件
  const tempDir = path.join(__dirname, 'temp_import');
  if (fs.existsSync(tempDir)) {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
      console.log('临时文件已清理');
    } catch (error) {
      // 忽略清理错误
    }
  }
}

main().catch(error => {
  console.error('主程序错误:', error.message);
});
