#!/bin/bash
# 快速AI热点测试

echo "🚀 快速测试AI热点摘要系统"
echo ""

# 1. 准备配置
echo "1. 准备AI专用配置..."
CONFIG_DIR="/root/.openclaw/workspace/configs/ai-digest"

# 复制配置文件
cp /root/.openclaw/workspace/configs/ai-digest/sources-ai-only.json $CONFIG_DIR/sources.json
cp /root/.openclaw/workspace/configs/ai-digest/topics-ai.json $CONFIG_DIR/topics.json

echo "   配置目录: $CONFIG_DIR"
ls -la $CONFIG_DIR/*.json
echo ""

# 2. 测试RSS源
echo "2. 测试RSS源获取..."
cd /root/.openclaw/workspace/skills/tech-news-digest

# 先禁用Web搜索避免API限制
cat > $CONFIG_DIR/override.yaml << 'EOF'
sources:
  web:
    enabled: false
  twitter:
    enabled: false
  github:
    enabled: false
processing:
  test_mode: true
EOF

echo "   运行RSS测试..."
timeout 30 python3 scripts/run-pipeline.py \
  --defaults $CONFIG_DIR \
  --hours 24 \
  --output /tmp/ai-rss-test.json \
  2>&1 | grep -E "(RSS|items|Done)" | tail -10

if [ -f "/tmp/ai-rss-test.json" ]; then
    echo "   ✅ RSS测试完成"
    # 简单统计
    TOTAL=$(jq '.output_stats.total_articles' /tmp/ai-rss-test.json 2>/dev/null || echo "0")
    echo "   获取文章数: $TOTAL"
else
    echo "   ❌ RSS测试失败"
fi
echo ""

# 3. 生成可读报告
echo "3. 生成可读报告..."
if [ -f "/tmp/ai-rss-test.json" ] && [ "$TOTAL" -gt "0" ]; then
    # 创建简单报告生成脚本
    cat > /tmp/generate-simple-report.py << 'EOF'
import json
import sys
from datetime import datetime

with open('/tmp/ai-rss-test.json', 'r') as f:
    data = json.load(f)

items = []
# 尝试不同可能的数据位置
if 'items' in data:
    items = data['items']
elif 'articles' in data:
    items = data['articles']

print(f"# AI热点测试报告")
print(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"数据来源: RSS + Reddit")
print("")

if items:
    print(f"## 共找到 {len(items)} 条AI相关热点")
    print("")
    
    # 按主题分组
    topics = {}
    for item in items[:15]:  # 只显示前15条
        topic = item.get('primary_topic', '其他')
        if topic not in topics:
            topics[topic] = []
        topics[topic].append(item)
    
    for topic, topic_items in topics.items():
        print(f"### {topic} ({len(topic_items)}条)")
        for item in topic_items[:5]:
            title = item.get('title', '无标题')[:60]
            score = item.get('quality_score', 0)
            source = item.get('source_name', '未知')
            print(f"• **{title}...** ({score}分) - {source}")
        print("")
else:
    print("未找到具体文章数据")
    print("原始数据结构:")
    for key in data.keys():
        print(f"- {key}: {type(data[key])}")
EOF

    python3 /tmp/generate-simple-report.py > /tmp/ai-test-report.md
    echo "   报告已生成: /tmp/ai-test-report.md"
    echo "   报告预览:"
    head -20 /tmp/ai-test-report.md
else
    echo "   ⚠️ 无法生成报告，数据文件可能为空"
fi
echo ""

# 4. 下一步建议
echo "4. 下一步建议:"
cat << 'EOF'
    ✅ 已完成:
    - Brave API密钥配置
    - AI专用数据源配置
    - RSS源测试运行
    
    🔄 待完成:
    - 启用Web搜索（注意API限制）
    - 配置Telegram输出
    - 设置定时任务
    - 集成到内容创作流程
    
    📝 立即行动:
    1. 查看完整报告: cat /tmp/ai-test-report.md
    2. 评估热点质量是否符合预期
    3. 决定是否启用Web搜索
    4. 配置Telegram自动发送
EOF
echo ""

echo "✅ 快速测试完成"