#!/bin/bash
# 每日记忆整理脚本

WORKSPACE="/root/.openclaw/workspace"
TODAY=$(date +%Y-%m-%d)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)

echo "🧠 开始每日记忆整理 - $(date)"

# 1. 检查并创建记忆目录
if [ ! -d "$WORKSPACE/memory" ]; then
    mkdir -p "$WORKSPACE/memory"
    echo "✅ 创建记忆目录"
fi

# 2. 创建今天的记忆文件（如果不存在）
if [ ! -f "$WORKSPACE/memory/$TODAY.md" ]; then
    echo "# $TODAY 记忆日志" > "$WORKSPACE/memory/$TODAY.md"
    echo "创建时间: $(date)" >> "$WORKSPACE/memory/$TODAY.md"
    echo "---" >> "$WORKSPACE/memory/$TODAY.md"
    echo "✅ 创建今日记忆文件"
fi

# 3. 检查昨天的记忆文件，提取重要内容到长期记忆
if [ -f "$WORKSPACE/memory/$YESTERDAY.md" ]; then
    echo "📅 检查昨日记忆文件: $YESTERDAY.md"
    
    # 提取重要内容（这里可以添加更复杂的提取逻辑）
    IMPORTANT_CONTENT=$(grep -E "(重要|决策|教训|发现|TODO|FIXME)" "$WORKSPACE/memory/$YESTERDAY.md" | head -10)
    
    if [ ! -z "$IMPORTANT_CONTENT" ]; then
        echo "📝 发现重要内容，更新长期记忆..."
        echo "" >> "$WORKSPACE/MEMORY.md"
        echo "## $YESTERDAY 重要记忆" >> "$WORKSPACE/MEMORY.md"
        echo "$IMPORTANT_CONTENT" >> "$WORKSPACE/MEMORY.md"
        echo "---" >> "$WORKSPACE/MEMORY.md"
    fi
fi

# 4. 清理旧记忆文件（保留最近30天）
find "$WORKSPACE/memory" -name "*.md" -mtime +30 -delete
echo "🧹 清理30天前的旧记忆文件"

# 5. 检查记忆文件大小
MEMORY_SIZE=$(du -sh "$WORKSPACE/memory" | cut -f1)
MEMORY_COUNT=$(find "$WORKSPACE/memory" -name "*.md" | wc -l)
echo "📊 记忆统计: $MEMORY_COUNT 个文件，总大小 $MEMORY_SIZE"

echo "✅ 记忆整理完成 - $(date)"