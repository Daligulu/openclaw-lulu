#!/bin/bash
# 快速测试备份脚本

echo "🔍 测试OpenClaw备份系统..."
echo ""

# 1. 检查脚本权限
echo "1. 检查脚本权限..."
ls -la /root/.openclaw/workspace/backup-openclaw.sh
echo ""

# 2. 检查GitHub令牌
echo "2. 检查GitHub令牌配置..."
TOKEN=$(grep -o 'GITHUB_TOKEN="[^"]*"' /root/.openclaw/workspace/backup-openclaw.sh | cut -d'"' -f2)
if [ -n "$TOKEN" ]; then
    echo "   ✅ GitHub令牌已配置"
    echo "   令牌前10位: ${TOKEN:0:10}..."
else
    echo "   ❌ 未找到GitHub令牌"
fi
echo ""

# 3. 检查定时任务
echo "3. 检查定时任务..."
crontab -l | grep -i openclaw
echo ""

# 4. 测试备份准备（不实际推送）
echo "4. 测试备份准备..."
cd /root/.openclaw/workspace
timeout 10 ./backup-openclaw.sh 2>&1 | grep -E "(准备|开始|备份大小|完成)" | head -10
echo ""

# 5. 检查备份文件
echo "5. 检查备份文件..."
find /tmp -name "openclaw-backup-*.tar.gz" -type f 2>/dev/null | head -5
echo ""

echo "📋 测试完成！"
echo ""
echo "✅ 如果以上检查都通过，备份系统已就绪"
echo "🕒 定时备份将在 7:00, 12:00, 17:00, 20:00 自动运行"
echo "🔧 手动备份命令: backup-openclaw"
echo "📊 查看日志命令: backup-openclaw-log"