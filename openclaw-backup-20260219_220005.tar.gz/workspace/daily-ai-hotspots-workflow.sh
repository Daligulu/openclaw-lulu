#!/bin/bash
# 完整AI热点工作流 - 每日自动运行

echo "🤖 AI热点工作流启动..."
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 配置
CONFIG_DIR="/root/.openclaw/workspace/configs/ai-digest-optimized"
OUTPUT_DIR="/root/.openclaw/workspace/ai-hotspots"
LOG_FILE="/var/log/ai-hotspots-$(date +%Y%m%d).log"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 创建目录
mkdir -p "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR/archive"
mkdir -p "$(dirname "$LOG_FILE")"

# 记录开始
echo "=== AI热点收集开始 ===" >> "$LOG_FILE"
echo "开始时间: $(date)" >> "$LOG_FILE"

# 1. 设置环境
echo "1. 设置环境..."
export BRAVE_API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
export TZ='Asia/Shanghai'

cd /root/.openclaw/workspace/skills/tech-news-digest || {
    echo "❌ 无法进入技能目录" | tee -a "$LOG_FILE"
    exit 1
}

# 2. 运行数据收集
echo "2. 收集AI热点数据..." | tee -a "$LOG_FILE"
echo "配置目录: $CONFIG_DIR" >> "$LOG_FILE"
echo "时间范围: 过去24小时" >> "$LOG_FILE"

DATA_FILE="/tmp/ai-hotspots-$TIMESTAMP.json"
METRICS_FILE="/tmp/ai-metrics-$TIMESTAMP.json"

python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_DIR" \
  --hours 24 \
  --output "$DATA_FILE" \
  --verbose 2>&1 | tee -a "$LOG_FILE"

if [ ! -f "$DATA_FILE" ]; then
    echo "❌ 数据收集失败" | tee -a "$LOG_FILE"
    exit 1
fi

echo "✅ 数据收集完成: $(wc -l < "$DATA_FILE") 字节" | tee -a "$LOG_FILE"

# 3. 生成可读报告
echo "3. 生成可读报告..." | tee -a "$LOG_FILE"

REPORT_FILE="$OUTPUT_DIR/daily-$TIMESTAMP.md"
SUMMARY_FILE="$OUTPUT_DIR/summary-$TIMESTAMP.md"

# 创建报告生成脚本
cat > /tmp/generate-report.py << 'EOF'
import json
import sys
from datetime import datetime
import re

def load_data(filepath):
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"加载数据失败: {e}")
        return None

def extract_ai_hotspots(data):
    """从数据中提取AI热点"""
    hotspots = []
    
    # 从topics.{topic}.articles中提取数据
    topics = data.get('topics', {})
    
    for topic_name, topic_data in topics.items():
        if not isinstance(topic_data, dict):
            continue
            
        articles = topic_data.get('articles', [])
        
        for article in articles:
            if not isinstance(article, dict):
                continue
                
            title = article.get('title', '')
            link = article.get('link', article.get('url', ''))
            score = article.get('quality_score', article.get('score', 8.0))  # 默认8分
            source = article.get('source_name', article.get('source', '未知'))
            date = article.get('date', article.get('published', ''))
            summary = article.get('summary', article.get('description', ''))[:200]
            
            # 基本验证
            if not title:
                continue
                
            # 确保是AI相关内容
            ai_keywords = ['ai', 'gpt', 'claude', 'llm', '人工智能', '机器学习', '深度学习']
            title_lower = title.lower()
            if not any(keyword in title_lower for keyword in ai_keywords):
                continue
            
            hotspots.append({
                'title': title,
                'link': link,
                'score': score,
                'source': source,
                'date': date,
                'summary': summary,
                'topic': topic_name
            })
    
    return hotspots

def generate_markdown_report(hotspots, output_file):
    """生成Markdown报告"""
    now = datetime.now()
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"# 🔔 AI科技热点日报\n")
        f.write(f"**生成时间**: {now.strftime('%Y-%m-%d %H:%M:%S %Z')}\n")
        f.write(f"**热点数量**: {len(hotspots)}条\n\n")
        
        if not hotspots:
            f.write("## ⚠️ 今日无AI热点\n")
            f.write("可能原因:\n")
            f.write("1. 数据源暂时无更新\n")
            f.write("2. 过滤规则过于严格\n")
            f.write("3. 网络或API问题\n")
            f.write("\n建议检查数据源配置和网络连接。\n")
        else:
            # 按主题分组
            topics = {}
            for hotspot in hotspots:
                topic = hotspot.get('topic', '其他')
                if topic not in topics:
                    topics[topic] = []
                topics[topic].append(hotspot)
            
            # 按主题显示
            for topic_name, topic_hotspots in topics.items():
                # 转换主题ID为中文
                topic_map = {
                    'ai-core': '🧠 AI核心发布',
                    'llm': '💬 大语言模型', 
                    'ai-research': '🔬 AI研究',
                    'ai-tech': '⚙️ AI技术',
                    'ai-china': '🇨🇳 中国AI',
                    'industry': '🏢 AI产业',
                    'ml': '📊 机器学习',
                    'frontier-tech': '🚀 前沿科技',
                    'programming': '💻 编程相关'
                }
                
                display_name = topic_map.get(topic_name, f'📁 {topic_name}')
                f.write(f"## {display_name} ({len(topic_hotspots)}条)\n")
                
                # 按分数排序
                topic_hotspots.sort(key=lambda x: x['score'], reverse=True)
                
                for i, hotspot in enumerate(topic_hotspots[:8], 1):  # 每个主题最多8条
                    title = hotspot['title']
                    if len(title) > 80:
                        title = title[:77] + "..."
                    
                    f.write(f"### {i}. {title}\n")
                    f.write(f"**评分**: {hotspot['score']:.1f}分\n")
                    f.write(f"**来源**: {hotspot['source']}\n")
                    
                    if hotspot['summary']:
                        f.write(f"**摘要**: {hotspot['summary']}...\n")
                    
                    if hotspot['link']:
                        f.write(f"🔗 [阅读原文]({hotspot['link']})\n")
                    
                    f.write("\n")
                
                f.write("\n")
            
            # 统计信息
            f.write("## 📊 统计信息\n")
            if hotspots:
                avg_score = sum(h['score'] for h in hotspots) / len(hotspots)
                f.write(f"- **平均评分**: {avg_score:.1f}/10\n")
            
            # 主题分布
            f.write("- **主题分布**:\n")
            for topic_name, count in sorted(topics.items(), key=lambda x: len(x[1]), reverse=True):
                display_name = topic_map.get(topic_name, topic_name)
                f.write(f"  - {display_name}: {len(count)}条\n")
            
            # 来源分布
            sources = {}
            for h in hotspots:
                source = h['source']
                sources[source] = sources.get(source, 0) + 1
            
            f.write("- **热门来源**:\n")
            for source, count in sorted(sources.items(), key=lambda x: x[1], reverse=True)[:5]:
                f.write(f"  - {source}: {count}条\n")
        
        f.write("\n---\n")
        f.write("*数据源: AI核心媒体 + Reddit社区 + Web搜索*\n")
        f.write("*过滤规则: 排除加密货币，优先中文内容*\n")
        f.write(f"*报告版本: v1.2 | 生成ID: {now.strftime('%Y%m%d%H%M')}*\n")
    
    return len(hotspots)

def generate_summary(hotspots, output_file):
    """生成简洁摘要"""
    now = datetime.now()
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"AI热点摘要 {now.strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"共{len(hotspots)}条热点\n\n")
        
        # 前5条
        hotspots.sort(key=lambda x: x['score'], reverse=True)
        for i, hotspot in enumerate(hotspots[:5], 1):
            title = hotspot['title'][:50]
            if len(hotspot['title']) > 50:
                title += "..."
            f.write(f"{i}. {title}\n")
            f.write(f"   {hotspot['score']}分 | {hotspot['source']}\n\n")
        
        f.write("---\n#AI热点")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 generate-report.py <数据文件>")
        sys.exit(1)
    
    data_file = sys.argv[1]
    data = load_data(data_file)
    
    if not data:
        print("无法加载数据")
        sys.exit(1)
    
    hotspots = extract_ai_hotspots(data)
    print(f"找到 {len(hotspots)} 条AI热点")
    
    # 生成详细报告
    report_file = sys.argv[2] if len(sys.argv) > 2 else "/tmp/ai-report.md"
    count = generate_markdown_report(hotspots, report_file)
    print(f"报告已生成: {report_file} ({count}条)")
    
    # 生成摘要
    summary_file = sys.argv[3] if len(sys.argv) > 3 else "/tmp/ai-summary.md"
    generate_summary(hotspots, summary_file)
    print(f"摘要已生成: {summary_file}")
EOF

# 运行报告生成
python3 /tmp/generate-report.py "$DATA_FILE" "$REPORT_FILE" "$SUMMARY_FILE" 2>&1 | tee -a "$LOG_FILE"

if [ -f "$REPORT_FILE" ]; then
    REPORT_SIZE=$(wc -l < "$REPORT_FILE")
    echo "✅ 报告生成完成: $REPORT_FILE ($REPORT_SIZE 行)" | tee -a "$LOG_FILE"
else
    echo "⚠️  报告生成可能失败" | tee -a "$LOG_FILE"
fi

# 4. 发送到Telegram（可选）
echo "4. 发送到Telegram..." | tee -a "$LOG_FILE"

if [ -f "$SUMMARY_FILE" ] && [ -s "$SUMMARY_FILE" ]; then
    # 这里可以添加Telegram发送逻辑
    # 例如使用OpenClaw的message工具
    echo "📱 Telegram发送就绪（需配置）" | tee -a "$LOG_FILE"
    
    # 示例发送命令（需要实际配置）
    # CONTENT=$(cat "$SUMMARY_FILE")
    # 调用message工具发送
else
    echo "⚠️  摘要文件为空，跳过Telegram发送" | tee -a "$LOG_FILE"
fi

# 5. 归档和清理
echo "5. 归档处理..." | tee -a "$LOG_FILE"

# 归档数据文件
ARCHIVE_FILE="$OUTPUT_DIR/archive/ai-data-$TIMESTAMP.json.gz"
gzip -c "$DATA_FILE" > "$ARCHIVE_FILE" 2>/dev/null && \
    echo "✅ 数据已归档: $ARCHIVE_FILE" | tee -a "$LOG_FILE"

# 清理临时文件（保留最近3天）
find /tmp -name "ai-hotspots-*" -mtime +3 -delete 2>/dev/null
find /tmp -name "td-*.json" -mtime +1 -delete 2>/dev/null

# 6. 生成运行统计
echo "6. 生成运行统计..." | tee -a "$LOG_FILE"

cat > "$METRICS_FILE" << EOF
{
  "timestamp": "$(date -Iseconds)",
  "workflow": "ai-hotspots-daily",
  "config_version": "1.1",
  "files_generated": {
    "data": "$DATA_FILE",
    "report": "$REPORT_FILE",
    "summary": "$SUMMARY_FILE",
    "archive": "$ARCHIVE_FILE",
    "log": "$LOG_FILE"
  },
  "status": "completed",
  "duration_seconds": "$SECONDS"
}
EOF

echo "📊 运行统计: $METRICS_FILE" | tee -a "$LOG_FILE"

# 7. 完成
echo "" | tee -a "$LOG_FILE"
echo "=== AI热点收集完成 ===" | tee -a "$LOG_FILE"
echo "完成时间: $(date)" | tee -a "$LOG_FILE"
echo "总耗时: ${SECONDS}秒" | tee -a "$LOG_FILE"
echo "输出文件:" | tee -a "$LOG_FILE"
echo "  • 详细报告: $REPORT_FILE" | tee -a "$LOG_FILE"
echo "  • 简洁摘要: $SUMMARY_FILE" | tee -a "$LOG_FILE"
echo "  • 原始数据: $ARCHIVE_FILE" | tee -a "$LOG_FILE"
echo "  • 运行日志: $LOG_FILE" | tee -a "$LOG_FILE"

echo ""
echo "✅ AI热点工作流执行完成"
echo "查看报告: cat $REPORT_FILE | head -30"
echo "查看日志: tail -20 $LOG_FILE"