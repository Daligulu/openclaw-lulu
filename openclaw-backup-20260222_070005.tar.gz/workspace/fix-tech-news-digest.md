# Tech-News-Digest 修复方案

## 已发现的问题

### 1. RSS抓取问题
- 缺少feedparser库（Python包）
- 某些RSS源可能无法访问或超时
- 脚本使用regex回退，但可能效率较低

### 2. Web搜索问题
- Brave API key有效（BSAGhr7xYgJZubiYo6EW2SzTaXvifq_）
- fetch-web.py脚本可能因为rate limit检测或查询延迟而显得慢
- 每个topic有4个查询，4个topic共16个查询，每个查询1秒延迟

### 3. 依赖问题
- 系统缺少pip/pip3，无法安装Python包
- 可能需要系统包管理器安装python3-pip

## 临时修复方案

### 方案A：简化配置（推荐）
1. 创建简化的sources.json，只包含可靠的RSS源
2. 禁用有问题的源（如The Block返回403）
3. 减少查询数量和时间窗口

### 方案B：修复脚本
1. 减少fetch-rss.py的超时时间和worker数量（已做）
2. 简化fetch-web.py的rate limit检测（已做）
3. 添加更好的错误处理和日志

### 方案C：分步测试
1. 先测试RSS抓取（少量源）
2. 再测试Web搜索（单个查询）
3. 最后测试完整pipeline

## 具体修复步骤

### 1. 创建简化配置
```bash
mkdir -p /root/.openclaw/workspace/config/tech-digest
cat > /root/.openclaw/workspace/config/tech-digest/sources.json << 'EOF'
{
  "sources": [
    {
      "id": "hackernews-rss",
      "type": "rss",
      "name": "Hacker News Frontpage",
      "url": "https://hnrss.org/frontpage",
      "enabled": true,
      "priority": true,
      "topics": ["frontier-tech"]
    },
    {
      "id": "producthunt-rss",
      "type": "rss",
      "name": "Product Hunt",
      "url": "https://www.producthunt.com/feed",
      "enabled": true,
      "priority": true,
      "topics": ["frontier-tech"]
    },
    {
      "id": "decrypt-rss",
      "type": "rss",
      "name": "Decrypt",
      "url": "https://decrypt.co/feed",
      "enabled": true,
      "priority": true,
      "topics": ["crypto"]
    }
  ]
}
EOF
```

### 2. 测试简化RSS抓取
```bash
cd /root/.openclaw/workspace/skills/tech-news-digest
python3 scripts/fetch-rss.py \
  --defaults config/defaults \
  --config /root/.openclaw/workspace/config/tech-digest \
  --hours 24 \
  --output /tmp/test-rss-simple.json \
  --verbose
```

### 3. 测试简化Web搜索
```bash
# 创建简化topics.json
cat > /root/.openclaw/workspace/config/tech-digest/topics.json << 'EOF'
{
  "topics": [
    {
      "id": "llm",
      "emoji": "🧠",
      "label": "LLM / Large Models",
      "description": "Large Language Models",
      "search": {
        "queries": ["LLM latest news"],
        "must_include": ["LLM", "large language model"],
        "exclude": ["tutorial"]
      },
      "display": {
        "max_items": 3,
        "style": "detailed"
      }
    }
  ]
}
EOF

# 测试Web搜索
python3 scripts/fetch-web.py \
  --defaults config/defaults \
  --config /root/.openclaw/workspace/config/tech-digest \
  --freshness pd \
  --output /tmp/test-web-simple.json \
  --verbose
```

### 4. 测试完整pipeline（简化版）
```bash
python3 scripts/run-pipeline.py \
  --defaults config/defaults \
  --config /root/.openclaw/workspace/config/tech-digest \
  --hours 24 \
  --freshness pd \
  --output /tmp/test-pipeline-simple.json \
  --verbose --force
```

## 长期解决方案

### 1. 安装Python包管理
```bash
# 尝试安装pip
dnf install -y python3-pip || yum install -y python3-pip || apt-get install -y python3-pip

# 安装feedparser
pip3 install feedparser
```

### 2. 优化脚本配置
- 增加超时处理
- 添加更详细的日志
- 实现更好的错误恢复

### 3. 配置API keys
- Twitter API key（可选）
- 确保Brave API key正确配置

## 验证修复

运行以下命令验证修复：
```bash
# 检查RSS抓取
python3 scripts/fetch-rss.py --hours 1 --verbose 2>&1 | grep -E "(INFO|articles)"

# 检查Web搜索  
python3 scripts/fetch-web.py --freshness pd --verbose 2>&1 | grep -E "(INFO|results)"

# 检查完整pipeline
python3 scripts/run-pipeline.py --hours 24 --freshness pd --verbose 2>&1 | tail -20
```