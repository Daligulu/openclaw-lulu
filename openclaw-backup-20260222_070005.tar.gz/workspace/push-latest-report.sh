#!/bin/bash
# 推送最新详细报告到Telegram

echo "📤 推送最新详细报告到Telegram"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 查找最新报告
LATEST_REPORT=$(find /root/.openclaw/workspace/ai-hotspots-only -name "daily-*.md" -type f 2>/dev/null | sort -r | head -1)

if [ -f "$LATEST_REPORT" ]; then
    REPORT_NAME=$(basename "$LATEST_REPORT")
    REPORT_SIZE=$(du -h "$LATEST_REPORT" | cut -f1)
    REPORT_TIME=$(stat -c %y "$LATEST_REPORT" 2>/dev/null | cut -d'.' -f1)
    
    echo "📄 找到最新报告:"
    echo "   文件: $REPORT_NAME"
    echo "   大小: $REPORT_SIZE"
    echo "   时间: $REPORT_TIME"
    echo ""
    
    # 设置Telegram配置
    export TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-8289858508:AAGacfYMR0PmKVvMHfrSWTntccwxB5LsQfA}"
    export TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-8375286112}"
    
    if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ]; then
        echo "❌ Telegram配置不完整"
        echo "   请设置 TELEGRAM_BOT_TOKEN 和 TELEGRAM_CHAT_ID 环境变量"
        exit 1
    fi
    
    echo "📤 开始推送..."
    python3 /root/.openclaw/workspace/scripts/direct-report-pusher.py \
        "$LATEST_REPORT" \
        "$TELEGRAM_BOT_TOKEN" \
        "$TELEGRAM_CHAT_ID"
    
    echo ""
    echo "✅ 推送完成"
    echo "💡 报告已直接发送到Telegram"
else
    echo "❌ 未找到详细报告"
    echo "   运行以下命令生成报告:"
    echo "   /root/.openclaw/workspace/scripts/ai-hotspots-only.sh"
    exit 1
fi
