#!/bin/bash
# OpenClaw 完整备份脚本
# 定时备份：7:00, 12:00, 17:00, 20:00 (北京时间)
# 支持手动触发：./backup-openclaw.sh

set -e

# 配置
GITHUB_TOKEN="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"
REPO_URL="https://github.com/Daligulu/openclaw-lulu.git"
BACKUP_SOURCE="/root/.openclaw"
BACKUP_DIR="/tmp/openclaw-backup"
REPO_DIR="/tmp/openclaw-backup-repo"
LOG_FILE="/var/log/openclaw-backup.log"

# 时区设置（中国上海 GMT+8）
export TZ='Asia/Shanghai'

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "$(date '+%Y-%m-%d %H:%M:%S %Z') - $1" | tee -a "$LOG_FILE"
}

success() {
    echo -e "${GREEN}$(date '+%Y-%m-%d %H:%M:%S %Z') - $1${NC}" | tee -a "$LOG_FILE"
}

warning() {
    echo -e "${YELLOW}$(date '+%Y-%m-%d %H:%M:%S %Z') - $1${NC}" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}$(date '+%Y-%m-%d %H:%M:%S %Z') - $1${NC}" | tee -a "$LOG_FILE"
    exit 1
}

# 创建备份目录
prepare_backup() {
    log "准备备份目录..."
    rm -rf "$BACKUP_DIR"
    mkdir -p "$BACKUP_DIR"
    
    # 创建备份清单
    cat > "$BACKUP_DIR/backup-info.txt" << EOF
OpenClaw 完整备份
备份时间: $(date '+%Y-%m-%d %H:%M:%S %Z')
备份来源: $BACKUP_SOURCE
备份策略: 完整配置备份（排除缓存和大文件）
时区: 中国上海 (GMT+8)
恢复说明: 解压后替换 /root/.openclaw 目录即可
EOF
}

# 智能排除策略
backup_files() {
    log "开始备份文件..."
    
    # 科学备份策略：只备份关键文件
    log "备份关键配置文件..."
    
    # 1. 备份根目录配置文件
    cp -p "$BACKUP_SOURCE/openclaw.json" "$BACKUP_DIR/" 2>/dev/null || warning "未找到openclaw.json"
    
    # 2. 备份workspace目录（排除大文件）
    if [ -d "$BACKUP_SOURCE/workspace" ]; then
        log "备份workspace目录..."
        mkdir -p "$BACKUP_DIR/workspace"
        find "$BACKUP_SOURCE/workspace" -type f \( -name "*.md" -o -name "*.json" -o -name "*.js" -o -name "*.ts" -o -name "*.sh" -o -name "*.txt" -o -name "*.yml" -o -name "*.yaml" \) \
            -not -path "*/node_modules/*" \
            -not -path "*/.cache/*" \
            -not -path "*/tmp/*" \
            -not -path "*/.git/*" \
            -size -10M \
            -exec cp -p {} "$BACKUP_DIR/workspace/" \; 2>/dev/null
    fi
    
    # 3. 备份extensions目录（只备份配置）
    if [ -d "$BACKUP_SOURCE/extensions" ]; then
        log "备份extensions配置..."
        mkdir -p "$BACKUP_DIR/extensions"
        find "$BACKUP_SOURCE/extensions" -type f \( -name "*.json" -o -name "*.js" -o -name "*.md" -o -name "package.json" \) \
            -not -path "*/node_modules/*" \
            -size -1M \
            -exec cp -p {} "$BACKUP_DIR/extensions/" \; 2>/dev/null
    fi
    
    # 4. 备份其他关键目录
    KEY_DIRS=("agents" "config" "memory" "identity" "cron" "completions" "canvas" "telegram" "subagents" "credentials")
    for dir in "${KEY_DIRS[@]}"; do
        if [ -d "$BACKUP_SOURCE/$dir" ]; then
            log "备份$dir目录..."
            mkdir -p "$BACKUP_DIR/$dir"
            find "$BACKUP_SOURCE/$dir" -type f \
                -not -path "*/node_modules/*" \
                -not -path "*/.cache/*" \
                -size -5M \
                -exec cp -p {} "$BACKUP_DIR/$dir/" \; 2>/dev/null
        fi
    done
    
    # 5. 创建恢复脚本
    cat > "$BACKUP_DIR/restore-openclaw.sh" << 'EOF'
#!/bin/bash
# OpenClaw恢复脚本

set -e

BACKUP_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="/root/.openclaw"

echo "开始恢复OpenClaw备份..."
echo "备份目录: $BACKUP_DIR"
echo "目标目录: $TARGET_DIR"

read -p "确认恢复？这将覆盖现有配置 [y/N]: " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "取消恢复"
    exit 1
fi

# 备份现有配置
BACKUP_TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
BACKUP_FILE="/tmp/openclaw-pre-restore-$BACKUP_TIMESTAMP.tar.gz"
echo "备份现有配置到: $BACKUP_FILE"
tar -czf "$BACKUP_FILE" -C /root .openclaw 2>/dev/null || echo "警告：备份现有配置失败"

# 恢复文件
echo "恢复文件中..."
for dir in workspace extensions agents config memory identity cron completions canvas telegram subagents credentials; do
    if [ -d "$BACKUP_DIR/$dir" ]; then
        mkdir -p "$TARGET_DIR/$dir"
        cp -r "$BACKUP_DIR/$dir/"* "$TARGET_DIR/$dir/" 2>/dev/null || true
    fi
done

# 恢复配置文件
if [ -f "$BACKUP_DIR/openclaw.json" ]; then
    cp "$BACKUP_DIR/openclaw.json" "$TARGET_DIR/"
fi

echo "✅ OpenClaw恢复完成！"
echo "⚠️  注意：可能需要重启OpenClaw服务"
echo "   运行: openclaw gateway restart"
EOF
    
    chmod +x "$BACKUP_DIR/restore-openclaw.sh"
    
    # 统计备份大小
    BACKUP_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
    log "备份大小: $BACKUP_SIZE"
}

# 压缩备份
compress_backup() {
    log "压缩备份文件..."
    TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
    BACKUP_FILE="/tmp/openclaw-backup-$TIMESTAMP.tar.gz"
    
    cd "$BACKUP_DIR"
    tar -czf "$BACKUP_FILE" . 2>/dev/null || error "压缩失败"
    
    BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    log "备份压缩完成: $BACKUP_FILE ($BACKUP_SIZE)"
    
    # 返回备份文件路径（确保只有路径）
    echo "$BACKUP_FILE"
}

# Git操作
setup_git() {
    log "设置Git仓库..."
    rm -rf "$REPO_DIR"
    mkdir -p "$REPO_DIR"
    
    cd "$REPO_DIR"
    git init
    git config user.name "OpenClaw Backup"
    git config user.email "backup@openclaw.ai"
    
    # 添加远程仓库
    git remote add origin "https://x-access-token:${GITHUB_TOKEN}@github.com/Daligulu/openclaw-lulu.git"
    
    # 拉取现有内容或初始化
    if git pull origin main 2>/dev/null; then
        log "成功拉取远程仓库"
    else
        warning "初始拉取失败，可能是空仓库"
        # 如果是空仓库，先创建README
        echo "# OpenClaw Backup Repository" > README.md
        echo "自动备份的OpenClaw配置文件" >> README.md
        echo "" >> README.md
        echo "备份时间: $(date)" >> README.md
        git add README.md
        git commit -m "初始化备份仓库"
        git branch -M main
    fi
}

# 生成版本差异报告
generate_changelog() {
    local backup_file="$1"
    log "生成版本差异报告..."
    
    # 获取上一个备份文件
    PREV_BACKUP=$(find . -name "openclaw-backup-*.tar.gz" -type f | sort -r | head -2 | tail -1)
    
    if [ -z "$PREV_BACKUP" ] || [ ! -f "$PREV_BACKUP" ]; then
        echo "首次备份"
        return
    fi
    
    # 简单比较：文件大小和修改时间
    PREV_SIZE=$(stat -c%s "$PREV_BACKUP" 2>/dev/null || echo "0")
    CURR_SIZE=$(stat -c%s "$backup_file" 2>/dev/null || echo "0")
    PREV_TIME=$(stat -c%y "$PREV_BACKUP" 2>/dev/null | cut -d' ' -f1)
    CURR_TIME=$(date '+%Y-%m-%d')
    
    # 计算变化百分比
    if [ "$PREV_SIZE" -gt 0 ]; then
        SIZE_DIFF=$((CURR_SIZE - PREV_SIZE))
        SIZE_PERCENT=$((SIZE_DIFF * 100 / PREV_SIZE))
    else
        SIZE_DIFF=$CURR_SIZE
        SIZE_PERCENT=100
    fi
    
    # 构建变更概述
    CHANGELOG="📊 备份统计：\n"
    CHANGELOG+="  • 前次备份: $PREV_TIME ($((PREV_SIZE/1024))KB)\n"
    CHANGELOG+="  • 本次备份: $CURR_TIME ($((CURR_SIZE/1024))KB)\n"
    
    if [ "$SIZE_DIFF" -gt 0 ]; then
        CHANGELOG+="  • 大小变化: +$((SIZE_DIFF/1024))KB (+${SIZE_PERCENT}%)\n"
    elif [ "$SIZE_DIFF" -lt 0 ]; then
        CHANGELOG+="  • 大小变化: $((SIZE_DIFF/1024))KB (${SIZE_PERCENT}%)\n"
    else
        CHANGELOG+="  • 大小变化: 无变化\n"
    fi
    
    # 检查关键文件变化
    CHANGELOG+="\n🔍 关键文件状态：\n"
    
    # 列出最近修改的配置文件
    CONFIG_CHANGES=$(find /root/.openclaw -name "*.json" -o -name "*.md" -o -name "*.sh" -type f -mtime -1 2>/dev/null | head -5)
    
    if [ -n "$CONFIG_CHANGES" ]; then
        CHANGELOG+="最近24小时修改的文件：\n"
        echo "$CONFIG_CHANGES" | sed 's|/root/.openclaw/||' | while read file; do
            CHANGELOG+="  • $file\n"
        done
    else
        CHANGELOG+="配置文件无近期修改\n"
    fi
    
    # 检查记忆文件更新
    if [ -f "/root/.openclaw/workspace/memory/$(date '+%Y-%m-%d').md" ]; then
        MEMORY_LINES=$(wc -l < "/root/.openclaw/workspace/memory/$(date '+%Y-%m-%d').md" 2>/dev/null || echo "0")
        CHANGELOG+="今日记忆记录: ${MEMORY_LINES}行\n"
    fi
    
    # 检查SOUL.md是否更新
    SOUL_MTIME=$(stat -c%y "/root/.openclaw/workspace/SOUL.md" 2>/dev/null | cut -d' ' -f1)
    if [ "$SOUL_MTIME" = "$CURR_TIME" ]; then
        CHANGELOG+="身份文件今日有更新\n"
    fi
    
    echo -e "$CHANGELOG"
}

push_to_github() {
    local backup_file="$1"
    
    log "推送备份到GitHub..."
    cd "$REPO_DIR"
    
    # 清理旧备份（保留最近7天）
    find . -name "openclaw-backup-*.tar.gz" -mtime +7 -delete 2>/dev/null || true
    
    # 复制新备份
    cp "$backup_file" .
    
    # 生成版本差异报告
    CHANGELOG=$(generate_changelog "$backup_file" 2>/dev/null)
    
    # 提交
    git add .
    if git diff --cached --quiet; then
        warning "没有变化需要提交"
        return
    fi
    
    # 构建提交信息
    BACKUP_NAME=$(basename "$backup_file" .tar.gz)
    COMMIT_MSG="🔧 OpenClaw备份 $BACKUP_NAME"
    
    # 添加详细变更说明（使用中国时区）
    COMMIT_BODY="备份时间: $(date '+%Y-%m-%d %H:%M:%S %Z')\n"
    COMMIT_BODY+="时区: 中国上海 (GMT+8)\n"
    COMMIT_BODY+="备份文件: $BACKUP_NAME.tar.gz\n"
    
    if [ -n "$CHANGELOG" ] && [ ! "$CHANGELOG" = "首次备份" ]; then
        COMMIT_BODY+="\n📋 版本变更概述：\n$CHANGELOG\n"
    else
        COMMIT_BODY+="\n📋 版本变更概述：首次备份\n"
    fi
    
    COMMIT_BODY+="\n💾 恢复方式：解压后运行 restore-openclaw.sh"
    
    # 提交（使用多行commit message）
    git commit -m "$COMMIT_MSG" -m "$COMMIT_BODY"
    
    # 推送（最多重试3次）
    for i in {1..3}; do
        if git push origin main; then
            success "备份已推送到GitHub"
            log "提交信息：$COMMIT_MSG"
            log "变更概述：$CHANGELOG"
            return
        fi
        warning "推送失败，重试 $i/3..."
        sleep 5
    done
    
    error "GitHub推送失败"
}

# 清理
cleanup() {
    log "清理临时文件..."
    rm -rf "$BACKUP_DIR" "$REPO_DIR" 2>/dev/null || true
    find /tmp -name "openclaw-backup-*.tar.gz" -mtime +1 -delete 2>/dev/null || true
}

# 主函数
main() {
    log "=== OpenClaw备份开始 ==="
    
    # 检查源目录
    if [ ! -d "$BACKUP_SOURCE" ]; then
        error "备份源目录不存在: $BACKUP_SOURCE"
    fi
    
    # 执行备份流程
    prepare_backup
    backup_files
    BACKUP_FILE=$(compress_backup 2>&1 | tail -1)  # 只获取最后一行（文件路径）
    setup_git
    push_to_github "$BACKUP_FILE"
    
    success "=== OpenClaw备份完成 ==="
    
    # 推送详细报告
    send_detailed_report "$BACKUP_FILE"
    
    # 清理
    cleanup
}

# 推送详细报告
send_detailed_report() {
    local backup_file="$1"
    log "推送详细备份报告..."
    
    # 调用报告推送脚本
    if [ -f "/root/.openclaw/workspace/backup-report-push.sh" ]; then
        /root/.openclaw/workspace/backup-report-push.sh
        if [ $? -eq 0 ]; then
            success "详细报告已推送"
        else
            warning "报告推送失败，但备份已完成"
        fi
    else
        warning "报告推送脚本不存在，跳过报告推送"
    fi
}

# 简单通知函数（可根据需要扩展）
send_notification() {
    local message="$1"
    # 这里可以添加Telegram、邮件等通知
    echo "$message" >> "$LOG_FILE"
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi