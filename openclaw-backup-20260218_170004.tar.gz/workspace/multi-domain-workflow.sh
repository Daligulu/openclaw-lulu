#!/bin/bash
# 多领域热点工作流 - AI + 篮球 + 宠物

echo "🌐 多领域热点工作流启动"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 配置
BASE_DIR="/root/.openclaw/workspace"
CONFIG_AI="$BASE_DIR/configs/ai-digest-optimized"
CONFIG_BASKETBALL="$BASE_DIR/configs/basketball-digest/defaults"
CONFIG_PETS="$BASE_DIR/configs/pets-digest/defaults"
OUTPUT_DIR="$BASE_DIR/multi-domain-hotspots"
LOG_FILE="/var/log/multi-domain-$(date +%Y%m%d).log"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 创建目录
mkdir -p "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR/ai"
mkdir -p "$OUTPUT_DIR/basketball"
mkdir -p "$OUTPUT_DIR/pets"
mkdir -p "$OUTPUT_DIR/combined"
mkdir -p "$OUTPUT_DIR/archive"
mkdir -p "$(dirname "$LOG_FILE")"

# 记录开始
echo "=== 多领域热点收集开始 ===" >> "$LOG_FILE"
echo "开始时间: $(date)" >> "$LOG_FILE"
echo "领域: AI + 篮球 + 宠物" >> "$LOG_FILE"

# 1. 设置环境
echo "1. 设置环境..." | tee -a "$LOG_FILE"
export BRAVE_API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
export TZ='Asia/Shanghai'
export TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-8289858508:AAGacfYMR0PmKVvMHfrSWTntccwxB5LsQfA}"
export TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-8375286112}"

cd /root/.openclaw/workspace/skills/tech-news-digest || {
    echo "❌ 无法进入技能目录" | tee -a "$LOG_FILE"
    exit 1
}

# 2. AI领域热点收集
echo "2. 收集AI热点..." | tee -a "$LOG_FILE"
AI_DATA_FILE="/tmp/ai-multi-$TIMESTAMP.json"
AI_REPORT_FILE="$OUTPUT_DIR/ai/daily-$TIMESTAMP.md"
AI_SUMMARY_FILE="$OUTPUT_DIR/ai/summary-$TIMESTAMP.md"

python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_AI" \
  --hours 24 \
  --output "$AI_DATA_FILE" \
  2>&1 | tee -a "$LOG_FILE"

if [ -f "$AI_DATA_FILE" ]; then
    AI_SIZE=$(wc -c < "$AI_DATA_FILE")
    echo "✅ AI数据收集完成: $AI_SIZE 字节" | tee -a "$LOG_FILE"
    
    # 生成AI报告
    python3 /root/.openclaw/workspace/scripts/optimized-scoring-report.py "$AI_DATA_FILE" "$AI_REPORT_FILE" 2>&1 | tee -a "$LOG_FILE"
else
    echo "❌ AI数据收集失败" | tee -a "$LOG_FILE"
fi

# 3. 篮球领域热点收集
echo "3. 收集篮球热点..." | tee -a "$LOG_FILE"
BASKETBALL_DATA_FILE="/tmp/basketball-$TIMESTAMP.json"
BASKETBALL_REPORT_FILE="$OUTPUT_DIR/basketball/daily-$TIMESTAMP.md"
BASKETBALL_SUMMARY_FILE="$OUTPUT_DIR/basketball/summary-$TIMESTAMP.md"

python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_BASKETBALL" \
  --hours 24 \
  --output "$BASKETBALL_DATA_FILE" \
  2>&1 | tee -a "$LOG_FILE"

if [ -f "$BASKETBALL_DATA_FILE" ]; then
    BB_SIZE=$(wc -c < "$BASKETBALL_DATA_FILE")
    echo "✅ 篮球数据收集完成: $BB_SIZE 字节" | tee -a "$LOG_FILE"
    
    # 生成篮球报告（使用简化版本）
    python3 -c "
import json
import sys
from datetime import datetime

with open('$BASKETBALL_DATA_FILE', 'r') as f:
    data = json.load(f)

now = datetime.now()
with open('$BASKETBALL_REPORT_FILE', 'w', encoding='utf-8') as f:
    f.write(f'# 🏀 篮球热点日报\\n')
    f.write(f'**生成时间**: {now.strftime(\"%Y-%m-%d %H:%M:%S %Z\")}\\n')
    
    topics = data.get('topics', {})
    total = 0
    for topic_name, topic_data in topics.items():
        articles = topic_data.get('articles', [])
        total += len(articles)
    
    f.write(f'**热点数量**: {total}条\\n\\n')
    
    if topics:
        for topic_name, topic_data in topics.items():
            articles = topic_data.get('articles', [])
            if articles:
                # 主题映射
                topic_map = {
                    'nba-breaking': '🚨 NBA突发',
                    'nba-analysis': '📊 NBA分析',
                    'nba-rumors': '🗣️ NBA流言',
                    'cba-news': '🇨🇳 CBA新闻',
                    'fiba-international': '🌍 国际篮球',
                    'streetball-culture': '🏀 街头篮球'
                }
                
                display_name = topic_map.get(topic_name, f'📁 {topic_name}')
                f.write(f'## {display_name} ({len(articles)}条)\\n')
                
                for i, article in enumerate(articles[:5], 1):
                    title = article.get('title', '')
                    if len(title) > 70:
                        title = title[:67] + '...'
                    
                    f.write(f'{i}. **{title}**\\n')
                    source = article.get('source_name', article.get('source', '未知'))
                    f.write(f'   来源: {source}\\n')
                    
                    link = article.get('link', article.get('url', ''))
                    if link:
                        f.write(f'   [链接]({link})\\n')
                    
                    f.write('\\n')
                
                f.write('\\n')
    else:
        f.write('## ⚠️ 今日无篮球热点\\n')
    
    f.write('---\\n')
    f.write('*数据源: NBA/CBA/FIBA官方 + 篮球社区*\\n')
" 2>&1 | tee -a "$LOG_FILE"
else
    echo "❌ 篮球数据收集失败" | tee -a "$LOG_FILE"
fi

# 4. 宠物领域热点收集
echo "4. 收集宠物热点..." | tee -a "$LOG_FILE"
PETS_DATA_FILE="/tmp/pets-$TIMESTAMP.json"
PETS_REPORT_FILE="$OUTPUT_DIR/pets/daily-$TIMESTAMP.md"
PETS_SUMMARY_FILE="$OUTPUT_DIR/pets/summary-$TIMESTAMP.md"

python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_PETS" \
  --hours 24 \
  --output "$PETS_DATA_FILE" \
  2>&1 | tee -a "$LOG_FILE"

if [ -f "$PETS_DATA_FILE" ]; then
    PETS_SIZE=$(wc -c < "$PETS_DATA_FILE")
    echo "✅ 宠物数据收集完成: $PETS_SIZE 字节" | tee -a "$LOG_FILE"
    
    # 生成宠物报告
    python3 -c "
import json
import sys
from datetime import datetime

with open('$PETS_DATA_FILE', 'r') as f:
    data = json.load(f)

now = datetime.now()
with open('$PETS_REPORT_FILE', 'w', encoding='utf-8') as f:
    f.write(f'# 🐕 宠物热点日报\\n')
    f.write(f'**生成时间**: {now.strftime(\"%Y-%m-%d %H:%M:%S %Z\")}\\n')
    
    topics = data.get('topics', {})
    total = 0
    for topic_name, topic_data in topics.items():
        articles = topic_data.get('articles', [])
        total += len(articles)
    
    f.write(f'**热点数量**: {total}条\\n\\n')
    
    if topics:
        for topic_name, topic_data in topics.items():
            articles = topic_data.get('articles', [])
            if articles:
                # 主题映射
                topic_map = {
                    'dog-health': '❤️ 狗狗健康',
                    'dog-training': '🎓 狗狗训练',
                    'dog-breeds': '🐕 狗狗品种',
                    'pet-products': '🛒 宠物产品',
                    'pet-nutrition': '🍖 宠物营养',
                    'pet-viral': '🔥 宠物热点'
                }
                
                display_name = topic_map.get(topic_name, f'📁 {topic_name}')
                f.write(f'## {display_name} ({len(articles)}条)\\n')
                
                for i, article in enumerate(articles[:5], 1):
                    title = article.get('title', '')
                    if len(title) > 70:
                        title = title[:67] + '...'
                    
                    f.write(f'{i}. **{title}**\\n')
                    source = article.get('source_name', article.get('source', '未知'))
                    f.write(f'   来源: {source}\\n')
                    
                    link = article.get('link', article.get('url', ''))
                    if link:
                        f.write(f'   [链接]({link})\\n')
                    
                    f.write('\\n')
                
                f.write('\\n')
    else:
        f.write('## ⚠️ 今日无宠物热点\\n')
    
    f.write('---\\n')
    f.write('*数据源: 宠物健康媒体 + 宠物社区 + 产品资讯*\\n')
" 2>&1 | tee -a "$LOG_FILE"
else
    echo "❌ 宠物数据收集失败" | tee -a "$LOG_FILE"
fi

# 5. 生成合并摘要（用于Telegram推送）
echo "5. 生成合并摘要..." | tee -a "$LOG_FILE"
COMBINED_SUMMARY="$OUTPUT_DIR/combined/summary-$TIMESTAMP.md"

cat > "$COMBINED_SUMMARY" << EOF
🌐 多领域热点摘要
时间: $(date '+%Y-%m-%d %H:%M')

🤖 AI科技热点
$(if [ -f "$AI_REPORT_FILE" ]; then
    grep -A5 "热点数量" "$AI_REPORT_FILE" | head -2
    echo ""
    grep -A3 "## 🚀" "$AI_REPORT_FILE" | head -5 | sed 's/### /• /'
else
    echo "  今日无AI热点"
fi)

🏀 篮球热点
$(if [ -f "$BASKETBALL_REPORT_FILE" ]; then
    grep -A5 "热点数量" "$BASKETBALL_REPORT_FILE" | head -2
    echo ""
    grep -B2 -A1 "1\." "$BASKETBALL_REPORT_FILE" | head -3 | sed 's/1\. /• /'
else
    echo "  今日无篮球热点"
fi)

🐕 宠物热点
$(if [ -f "$PETS_REPORT_FILE" ]; then
    grep -A5 "热点数量" "$PETS_REPORT_FILE" | head -2
    echo ""
    grep -B2 -A1 "1\." "$PETS_REPORT_FILE" | head -3 | sed 's/1\. /• /'
else
    echo "  今日无宠物热点"
fi)

---
#多领域热点 #AI #篮球 #宠物 #每日推送
EOF

echo "✅ 合并摘要生成完成" | tee -a "$LOG_FILE"

# 6. 发送到Telegram
echo "6. 发送到Telegram..." | tee -a "$LOG_FILE"

if [ -f "$COMBINED_SUMMARY" ] && [ -s "$COMBINED_SUMMARY" ]; then
    /root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh "$COMBINED_SUMMARY" 2>&1 | tee -a "$LOG_FILE"
else
    echo "⚠️  合并摘要为空，跳过Telegram推送" | tee -a "$LOG_FILE"
fi

# 7. 归档处理
echo "7. 归档处理..." | tee -a "$LOG_FILE"

# 归档数据文件
for file in "$AI_DATA_FILE" "$BASKETBALL_DATA_FILE" "$PETS_DATA_FILE"; do
    if [ -f "$file" ]; then
        ARCHIVE_FILE="$OUTPUT_DIR/archive/$(basename "$file").gz"
        gzip -c "$file" > "$ARCHIVE_FILE" 2>/dev/null && \
            echo "✅ 归档: $(basename "$file")" | tee -a "$LOG_FILE"
    fi
done

# 清理临时文件
find /tmp -name "ai-multi-*" -mtime +1 -delete 2>/dev/null
find /tmp -name "basketball-*" -mtime +1 -delete 2>/dev/null
find /tmp -name "pets-*" -mtime +1 -delete 2>/dev/null
find /tmp -name "td-*.json" -mtime +1 -delete 2>/dev/null

# 8. 生成统计信息
echo "8. 生成统计信息..." | tee -a "$LOG_FILE"

STATS_FILE="$OUTPUT_DIR/combined/stats-$TIMESTAMP.json"

cat > "$STATS_FILE" << EOF
{
  "timestamp": "$(date -Iseconds)",
  "workflow": "multi-domain-hotspots",
  "domains": ["ai", "basketball", "pets"],
  "files": {
    "ai_report": "$(basename "$AI_REPORT_FILE")",
    "basketball_report": "$(basename "$BASKETBALL_REPORT_FILE")",
    "pets_report": "$(basename "$PETS_REPORT_FILE")",
    "combined_summary": "$(basename "$COMBINED_SUMMARY")",
    "log": "$(basename "$LOG_FILE")"
  },
  "status": "completed",
  "duration_seconds": "$SECONDS"
}
EOF

echo "📊 统计文件: $STATS_FILE" | tee -a "$LOG_FILE"

# 9. 完成
echo "" | tee -a "$LOG_FILE"
echo "=== 多领域热点收集完成 ===" | tee -a "$LOG_FILE"
echo "完成时间: $(date)" | tee -a "$LOG_FILE"
echo "总耗时: ${SECONDS}秒" | tee -a "$LOG_FILE"
echo "输出文件:" | tee -a "$LOG_FILE"
echo "  • AI报告: $AI_REPORT_FILE" | tee -a "$LOG_FILE"
echo "  • 篮球报告: $BASKETBALL_REPORT_FILE" | tee -a "$LOG_FILE"
echo "  • 宠物报告: $PETS_REPORT_FILE" | tee -a "$LOG_FILE"
echo "  • 合并摘要: $COMBINED_SUMMARY" | tee -a "$LOG_FILE"
echo "  • 统计信息: $STATS_FILE" | tee -a "$LOG_FILE"
echo "  • 运行日志: $LOG_FILE" | tee -a "$LOG_FILE"

echo ""
echo "🎉 多领域热点工作流执行完成！"
echo "查看合并摘要: cat $COMBINED_SUMMARY"
echo "查看日志: tail -20 $LOG_FILE"