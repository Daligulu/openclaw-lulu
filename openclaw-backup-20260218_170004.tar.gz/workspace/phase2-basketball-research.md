# 第二阶段：篮球领域热点追踪预研

## 领域范围
- **NBA** (美国职业篮球): 主要热点来源
- **FIBA** (国际篮联): 国际赛事
- **CBA** (中国篮球协会): 国内联赛  
- **野球/街球**: 民间篮球文化

## 数据源收集

### 1. NBA官方和权威媒体

#### 国际源 (英文)
```yaml
rss:
  # NBA官方
  - url: "https://www.nba.com/news/rss.xml"
    name: "NBA Official News"
    priority: true
    language: "en"
    
  - url: "https://www.espn.com/espn/rss/nba/news"
    name: "ESPN NBA"
    priority: true
    language: "en"
    
  - url: "https://www.cbssports.com/rss/headlines/nba/"
    name: "CBS Sports NBA"
    priority: true
    language: "en"
    
  - url: "https://www.si.com/.rss/full/%7B%22section%22%3A%22nba%22%7D"
    name: "Sports Illustrated NBA"
    priority: true
    language: "en"
    
  - url: "https://bleacherreport.com/nba"
    name: "Bleacher Report NBA"
    priority: true
    language: "en"
    
  # 球队官方（示例）
  - url: "https://www.nba.com/lakers/news/rss.xml"
    name: "LA Lakers News"
    priority: false
    language: "en"
    
  - url: "https://www.nba.com/warriors/news/rss.xml"
    name: "Golden State Warriors News"
    priority: false
    language: "en"
```

#### 国内源 (中文)
```yaml
rss:
  # 国内篮球媒体
  - url: "https://sports.qq.com/rss_nba.htm"
    name: "腾讯NBA"
    priority: true
    language: "zh"
    
  - url: "https://sports.sina.com.cn/rss/nba/all.xml"
    name: "新浪NBA"
    priority: true
    language: "zh"
    
  - url: "https://voice.hupu.com/nba/rss"
    name: "虎扑NBA"
    priority: true
    language: "zh"
    
  - url: "https://www.zhibo8.cc/rss/nba.xml"
    name: "直播吧NBA"
    priority: true
    language: "zh"
    
  - url: "https://www.dongqiudi.com/rss/nba"
    name: "懂球帝NBA"
    priority: true
    language: "zh"
```

### 2. FIBA国际赛事
```yaml
rss:
  - url: "https://www.fiba.basketball/rss/news"
    name: "FIBA News"
    priority: true
    language: "en"
    
  - url: "https://www.fiba.basketball/rss/events"
    name: "FIBA Events"
    priority: true
    language: "en"
    
  # 世界杯、奥运会等大赛
  - url: "https://www.fiba.basketball/basketballworldcup/rss"
    name: "FIBA World Cup"
    priority: true
    language: "en"
```

### 3. CBA中国篮球
```yaml
rss:
  - url: "http://www.cba.net.cn/rss/news.xml"
    name: "CBA官方新闻"
    priority: true
    language: "zh"
    
  - url: "https://sports.qq.com/rss_cba.htm"
    name: "腾讯CBA"
    priority: true
    language: "zh"
    
  - url: "https://sports.sina.com.cn/rss/cba/all.xml"
    name: "新浪CBA"
    priority: true
    language: "zh"
    
  - url: "https://voice.hupu.com/cba/rss"
    name: "虎扑CBA"
    priority: true
    language: "zh"
```

### 4. 野球/街球文化
```yaml
# 这类源较少，主要靠搜索和社交媒体
search:
  queries:
    - "街头篮球 比赛"
    - "野球比赛 2026"
    - "民间篮球赛事"
    - "篮球网红 最新"
    - "AND1 streetball"
    - "Drew League"
    
  # 可能的RSS源
  rss:
    - url: "https://www.slamonline.com/feed/"
      name: "SLAM Magazine"
      priority: true
      language: "en"
      topics: ["streetball", "culture"]
      
    - url: "https://ballislife.com/feed/"
      name: "BallisLife"
      priority: true
      language: "en"
      topics: ["streetball", "highlights"]
```

### 5. Twitter/X KOLs (需要API令牌)
```yaml
twitter:
  # NBA爆料大神
  - handle: "ShamsCharania"
    name: "Shams Charania"
    priority: true
    topics: ["nba-news", "trade-rumors"]
    
  - handle: "wojespn"
    name: "Adrian Wojnarowski"
    priority: true
    topics: ["nba-news", "breaking-news"]
    
  - handle: "ChrisBHaynes"
    name: "Chris Haynes"
    priority: true
    topics: ["nba-news"]
    
  # 球员和球队
  - handle: "KingJames"
    name: "LeBron James"
    priority: true
    topics: ["player-news"]
    
  - handle: "stephencurry30"
    name: "Stephen Curry"
    priority: true
    topics: ["player-news"]
    
  # 国内篮球KOL
  - handle: "yangyiyangyi"  # 杨毅
    name: "杨毅"
    priority: true
    topics: ["cba", "analysis"]
    
  - handle: "suqunbasketball"  # 苏群
    name: "苏群"
    priority: true
    topics: ["cba", "analysis"]
```

## 搜索关键词配置

### 实时热点追踪
```yaml
search:
  queries:
    # 比赛相关
    - "NBA score today"
    - "NBA比赛结果"
    - "全明星赛 2026"
    - "playoffs 2026"
    
    # 球员相关
    - "LeBron James injury"
    - "Stephen Curry record"
    - "球员交易 流言"
    - "自由球员 签约"
    
    # 争议和热点
    - "NBA controversy"
    - "裁判争议"
    - "球迷冲突"
    - "社交媒体热议"
    
    # 中国球员
    - "中国球员 NBA"
    - "周琦 CBA"
    - "中国男篮"
    
    # 街球文化
    - "streetball highlights"
    - "街头篮球 视频"
    - "篮球网红 抖音"
```

## 话题分类

### 篮球话题体系
```yaml
topics:
  - id: "nba-game"
    label: "NBA比赛"
    emoji: "🏀"
    sub_topics:
      - "regular-season"
      - "playoffs"
      - "all-star"
      - "finals"
      
  - id: "player-news"
    label: "球员动态"
    emoji: "👤"
    sub_topics:
      - "injury"
      - "trade"
      - "contract"
      - "retirement"
      - "record"
      
  - id: "team-news"
    label: "球队新闻"
    emoji: "🏆"
    sub_topics:
      - "roster"
      - "coaching"
      - "management"
      
  - id: "cba-news"
    label: "CBA新闻"
    emoji: "🇨🇳"
    sub_topics:
      - "cba-game"
      - "cba-player"
      - "cba-team"
      
  - id: "fiba-news"
    label: "国际篮球"
    emoji: "🌍"
    sub_topics:
      - "world-cup"
      - "olympics"
      - "asia-cup"
      
  - id: "streetball"
    label: "街头篮球"
    emoji: "🛹"
    sub_topics:
      - "highlight"
      - "event"
      - "influencer"
      
  - id: "controversy"
    label: "争议话题"
    emoji: "🔥"
    sub_topics:
      - "referee"
      - "fight"
      - "social-media"
```

## 评分权重调整

### 篮球领域特殊性
```yaml
processing:
  scoring:
    # 基础权重
    priority_source: 3      # 官方/权威媒体
    multi_source: 5         # 多源报道
    recency: 3             # 篮球新闻时效性更重要
    engagement: 2          # 互动量（评论、转发）
    
    # 篮球特有
    star_player: 4         # 涉及巨星球员
    chinese_relevant: 3    # 与中国相关
    controversy: 4         # 争议性话题
    breaking_news: 5       # 突发新闻
    
    # 比赛相关
    playoff_game: 4        # 季后赛
    rivalry_game: 3        # 宿敌对决
    record_breaking: 5     # 破纪录
```

## 输出格式定制

### 篮球专用模板
```yaml
templates:
  markdown:
    header: |
      # 🏀 篮球热点日报 | {{date}}
      **统计**: {{item_count}}条热点 | 高热度: {{high_score_count}}条
      
    item: |
      ## {{title}} ({{score}}分)
      **分类**: {{topics}}
      **来源**: {{sources}}
      **时间**: {{time}}
      
      {{summary}}
      
      {% if players %}**涉及球员**: {{players}}{% endif %}
      {% if teams %}**涉及球队**: {{teams}}{% endif %}
      
      🔗 [详细报道]({{url}})
      
    section_header: |
      ### {{topic_label}} ({{count}}条)
      
    footer: |
      ---
      *数据来源: {{source_count}}个篮球媒体 | 更新时间: {{update_time}}*
      *明日重点关注: {{tomorrow_focus}}*
```

## 实施步骤建议

### 阶段2.1: NBA核心源配置 (3天)
1. **配置NBA官方和ESPN等核心源**
2. **测试英文源获取和解析**
3. **建立基础评分体系**

### 阶段2.2: 国内源集成 (2天)
1. **添加腾讯、新浪、虎扑等中文源**
2. **处理中文编码和内容解析**
3. **测试中英文混合摘要**

### 阶段2.3: CBA和FIBA扩展 (2天)
1. **添加CBA官方和媒体源**
2. **集成FIBA国际赛事**
3. **测试多联赛混合处理**

### 阶段2.4: 街球文化补充 (2天)
1. **配置街球相关搜索关键词**
2. **添加街球媒体和社区源**
3. **测试文化类内容识别**

## 技术挑战与应对

### 1. 多语言处理
- **挑战**: 中英文混合，术语翻译
- **应对**: 建立篮球术语词典，统一翻译

### 2. 实时性要求
- **挑战**: 比赛结果需要快速更新
- **应对**: 提高抓取频率，比赛期间特殊处理

### 3. 数据量大
- **挑战**: 每天数百条篮球新闻
- **应对**: 严格过滤，只保留高热度内容

### 4. 图片和视频内容
- **挑战**: 篮球新闻常含精彩集锦
- **应对**: 提取视频链接，在摘要中标注

## 与AI领域的差异

### 内容特性对比
| 维度 | AI领域 | 篮球领域 |
|------|--------|----------|
| 时效性 | 中等（几天内） | 高（几小时内） |
| 情感色彩 | 理性分析为主 | 强烈情感倾向 |
| 数据形式 | 技术文档、论文 | 比赛数据、集锦 |
| 热点周期 | 数天到数周 | 数小时到数天 |
| 地域性 | 全球性 | 强地域性（NBA/CBA） |

### 配置调整重点
1. **更高抓取频率**: 篮球新闻需要更及时
2. **情感分析**: 识别争议和热点话题
3. **球员/球队识别**: 自动标注相关实体
4. **比赛数据集成**: 结合比赛统计

## 预期输出示例

### 篮球热点日报
```
🏀 篮球热点日报 | 2026-02-17

🔥 今日头条 (评分>9)
1. 詹姆斯连续21年全明星首发纪录终结
   • 评分: 9.8/10
   • 来源: ESPN + 腾讯NBA + 虎扑
   • 涉及: LeBron James, 全明星赛
   • 热度: 社交媒体热议，虎扑帖子5000+回复

2. 勇士vs湖人加时赛冲突：追梦格林被驱逐
   • 评分: 9.5/10  
   • 来源: CBS Sports + 新浪NBA
   • 涉及: Draymond Green, 比赛冲突
   • 热度: 比赛关键时刻争议判罚

📊 比赛结果
• 湖人 112-110 勇士 (加时)
• 凯尔特人 98-95 雄鹿
• 辽宁 105-100 广东 (CBA)

👤 球员动态
• 库里左膝扭伤，预计缺席2周
• 周琦CBA单场35分创赛季新高

🌍 国际篮球
• 中国男篮公布世界杯预选赛名单
• 法国队公布奥运会集训名单

🛹 街球文化
• 北京街头篮球赛周末开打
• 抖音篮球网红"暴扣哥"粉丝破百万
```

## 成功指标

### 篮球领域特有指标
- [ ] **比赛覆盖率**: 重要比赛报道率 > 95%
- [ ] **时效性**: 比赛结果更新延迟 < 30分钟
- [ ] **球员识别准确率**: > 90%
- [ ] **中英文混合处理**: 无乱码，术语统一
- [ ] **争议话题识别**: 准确率 > 85%

## 与第一阶段的关系

### 复用组件
1. **基础框架**: 相同的pipeline架构
2. **搜索功能**: Brave Search API配置
3. **输出系统**: Telegram/文件输出
4. **调度机制**: 定时任务管理

### 差异处理
1. **独立配置文件**: 篮球专用配置
2. **不同评分权重**: 篮球特有评分规则
3. **专用模板**: 篮球内容展示格式
4. **特殊处理逻辑**: 比赛数据解析

## 下一步行动

### 立即开始
1. **收集验证RSS源**: 测试各篮球源的可访问性
2. **建立术语词典**: 篮球中英文术语对照
3. **设计测试用例**: 典型篮球热点场景

### 依赖准备
1. **Twitter/X API**: 如需集成篮球KOL
2. **比赛数据API**: 考虑集成实时比分
3. **图片处理**: 如需提取比赛集锦

第一阶段成功后，可以快速启动篮球领域的配置工作。