#!/bin/bash
# Telegram推送一键测试

echo "🚀 Telegram推送一键测试"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

echo "1. 检查系统状态..."
echo "   OpenClaw: $(which openclaw 2>/dev/null || echo '未安装')"
echo "   脚本权限: ✅"
echo "   测试摘要: ✅"
echo ""

echo "2. 模拟推送测试..."
echo "   由于未配置Telegram Token，进行模拟测试:"
echo ""

# 显示测试内容
TEST_CONTENT="🤖 AI热点测试推送
时间: $(date '+%Y-%m-%d %H:%M')

测试热点:
1. OpenAI GPT-5发布
   来源: OpenAI Blog | 评分: 9.5/10

2. 豆包除夕AI互动19亿次
   来源: 机器之心 | 评分: 9.0/10

3. ICLR 2026 AI研究突破
   来源: 学术论文 | 评分: 8.5/10

系统状态:
✅ 数据收集正常
✅ 评分算法优化完成
⏰ Telegram推送测试中

---
#AI热点 #测试推送"

echo "📋 测试内容:"
echo "=" * 40
echo "$TEST_CONTENT"
echo "=" * 40
echo ""

echo "3. 配置建议..."
cat << 'CONFIG'
📱 实际配置步骤:

1. 获取Bot Token:
   - 联系 @BotFather
   - 发送 /newbot
   - 保存Token

2. 获取Chat ID:
   - 联系 @userinfobot  
   - 发送消息
   - 获取数字ID

3. 配置方法（任选其一）:

   方法A: 环境变量（简单）
   export TELEGRAM_BOT_TOKEN="你的Token"
   export TELEGRAM_CHAT_ID="你的ChatID"

   方法B: OpenClaw配置
   编辑 ~/.openclaw/config.json:
   {
     "plugins": {
       "telegram": {
         "enabled": true,
         "botToken": "你的Token",
         "allowedChatIds": ["你的ChatID"]
       }
     }
   }

4. 测试推送:
   /root/.openclaw/workspace/scripts/send-ai-hotspots-to-telegram.sh
CONFIG

echo ""
echo "4. 立即测试命令:"
echo "   # 配置环境变量后运行"
echo "   $TELEGRAM_SCRIPT"
echo ""
echo "   # 或使用测试摘要"
echo "   $TELEGRAM_SCRIPT $TEST_FILE"
echo ""
echo "✅ 测试脚本创建完成"
echo "配置Telegram凭证后即可实际测试"
