#!/bin/bash
# OpenClaw恢复脚本

set -e

BACKUP_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="/root/.openclaw"

echo "开始恢复OpenClaw备份..."
echo "备份目录: $BACKUP_DIR"
echo "目标目录: $TARGET_DIR"

read -p "确认恢复？这将覆盖现有配置 [y/N]: " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "取消恢复"
    exit 1
fi

# 备份现有配置
BACKUP_TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
BACKUP_FILE="/tmp/openclaw-pre-restore-$BACKUP_TIMESTAMP.tar.gz"
echo "备份现有配置到: $BACKUP_FILE"
tar -czf "$BACKUP_FILE" -C /root .openclaw 2>/dev/null || echo "警告：备份现有配置失败"

# 恢复文件
echo "恢复文件中..."
for dir in workspace extensions agents config memory identity cron completions canvas telegram subagents credentials; do
    if [ -d "$BACKUP_DIR/$dir" ]; then
        mkdir -p "$TARGET_DIR/$dir"
        cp -r "$BACKUP_DIR/$dir/"* "$TARGET_DIR/$dir/" 2>/dev/null || true
    fi
done

# 恢复配置文件
if [ -f "$BACKUP_DIR/openclaw.json" ]; then
    cp "$BACKUP_DIR/openclaw.json" "$TARGET_DIR/"
fi

echo "✅ OpenClaw恢复完成！"
echo "⚠️  注意：可能需要重启OpenClaw服务"
echo "   运行: openclaw gateway restart"
