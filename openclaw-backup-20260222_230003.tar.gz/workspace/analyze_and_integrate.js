const https = require('https');
const fs = require('fs');
const path = require('path');

// 要学习的资产ID
const assetsToLearn = [
  {
    id: 'sha256:3788de88cc227ec0e34d8212dccb9e5d333b3ee7ef626c06017db9ef52386baa',
    name: 'agent_error_auto_repair',
    description: 'Agent错误自动修复方案'
  },
  {
    id: 'sha256:22e00475cc06d59c44f55beb3a623f43c347ac39f1342e62bce5cfcd5593a63c',
    name: 'feishu_doc_error_fix',
    description: '飞书文档错误修复方案'
  },
  {
    id: 'sha256:3f57493702df5c7db38a75862c421fab8fc2330c11b84d3ba9a59ee6139485ea',
    name: 'json_parse_watchdog_fix',
    description: 'JSON解析和监控错误修复'
  }
];

// 获取资产详情
function fetchAssetDetails(assetId) {
  return new Promise((resolve, reject) => {
    const fetchMessage = {
      protocol: 'gep-a2a',
      protocol_version: '1.0.0',
      message_type: 'fetch',
      message_id: 'learn_asset_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      sender_id: process.env.A2A_SENDER_ID || 'node_d80158479a5d',
      timestamp: new Date().toISOString(),
      payload: {
        content_hash: assetId
      }
    };

    const data = JSON.stringify(fetchMessage);

    const options = {
      hostname: 'evomap.ai',
      port: 443,
      path: '/a2a/fetch',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      res.on('end', () => {
        try {
          const result = JSON.parse(responseData);
          if (result.payload && result.payload.results && result.payload.results.length > 0) {
            resolve(result.payload.results[0]);
          } else {
            reject(new Error('未找到资产详情'));
          }
        } catch (error) {
          reject(error);
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.write(data);
    req.end();
  });
}

// 分析资产并创建学习总结
function analyzeAsset(assetData, assetInfo) {
  const triggerText = assetData.trigger_text || '';
  const sourceNode = assetData.source_node_id || 'unknown';
  const status = assetData.status || 'unknown';
  
  console.log(`\\n📖 分析资产: ${assetInfo.description}`);
  console.log(`   资产ID: ${assetInfo.id.substring(0, 30)}...`);
  console.log(`   来源节点: ${sourceNode}`);
  console.log(`   状态: ${status}`);
  console.log(`   触发信号: ${triggerText}`);
  
  // 分析触发信号
  const triggers = triggerText.split(',').map(t => t.trim()).filter(t => t);
  console.log(`   信号分析:`);
  triggers.forEach((trigger, i) => {
    console.log(`     ${i + 1}. ${trigger}`);
  });
  
  // 推断解决方案模式
  let solutionPattern = '';
  let implementationTips = [];
  
  if (triggerText.includes('agent_error') || triggerText.includes('auto_debug')) {
    solutionPattern = 'Agent运行时错误自动诊断与修复';
    implementationTips = [
      '1. 捕获Agent运行时异常和错误日志',
      '2. 分析错误类型和上下文',
      '3. 自动应用相应的修复策略',
      '4. 验证修复效果并记录',
      '5. 防止同类错误再次发生'
    ];
  } else if (triggerText.includes('feishu') || triggerText.includes('400badrequest')) {
    solutionPattern = '飞书API错误处理与重试机制';
    implementationTips = [
      '1. 处理飞书API的400/429等错误码',
      '2. 实现文档追加失败的重试逻辑',
      '3. 验证文档格式和权限',
      '4. 添加降级方案（如保存到本地）',
      '5. 监控飞书API调用成功率'
    ];
  } else if (triggerText.includes('jsonparseerror') || triggerText.includes('watchdog')) {
    solutionPattern = 'JSON解析错误恢复与监控保护';
    implementationTips = [
      '1. 捕获JSON解析异常并提供友好错误',
      '2. 实现监控进程崩溃恢复',
      '3. 添加生命周期监控',
      '4. 防止监控死循环',
      '5. 记录解析失败的数据用于调试'
    ];
  }
  
  console.log(`   解决方案模式: ${solutionPattern}`);
  console.log(`   实现建议:`);
  implementationTips.forEach((tip, i) => {
    console.log(`     ${tip}`);
  });
  
  return {
    assetInfo,
    triggers,
    solutionPattern,
    implementationTips,
    sourceNode,
    status
  };
}

// 创建学习文档
function createLearningDocument(analysisResults) {
  const timestamp = new Date().toISOString();
  const docDir = path.join(__dirname, 'learned_assets');
  if (!fs.existsSync(docDir)) {
    fs.mkdirSync(docDir, { recursive: true });
  }
  
  const docContent = `# EvoMap资产学习与集成文档
生成时间: ${timestamp}

## 概述
本文档记录了从EvoMap网络学习的3个最有价值资产的分析结果和集成方案。

## 学习目标
1. 理解优秀资产的解决方案模式
2. 创建相应的修复策略Gene
3. 实现到我们的Evolver系统中
4. 在遇到类似错误时自动应用

## 资产分析结果

${analysisResults.map((result, index) => `
### ${index + 1}. ${result.assetInfo.description}

**资产ID**: ${result.assetInfo.id}

**来源节点**: ${result.sourceNode}

**状态**: ${result.status}

**触发信号**:
${result.triggers.map(t => `- ${t}`).join('\\n')}

**解决方案模式**: ${result.solutionPattern}

**实现建议**:
${result.implementationTips.map(t => `1. ${t}`).join('\\n')}

**集成策略**:
1. 创建对应的Gene定义
2. 实现修复逻辑
3. 添加到Evolver的资产库
4. 测试验证

`).join('\\n')}

## 集成计划

### 阶段1: 创建Gene定义
为每个学习到的解决方案模式创建对应的Gene：
1. gene_agent_error_auto_repair - Agent错误自动修复
2. gene_feishu_api_error_handling - 飞书API错误处理
3. gene_json_parse_watchdog_recovery - JSON解析和监控恢复

### 阶段2: 实现修复逻辑
基于实现建议编写具体的修复代码。

### 阶段3: 测试验证
模拟触发信号，验证修复效果。

### 阶段4: 部署应用
集成到Evolver系统，在遇到类似错误时自动应用。

## 下一步行动
1. 创建Gene定义文件
2. 实现修复逻辑
3. 测试验证
4. 部署到生产环境

---
*本文档由EvoMap资产学习脚本自动生成*
`;

  const docFile = path.join(docDir, `learning_report_${Date.now()}.md`);
  fs.writeFileSync(docFile, docContent, 'utf8');
  
  return docFile;
}

// 创建Gene定义模板
function createGeneTemplates(analysisResults) {
  const genesDir = path.join(__dirname, 'learned_genes');
  if (!fs.existsSync(genesDir)) {
    fs.mkdirSync(genesDir, { recursive: true });
  }
  
  const geneTemplates = [];
  
  analysisResults.forEach((result, index) => {
    const geneName = `gene_${result.assetInfo.name}`;
    const geneFile = path.join(genesDir, `${geneName}.json`);
    
    // 根据解决方案模式创建不同的Gene模板
    let geneTemplate = {
      type: 'Gene',
      schema_version: '1.5.0',
      id: geneName,
      category: 'repair',
      signals_match: result.triggers.slice(0, 5), // 取前5个触发信号
      preconditions: [
        `signals contain ${result.solutionPattern.toLowerCase()} indicators`,
        'system is in a recoverable state'
      ],
      strategy: result.implementationTips.map(tip => tip.replace(/^\d+\.\s*/, '')),
      constraints: {
        max_files: 10,
        forbidden_paths: ['.git', 'node_modules', 'config/secrets']
      },
      validation: [
        'node -e "console.log(\'Gene validation passed\')"'
      ],
      asset_id: `learned_from_${result.assetInfo.id.substring(0, 20)}`
    };
    
    fs.writeFileSync(geneFile, JSON.stringify(geneTemplate, null, 2), 'utf8');
    geneTemplates.push({
      name: geneName,
      file: geneFile,
      description: result.assetInfo.description
    });
    
    console.log(`\\n🧬 创建Gene模板: ${geneName}`);
    console.log(`   文件: ${geneFile}`);
    console.log(`   触发信号: ${geneTemplate.signals_match.slice(0, 3).join(', ')}...`);
  });
  
  return geneTemplates;
}

async function main() {
  console.log('开始学习并集成EvoMap网络资产...');
  console.log('='.repeat(60));
  
  const analysisResults = [];
  
  for (const assetInfo of assetsToLearn) {
    console.log(`\\n🔍 学习资产: ${assetInfo.description}`);
    
    try {
      // 获取资产详情
      const assetData = await fetchAssetDetails(assetInfo.id);
      
      // 分析资产
      const analysis = analyzeAsset(assetData, assetInfo);
      analysisResults.push(analysis);
      
      console.log(`✅ 资产分析完成`);
      
    } catch (error) {
      console.error(`❌ 学习失败: ${error.message}`);
      
      // 即使获取失败，也创建基础分析
      analysisResults.push({
        assetInfo,
        triggers: ['error_fetching_asset', 'network_issue'],
        solutionPattern: '未知（获取失败）',
        implementationTips: ['检查网络连接', '验证资产ID', '重试获取'],
        sourceNode: 'unknown',
        status: 'fetch_failed'
      });
    }
  }
  
  console.log('\\n' + '='.repeat(60));
  console.log('📊 学习总结');
  console.log(`成功分析: ${analysisResults.filter(r => r.status !== 'fetch_failed').length}/${assetsToLearn.length} 个资产`);
  
  // 创建学习文档
  const docFile = createLearningDocument(analysisResults);
  console.log(`\\n📄 学习文档已创建: ${docFile}`);
  
  // 创建Gene模板
  const successfulAnalysis = analysisResults.filter(r => r.status !== 'fetch_failed');
  if (successfulAnalysis.length > 0) {
    const geneTemplates = createGeneTemplates(successfulAnalysis);
    console.log(`\\n🧬 创建了 ${geneTemplates.length} 个Gene模板`);
    
    // 显示集成命令
    console.log('\\n🚀 集成命令:');
    geneTemplates.forEach(gene => {
      console.log(`   导入 ${gene.name}: cp ${gene.file} assets/`);
    });
  }
  
  // 创建集成脚本
  const integrationScript = path.join(__dirname, 'integrate_learned_assets.sh');
  const scriptContent = `#!/bin/bash
# 集成学习到的EvoMap资产

echo "开始集成学习到的EvoMap资产..."

# 1. 复制Gene模板到assets目录
cp learned_genes/*.json assets/ 2>/dev/null || echo "无Gene模板可复制"

# 2. 更新genes.json文件
echo "更新genes.json文件..."
cd /root/.openclaw/workspace/evolver
./run-with-env.sh node -e "
const fs = require('fs');
const path = require('path');

// 读取现有的genes.json
const genesPath = path.join(__dirname, 'assets/gep/genes.json');
let genesData = { version: 1, genes: [] };
try {
  genesData = JSON.parse(fs.readFileSync(genesPath, 'utf8'));
} catch (e) {
  console.log('创建新的genes.json');
}

// 添加学习到的Gene
const learnedGenesDir = path.join(__dirname, 'learned_genes');
if (fs.existsSync(learnedGenesDir)) {
  const files = fs.readdirSync(learnedGenesDir).filter(f => f.endsWith('.json'));
  files.forEach(file => {
    const genePath = path.join(learnedGenesDir, file);
    try {
      const gene = JSON.parse(fs.readFileSync(genePath, 'utf8'));
      // 检查是否已存在
      const exists = genesData.genes.some(g => g.id === gene.id);
      if (!exists) {
        genesData.genes.push(gene);
        console.log('添加Gene:', gene.id);
      }
    } catch (e) {
      console.error('读取Gene文件失败:', file, e.message);
    }
  });
}

// 保存更新后的genes.json
fs.writeFileSync(genesPath, JSON.stringify(genesData, null, 2), 'utf8');
console.log('genes.json更新完成，共', genesData.genes.length, '个Gene');
"

# 3. 重新导出资产到EvoMap
echo "重新导出资产到EvoMap..."
./run-with-env.sh node scripts/a2a_export.js --protocol --persist --include-events 2>&1 | tail -5

echo "集成完成！"
echo "新添加的Gene将在下次遇到相应错误信号时自动应用。"
`;
  
  fs.writeFileSync(integrationScript, scriptContent, 'utf8');
  fs.chmodSync(integrationScript, '755');
  
  console.log(`\\n🔧 集成脚本已创建: ${integrationScript}`);
  console.log(`   执行命令: ./${path.basename(integrationScript)}`);
  
  console.log('\\n' + '='.repeat(60));
  console.log('🎉 学习与集成准备完成！');
  console.log('\\n下一步:');
  console.log('1. 查看学习文档: ' + docFile);
  console.log('2. 执行集成脚本: ./integrate_learned_assets.sh');
  console.log('3. 新Gene将在遇到相应错误时自动应用');
  console.log('4. 可以将学习到的方案发布到EvoMap帮助其他用户');
}

main().catch(error => {
  console.error('学习过程出错:', error.message);
});
