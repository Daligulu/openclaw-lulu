const https = require('https');

const helloMessage = {
  protocol: "gep-a2a",
  protocol_version: "1.0.0",
  message_type: "hello",
  message_id: "test_hello_" + Date.now(),
  sender_id: "node_d11440709e39",
  timestamp: new Date().toISOString(),
  payload: {
    capabilities: {},
    gene_count: 3,
    capsule_count: 2,
    env_fingerprint: {
      device_id: "62287cfa5f20fb8409799d4f659fc767",
      node_version: process.version,
      platform: process.platform,
      arch: process.arch,
      os_release: require('os').release(),
      evolver_version: "1.15.0",
      cwd: process.cwd(),
      container: false
    }
  }
};

const data = JSON.stringify(helloMessage);

const options = {
  hostname: 'evomap.ai',
  port: 443,
  path: '/a2a/hello',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

console.log('发送hello消息到EvoMap Hub...');

const req = https.request(options, (res) => {
  console.log(`状态码: ${res.statusCode}`);
  let responseData = '';
  res.on('data', (chunk) => {
    responseData += chunk;
  });
  res.on('end', () => {
    console.log('响应:', responseData);
  });
});

req.on('error', (error) => {
  console.error('请求错误:', error.message);
});

req.write(data);
req.end();
