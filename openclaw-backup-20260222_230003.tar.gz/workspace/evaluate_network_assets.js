const https = require('https');
const fs = require('fs');
const path = require('path');

// 我们的工作领域关键词
const ourDomains = [
  'openclaw', 'feishu', 'content', 'telegram', 'agent',
  'error', 'repair', 'fix', 'bug', 'optimize', 'performance',
  'database', 'postgres', 'redis', 'ai', 'llm', 'prompt'
];

// 评估资产的相关性
function evaluateRelevance(asset) {
  const trigger = (asset.trigger_text || '').toLowerCase();
  let score = 0;
  const matches = [];
  
  ourDomains.forEach(domain => {
    if (trigger.includes(domain)) {
      score += 10;
      matches.push(domain);
    }
  });
  
  // 额外加分项
  if (asset.source_node_id && asset.source_node_id.includes('openclaw')) {
    score += 20; // OpenClaw节点的资产更相关
  }
  
  if (asset.status === 'promoted') {
    score += 5; // 已推广的资产质量更高
  }
  
  return { score, matches };
}

// 获取网络资产
function fetchNetworkAssets() {
  return new Promise((resolve, reject) => {
    const fetchMessage = {
      protocol: 'gep-a2a',
      protocol_version: '1.0.0',
      message_type: 'fetch',
      message_id: 'evaluate_assets_' + Date.now(),
      sender_id: process.env.A2A_SENDER_ID || 'node_d80158479a5d',
      timestamp: new Date().toISOString(),
      payload: {
        asset_type: 'Capsule',
        limit: 30,
        filters: {}
      }
    };

    const data = JSON.stringify(fetchMessage);

    const options = {
      hostname: 'evomap.ai',
      port: 443,
      path: '/a2a/fetch',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };

    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      res.on('end', () => {
        try {
          const result = JSON.parse(responseData);
          if (result.payload && result.payload.results) {
            resolve(result.payload.results);
          } else {
            resolve([]);
          }
        } catch (error) {
          reject(error);
        }
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.write(data);
    req.end();
  });
}

async function main() {
  console.log('评估EvoMap网络资产的相关性...');
  console.log('我们的工作领域:', ourDomains.join(', '));
  
  try {
    const assets = await fetchNetworkAssets();
    console.log(`\\n获取到 ${assets.length} 个资产`);
    
    // 评估每个资产
    const evaluated = assets.map(asset => {
      const evaluation = evaluateRelevance(asset);
      return {
        asset,
        evaluation
      };
    });
    
    // 按相关性排序
    evaluated.sort((a, b) => b.evaluation.score - a.evaluation.score);
    
    // 输出前10个最相关的资产
    console.log('\\n🎯 最相关的10个网络资产:');
    const topAssets = evaluated.slice(0, 10);
    
    topAssets.forEach((item, index) => {
      const asset = item.asset;
      const evalResult = item.evaluation;
      
      console.log(`\\n${index + 1}. ${asset.asset_id.substring(0, 25)}...`);
      console.log(`   相关性分数: ${evalResult.score}`);
      console.log(`   匹配领域: ${evalResult.matches.join(', ') || '无'}`);
      console.log(`   来源节点: ${asset.source_node_id}`);
      console.log(`   状态: ${asset.status}`);
      console.log(`   触发信号: ${(asset.trigger_text || '无').substring(0, 80)}...`);
    });
    
    // 推荐集成的前3个资产
    console.log('\\n💎 推荐集成的前3个资产:');
    const recommendations = topAssets.slice(0, 3);
    
    recommendations.forEach((item, index) => {
      const asset = item.asset;
      console.log(`\\n${index + 1}. ${asset.asset_id}`);
      console.log(`   推荐理由:`);
      console.log(`     - 相关性分数: ${item.evaluation.score}`);
      console.log(`     - 匹配领域: ${item.evaluation.matches.join(', ')}`);
      console.log(`     - 来源: ${asset.source_node_id}`);
      console.log(`     - 解决: ${asset.trigger_text}`);
      
      // 生成导入命令
      console.log(`   导入命令:`);
      console.log(`     ./run-with-env.sh node scripts/a2a_ingest.js --asset-id ${asset.asset_id}`);
    });
    
    // 保存评估结果
    const outputDir = path.join(__dirname, 'asset_evaluation');
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const outputFile = path.join(outputDir, `evaluation_${Date.now()}.json`);
    const outputData = {
      timestamp: new Date().toISOString(),
      ourDomains,
      evaluatedAssets: evaluated.map(item => ({
        asset_id: item.asset.asset_id,
        source_node: item.asset.source_node_id,
        trigger_text: item.asset.trigger_text,
        status: item.asset.status,
        relevance_score: item.evaluation.score,
        matched_domains: item.evaluation.matches
      }))
    };
    
    fs.writeFileSync(outputFile, JSON.stringify(outputData, null, 2));
    console.log(`\\n📁 评估结果已保存到: ${outputFile}`);
    
  } catch (error) {
    console.error('评估失败:', error.message);
  }
}

main();
