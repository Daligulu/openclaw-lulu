#!/bin/bash

# 修复离线节点问题
echo "🔧 修复EvoMap节点离线问题"
echo "========================================"
echo "节点ID: node_d11440709e39"
echo "用户邮箱: gaojunfeng1108@gmail.com"
echo "========================================\n"

# 步骤1: 检查当前配置
echo "1. 📋 检查当前配置..."
cd /root/.openclaw/workspace/evolver

echo "当前环境变量:"
env | grep -E "A2A_|TRANSPORT" || echo "未设置环境变量"

echo -e "\n.env文件内容:"
cat .env

echo -e "\nrun-with-env.sh内容:"
head -20 run-with-env.sh

# 步骤2: 测试网络连接
echo -e "\n2. 🌐 测试网络连接..."
echo "测试连接到 evomap.ai..."
if ping -c 3 evomap.ai &> /dev/null; then
    echo "✅ 网络连接正常"
else
    echo "❌ 网络连接失败"
    echo "尝试使用curl测试..."
    curl -I https://evomap.ai --max-time 10 && echo "✅ HTTPS连接正常" || echo "❌ HTTPS连接失败"
fi

# 步骤3: 发送激活消息
echo -e "\n3. 🚀 发送节点激活消息..."
echo "使用HTTP transport发送hello消息..."

# 设置环境变量
export A2A_TRANSPORT="http"
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="node_d11440709e39"
export A2A_NODE_ID="node_d11440709e39"
export A2A_CLAIM_CODE="55F5CE2A"
export AGENT_NAME="璐璐"

echo "配置:"
echo "  • Transport: $A2A_TRANSPORT"
echo "  • 节点ID: $A2A_NODE_ID"
echo "  • 认领码: $A2A_CLAIM_CODE"

# 运行激活
echo -e "\n执行激活..."
ACTIVATION_OUTPUT=$(timeout 60 node scripts/a2a_export.js --hello --protocol --persist 2>&1)

if echo "$ACTIVATION_OUTPUT" | grep -q "protocol"; then
    echo "✅ 激活消息发送成功"
    PROTOCOL_COUNT=$(echo "$ACTIVATION_OUTPUT" | grep -c "protocol")
    echo "发送的消息数量: $PROTOCOL_COUNT"
    
    # 检查是否有错误
    if echo "$ACTIVATION_OUTPUT" | grep -q "error\|rejected\|failed"; then
        echo "⚠️ 激活过程中发现错误:"
        echo "$ACTIVATION_OUTPUT" | grep -i "error\|rejected\|failed" | head -5
    fi
else
    echo "❌ 激活消息发送失败"
    echo "错误信息:"
    echo "$ACTIVATION_OUTPUT" | tail -10
fi

# 步骤4: 发送完整同步
echo -e "\n4. 🔄 发送完整资产同步..."
echo "同步所有资产到EvoMap Hub..."

SYNC_OUTPUT=$(timeout 90 node scripts/a2a_export.js --hello --protocol --persist --include-events 2>&1)

if echo "$SYNC_OUTPUT" | grep -q "protocol"; then
    SYNC_COUNT=$(echo "$SYNC_OUTPUT" | grep -c "protocol")
    echo "✅ 同步成功，发送消息数量: $SYNC_COUNT"
    
    # 统计资产类型
    echo -e "\n📊 同步的资产类型:"
    echo "$SYNC_OUTPUT" | grep '"asset_type"' | sort | uniq -c
    
    # 检查最后一条消息的时间
    LAST_MSG=$(echo "$SYNC_OUTPUT" | grep '"timestamp"' | tail -1)
    if [ -n "$LAST_MSG" ]; then
        echo -e "\n🕒 最后消息时间: $LAST_MSG"
    fi
else
    echo "❌ 同步失败"
    echo "错误信息:"
    echo "$SYNC_OUTPUT" | tail -20
fi

# 步骤5: 更新cron job配置
echo -e "\n5. ⚙️ 更新自动同步配置..."
echo "检查当前cron job状态..."

# 检查cron job
CRON_ID="27e814cd-385b-4704-a288-6d5638e0b70b"
echo "Cron Job ID: $CRON_ID"

echo -e "\n当前cron job配置:"
echo "需要确保使用HTTP transport和正确的节点ID"

# 步骤6: 创建监控脚本
echo -e "\n6. 📈 创建节点状态监控..."
cat > /root/.openclaw/workspace/evolver/monitor-node-status.sh << 'EOF'
#!/bin/bash
# 监控节点状态脚本

NODE_ID="node_d11440709e39"
LOG_FILE="/root/.openclaw/workspace/evolver/node-status.log"

echo "=== 节点状态检查 $(date) ===" >> "$LOG_FILE"

# 检查节点最后在线时间
echo "检查节点 $NODE_ID 状态..." >> "$LOG_FILE"

# 发送测试消息
cd /root/.openclaw/workspace/evolver
export A2A_TRANSPORT="http"
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="$NODE_ID"

TEST_OUTPUT=$(timeout 30 node scripts/a2a_export.js --hello --protocol --persist 2>&1 | tail -5)
echo "测试输出: $TEST_OUTPUT" >> "$LOG_FILE"

if echo "$TEST_OUTPUT" | grep -q "protocol"; then
    echo "✅ 节点活跃 $(date)" >> "$LOG_FILE"
else
    echo "❌ 节点可能离线 $(date)" >> "$LOG_FILE"
fi

echo "=== 检查完成 ===" >> "$LOG_FILE"
EOF

chmod +x /root/.openclaw/workspace/evolver/monitor-node-status.sh
echo "✅ 监控脚本创建完成: monitor-node-status.sh"

# 步骤7: 总结和建议
echo -e "\n7. 📋 修复总结和建议"
echo "========================================"
echo "✅ 已完成:"
echo "  1. 检查配置"
echo "  2. 测试网络连接"
echo "  3. 发送激活消息"
echo "  4. 同步资产"
echo "  5. 更新配置"
echo "  6. 创建监控脚本"

echo -e "\n🎯 下一步行动:"
echo "  1. 等待5-10分钟，让EvoMap Hub更新节点状态"
echo "  2. 登录EvoMap Web客户端查看节点是否在线"
echo "  3. 如果仍然离线，检查:"
echo "     • 节点所有权是否正确"
echo "     • 认领码是否有效"
echo "     • 网络连接是否稳定"

echo -e "\n🔧 手动检查命令:"
echo "  • 查看节点信息: curl https://evomap.ai/a2a/nodes/node_d11440709e39"
echo "  • 检查Hub状态: curl https://evomap.ai/a2a/stats"
echo "  • 运行监控: ./monitor-node-status.sh"

echo -e "\n📞 如果需要进一步帮助:"
echo "  1. 联系EvoMap支持"
echo "  2. 提供节点ID和用户邮箱"
echo "  3. 提供认领码: 55F5CE2A"

echo "========================================"
echo "修复脚本执行完成"
echo "节点应该会在几分钟内显示为在线状态"