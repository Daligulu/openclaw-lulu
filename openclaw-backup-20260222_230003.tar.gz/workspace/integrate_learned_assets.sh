#!/bin/bash
# 集成学习到的EvoMap资产

echo "开始集成学习到的EvoMap资产..."

# 1. 复制Gene模板到assets目录
cp learned_genes/*.json assets/ 2>/dev/null || echo "无Gene模板可复制"

# 2. 更新genes.json文件
echo "更新genes.json文件..."
cd /root/.openclaw/workspace/evolver
./run-with-env.sh node -e "
const fs = require('fs');
const path = require('path');

// 读取现有的genes.json
const genesPath = path.join(__dirname, 'assets/gep/genes.json');
let genesData = { version: 1, genes: [] };
try {
  genesData = JSON.parse(fs.readFileSync(genesPath, 'utf8'));
} catch (e) {
  console.log('创建新的genes.json');
}

// 添加学习到的Gene
const learnedGenesDir = path.join(__dirname, 'learned_genes');
if (fs.existsSync(learnedGenesDir)) {
  const files = fs.readdirSync(learnedGenesDir).filter(f => f.endsWith('.json'));
  files.forEach(file => {
    const genePath = path.join(learnedGenesDir, file);
    try {
      const gene = JSON.parse(fs.readFileSync(genePath, 'utf8'));
      // 检查是否已存在
      const exists = genesData.genes.some(g => g.id === gene.id);
      if (!exists) {
        genesData.genes.push(gene);
        console.log('添加Gene:', gene.id);
      }
    } catch (e) {
      console.error('读取Gene文件失败:', file, e.message);
    }
  });
}

// 保存更新后的genes.json
fs.writeFileSync(genesPath, JSON.stringify(genesData, null, 2), 'utf8');
console.log('genes.json更新完成，共', genesData.genes.length, '个Gene');
"

# 3. 重新导出资产到EvoMap
echo "重新导出资产到EvoMap..."
./run-with-env.sh node scripts/a2a_export.js --protocol --persist --include-events 2>&1 | tail -5

echo "集成完成！"
echo "新添加的Gene将在下次遇到相应错误信号时自动应用。"
