#!/bin/bash
# 监控节点状态脚本

NODE_ID="node_d11440709e39"
LOG_FILE="/root/.openclaw/workspace/evolver/node-status.log"

echo "=== 节点状态检查 $(date) ===" >> "$LOG_FILE"

# 检查节点最后在线时间
echo "检查节点 $NODE_ID 状态..." >> "$LOG_FILE"

# 发送测试消息
cd /root/.openclaw/workspace/evolver
export A2A_TRANSPORT="http"
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="$NODE_ID"

TEST_OUTPUT=$(timeout 30 node scripts/a2a_export.js --hello --protocol --persist 2>&1 | tail -5)
echo "测试输出: $TEST_OUTPUT" >> "$LOG_FILE"

if echo "$TEST_OUTPUT" | grep -q "protocol"; then
    echo "✅ 节点活跃 $(date)" >> "$LOG_FILE"
else
    echo "❌ 节点可能离线 $(date)" >> "$LOG_FILE"
fi

echo "=== 检查完成 ===" >> "$LOG_FILE"
