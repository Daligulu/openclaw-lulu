#!/bin/bash
# EvoMap积分增长实施脚本

echo "🚀 开始实施EvoMap积分增长策略..."
echo "节点ID: node_d80158479a5d"
echo "当前时间: $(date)"
echo "============================================================"

# 1. 创建资产目录结构
echo "📁 创建资产目录结构..."
mkdir -p assets/planned/{ai_agent,feishu,content,monitoring}
mkdir -p reports score_tracking

# 2. 设置积分追踪脚本
echo "📊 设置积分追踪系统..."
cat > track_evomap_score.sh << 'TRACK_EOF'
#!/bin/bash
# EvoMap积分追踪脚本

NODE_ID="node_d80158479a5d"
TRACK_FILE="/root/.openclaw/workspace/evolver/score_tracking/score_history.json"
LOG_FILE="/root/.openclaw/workspace/evolver/score_tracking/tracking.log"

echo "=== EvoMap积分追踪 $(date) ===" | tee -a "$LOG_FILE"

# 尝试获取节点状态
echo "获取节点 $NODE_ID 状态..." | tee -a "$LOG_FILE"

# 使用Evolver的API查询
cd /root/.openclaw/workspace/evolver
SCORE_INFO=$(./run-with-env.sh node -e "
const https = require('https');

const fetchMessage = {
  protocol: 'gep-a2a',
  protocol_version: '1.0.0',
  message_type: 'fetch',
  message_id: 'track_score_' + Date.now(),
  sender_id: process.env.A2A_SENDER_ID,
  timestamp: new Date().toISOString(),
  payload: {
    asset_type: 'Capsule',
    limit: 1,
    filters: {}
  }
};

const data = JSON.stringify(fetchMessage);

const options = {
  hostname: 'evomap.ai',
  port: 443,
  path: '/a2a/fetch',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = https.request(options, (res) => {
  let responseData = '';
  res.on('data', (chunk) => {
    responseData += chunk;
  });
  res.on('end', () => {
    try {
      const result = JSON.parse(responseData);
      console.log('节点状态: 网络连接正常');
      console.log('消息ID:', result.message_id);
      console.log('发送者:', result.sender_id);
      console.log('时间:', result.timestamp);
    } catch (error) {
      console.log('网络响应:', responseData.substring(0, 200));
    }
  });
});

req.on('error', (error) => {
  console.log('网络错误:', error.message);
});

req.write(data);
req.end();
" 2>&1 | tail -10)

echo "$SCORE_INFO" | tee -a "$LOG_FILE"

# 记录追踪数据
TIMESTAMP=$(date -Iseconds)
TRACK_DATA="{
  \"timestamp\": \"$TIMESTAMP\",
  \"node_id\": \"$NODE_ID\",
  \"check_type\": \"score_tracking\"
}"

echo "$TRACK_DATA" >> "$TRACK_FILE"
echo "追踪数据已记录到 $TRACK_FILE" | tee -a "$LOG_FILE"

# 显示当前资产状态
echo "" | tee -a "$LOG_FILE"
echo "📦 当前资产状态:" | tee -a "$LOG_FILE"
./run-with-env.sh node scripts/a2a_export.js --json 2>/dev/null | jq '. | length' 2>/dev/null | \
  xargs -I {} echo "可导出资产数量: {}" | tee -a "$LOG_FILE"

echo "✅ 积分追踪完成" | tee -a "$LOG_FILE"
TRACK_EOF

chmod +x track_evomap_score.sh

# 3. 创建资产发布模板
echo "📝 创建资产发布模板..."
cat > assets/template_high_quality_capsule.json << 'TEMPLATE_EOF'
{
  "type": "Capsule",
  "schema_version": "1.5.0",
  "id": "capsule_{{timestamp}}_{{category}}",
  "trigger": ["{{signal1}}", "{{signal2}}", "{{signal3}}"],
  "gene": "gene_{{category}}_{{problem}}",
  "summary": "解决 {{problem_description}}，变更 {{file_count}} 文件 / {{line_count}} 行。置信度基于 {{success_count}} 次成功验证。",
  "confidence": 0.85,
  "blast_radius": {
    "files": 1,
    "lines": 10
  },
  "outcome": {
    "status": "success",
    "score": 0.85
  },
  "success_streak": 3,
  "env_fingerprint": {
    "node_version": "v22.22.0",
    "platform": "linux",
    "arch": "x64",
    "os_release": "6.6.117-45.1.oc9.x86_64",
    "evolver_version": "1.15.0",
    "cwd": "/root/.openclaw/workspace/evolver",
    "captured_at": "{{captured_at}}"
  },
  "a2a": {
    "eligible_to_broadcast": true,
    "quality_score": 85,
    "reusability_score": 80
  }
}
TEMPLATE_EOF

# 4. 设置自动发布cron（如果尚未设置）
echo "⏰ 检查并设置自动同步cron job..."
if ! crontab -l 2>/dev/null | grep -q "evomap-sync"; then
  (crontab -l 2>/dev/null; echo "# EvoMap自动同步 - 每4小时一次") | crontab -
  (crontab -l 2>/dev/null; echo "0 */4 * * * cd /root/.openclaw/workspace/evolver && ./run-with-env.sh node scripts/a2a_export.js --protocol --persist --include-events 2>&1 | logger -t evomap-sync") | crontab -
  echo "✅ 自动同步cron job已设置"
else
  echo "ℹ️  自动同步cron job已存在"
fi

# 5. 创建周报生成脚本
echo "📈 创建周报生成系统..."
cat > generate_weekly_report.sh << 'REPORT_EOF'
#!/bin/bash
# EvoMap积分周报生成

WEEK=$(date +%Y-%W)
REPORT_DIR="/root/.openclaw/workspace/evolver/reports"
REPORT_FILE="$REPORT_DIR/weekly_$WEEK.md"
TRACK_FILE="/root/.openclaw/workspace/evolver/score_tracking/score_history.json"

mkdir -p "$REPORT_DIR"

echo "# EvoMap积分周报 (第$WEEK周)" > "$REPORT_FILE"
echo "生成时间: $(date)" >> "$REPORT_FILE"
echo "节点ID: node_d80158479a5d" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

echo "## 📊 本周数据概览" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

# 获取资产数量
ASSET_COUNT=$(cd /root/.openclaw/workspace/evolver && ./run-with-env.sh node scripts/a2a_export.js --json 2>/dev/null | jq '. | length' 2>/dev/null || echo "0")
echo "- 总资产数量: $ASSET_COUNT" >> "$REPORT_FILE"

# 获取Gene数量
GENE_COUNT=$(cd /root/.openclaw/workspace/evolver && cat assets/gep/genes.json 2>/dev/null | jq '.genes | length' 2>/dev/null || echo "0")
echo "- Gene数量: $GENE_COUNT" >> "$REPORT_FILE"

# 获取Capsule数量
CAPSULE_COUNT=$(cd /root/.openclaw/workspace/evolver && cat assets/gep/capsules.json 2>/dev/null | jq '.capsules | length' 2>/dev/null || echo "0")
echo "- Capsule数量: $CAPSULE_COUNT" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "## 🎯 本周成果" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "- 新发布资产: [填写具体资产]" >> "$REPORT_FILE"
echo "- 解决的问题: [填写具体问题]" >> "$REPORT_FILE"
echo "- 获得的反馈: [填写反馈]" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "## 📈 积分进展" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "- 当前积分: [需要从EvoMap API获取]" >> "$REPORT_FILE"
echo "- 积分增长: [本周增长]" >> "$REPORT_FILE"
echo "- 节点排名: [当前排名]" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "## 🔍 数据分析" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "### 最成功的资产" >> "$REPORT_FILE"
echo "- [资产1]: [成功指标]" >> "$REPORT_FILE"
echo "- [资产2]: [成功指标]" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "### 需要优化的资产" >> "$REPORT_FILE"
echo "- [资产1]: [优化建议]" >> "$REPORT_FILE"
echo "- [资产2]: [优化建议]" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "## 🚀 下周计划" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "### 资产发布计划" >> "$REPORT_FILE"
echo "- 目标资产: 3-5个新Capsule" >> "$REPORT_FILE"
echo "- 重点领域: AI Agent错误修复、飞书集成优化" >> "$REPORT_FILE"
echo "- 质量目标: 置信度 > 0.85" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "### 积分目标" >> "$REPORT_FILE"
echo "- 目标积分: [设置具体目标]" >> "$REPORT_FILE"
echo "- 目标排名: [设置排名目标]" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "---" >> "$REPORT_FILE"
echo "*本报告由EvoMap积分增长系统自动生成*" >> "$REPORT_FILE"

echo "✅ 周报已生成: $REPORT_FILE"
REPORT_EOF

chmod +x generate_weekly_report.sh

# 6. 创建立即行动项
echo "🎯 创建立即行动项..."
cat > immediate_actions.md << 'ACTIONS_EOF'
# EvoMap积分增长 - 立即行动项

## 第一阶段：基础建设 (第1周)

### ✅ 已完成
1. 节点注册完成: node_d80158479a5d
2. 基础资产发布: 6个Gene + 2个Capsule + 3个EvolutionEvent
3. 学习集成完成: 3个EvoMap网络资产
4. 自动同步设置: 4小时同步cron job

### 🚀 本周行动项 (优先级排序)

#### 高优先级 (1-2天完成)
1. **整理现有成功案例**
   - 从memory/目录中提取成功的修复实例
   - 创建对应的Capsule资产
   - 确保每个Capsule都有对应的Gene

2. **创建高质量资产捆绑包**
   - 选择3个最有价值的成功案例
   - 创建完整的Gene+Capsule+EvolutionEvent捆绑
   - 确保置信度 > 0.85

3. **设置积分追踪**
   - 执行 track_evomap_score.sh
   - 验证数据记录正常
   - 设置每日自动追踪

#### 中优先级 (3-5天完成)
4. **发布第一批高质量资产**
   - 发布3个完整资产捆绑包
   - 监控EvoMap验证状态
   - 记录发布结果

5. **分析竞争对手**
   - 研究KingOfAgents等顶级节点的资产
   - 学习他们的成功模式
   - 制定差异化策略

#### 长期准备 (第1周规划)
6. **建立资产质量体系**
   - 创建资产质量检查清单
   - 设置发布前验证流程
   - 建立反馈收集机制

## 第二阶段：快速增长 (第2-4周)

### 目标
- 发布10+个高质量资产
- 达到500+积分
- 进入EvoMap前100节点

### 关键策略
1. **热点聚焦**: 专注于AI Agent、飞书集成、内容创作
2. **质量优先**: 每个资产都达到高置信度标准
3. **持续优化**: 根据使用反馈优化资产
4. **社区参与**: 积极参与EvoMap社区活动

## 成功指标追踪

### 每日检查
- 节点状态是否正常
- 资产验证进度
- 积分变化趋势

### 每周评估
- 新发布资产数量和质量
- 积分增长情况
- 与目标的差距
- 调整下周策略

## 紧急联系人
- 节点问题: 检查 .env 配置和网络连接
- 资产问题: 检查 assets/gep/ 目录
- 同步问题: 检查cron job日志
- 积分问题: 使用 track_evomap_score.sh

---
*更新日期: $(date)*
ACTIONS_EOF

# 7. 立即执行第一次积分追踪
echo "📊 执行第一次积分追踪..."
./track_evomap_score.sh

# 8. 生成第一份周报
echo "📈 生成本周周报..."
./generate_weekly_report.sh

echo ""
echo "============================================================"
echo "✅ EvoMap积分增长策略实施完成！"
echo ""
echo "📋 已创建的工具和文件:"
echo "1. 📊 积分追踪脚本: track_evomap_score.sh"
echo "2. 📈 周报生成脚本: generate_weekly_report.sh"
echo "3. 📝 资产模板: assets/template_high_quality_capsule.json"
echo "4. 🎯 行动指南: immediate_actions.md"
echo "5. ⏰ 自动同步: 已设置4小时cron job"
echo ""
echo "🚀 下一步行动:"
echo "1. 查看 immediate_actions.md 中的具体任务"
echo "2. 立即开始整理现有成功案例"
echo "3. 创建第一批高质量资产捆绑包"
echo "4. 每天执行积分追踪"
echo "5. 每周生成进度报告"
echo ""
echo "💪 目标: 1个月内进入EvoMap前100节点，3个月内进入前10节点！"
