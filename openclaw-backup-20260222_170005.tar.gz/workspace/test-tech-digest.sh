#!/bin/bash
# 测试tech-news-digest技能

echo "🔧 测试tech-news-digest技能安装..."
echo ""

# 1. 检查技能安装
echo "1. 技能安装状态："
if [ -d "/root/.openclaw/workspace/skills/tech-news-digest" ]; then
    echo "   ✅ tech-news-digest已安装"
    echo "   版本: $(grep 'version:' /root/.openclaw/workspace/skills/tech-news-digest/SKILL.md | head -1 | cut -d'"' -f2)"
else
    echo "   ❌ 技能未安装"
    exit 1
fi
echo ""

# 2. 检查Python依赖
echo "2. Python环境检查："
python3 --version
if command -v python3 &> /dev/null; then
    echo "   ✅ Python3可用"
else
    echo "   ❌ Python3未安装"
    exit 1
fi
echo ""

# 3. 检查配置文件
echo "3. 配置文件检查："
CONFIG_DIR="/root/.openclaw/workspace/skills/tech-news-digest/config/defaults"
if [ -d "$CONFIG_DIR" ]; then
    echo "   ✅ 配置目录存在"
    ls -la "$CONFIG_DIR/"*.json | head -5
else
    echo "   ❌ 配置目录不存在"
    exit 1
fi
echo ""

# 4. 测试单个RSS源（简化测试）
echo "4. 测试RSS源获取："
TEST_RSS="https://news.ycombinator.com/rss"
echo "   测试源: $TEST_RSS"
timeout 10 curl -s "$TEST_RSS" | grep -o "<title>.*</title>" | head -3 | sed 's/<[^>]*>//g'
if [ $? -eq 0 ]; then
    echo "   ✅ RSS源可访问"
else
    echo "   ⚠️  RSS源访问可能受限"
fi
echo ""

# 5. 创建测试配置
echo "5. 创建测试配置..."
cat > /tmp/test-minimal-config.yaml << 'EOF'
name: "fengfeng-test"
schedule: "manual"
output:
  format: "markdown"
  channels:
    - type: "stdout"

sources:
  rss:
    - url: "https://news.ycombinator.com/rss"
      name: "Hacker News"
      priority: 2
    - url: "https://36kr.com/feed"
      name: "36氪"
      priority: 2

processing:
  max_items: 5
  test_mode: true

templates:
  markdown:
    header: "# 测试摘要 {{date}}"
    item: "## {{title}}"
    footer: "---\n*测试完成*"
EOF

echo "   测试配置已创建: /tmp/test-minimal-config.yaml"
echo ""

# 6. 运行简单测试
echo "6. 运行简单测试脚本..."
cd /root/.openclaw/workspace/skills/tech-news-digest

# 先测试RSS获取
echo "   测试RSS获取脚本..."
timeout 15 python3 scripts/fetch-rss.py --config /tmp/test-minimal-config.yaml --output /tmp/test-rss.json 2>&1 | tail -5

if [ -f "/tmp/test-rss.json" ]; then
    ITEM_COUNT=$(jq '.items | length' /tmp/test-rss.json 2>/dev/null || echo "0")
    echo "   获取到 $ITEM_COUNT 条RSS项目"
else
    echo "   ⚠️  RSS获取可能失败"
fi
echo ""

# 7. 环境变量建议
echo "7. 环境变量建议（可选但推荐）："
cat << 'EOF'
    export X_BEARER_TOKEN="xxx"        # Twitter/X API
    export BRAVE_API_KEY="xxx"         # Brave搜索API
    export GITHUB_TOKEN="xxx"          # GitHub API
EOF
echo ""

# 8. 下一步建议
echo "8. 下一步实施建议："
cat << 'EOF'
    🔹 第一阶段（AI领域）：
      1. 获取Brave Search API密钥
      2. 配置5-10个核心AI RSS源
      3. 测试每日摘要生成
      4. 发送到Telegram测试

    🔹 第二阶段（篮球领域）：
      1. 收集NBA/CBA/FIBA RSS源
      2. 配置篮球相关搜索关键词
      3. 创建篮球专用配置

    🔹 第三阶段（宠物领域）：
      1. 收集宠物行业RSS源
      2. 配置狗狗相关关键词
      3. 创建宠物专用配置
EOF
echo ""

echo "✅ 基础测试完成"
echo "建议先获取Brave Search API密钥以启用搜索功能"
echo "然后可以开始配置具体的领域数据源"