#!/bin/bash
# 修复EvoMap节点ID问题脚本
# 确保所有EvoMap通信使用正确的节点ID: node_d11440709e39

set -e

echo "🔧 修复EvoMap节点ID问题"
echo "=========================="

# 检查当前环境变量
echo "📋 当前环境变量检查:"
echo "A2A_SENDER_ID: ${A2A_SENDER_ID:-未设置}"
echo "A2A_NODE_ID: ${A2A_NODE_ID:-未设置}"
echo "A2A_CLAIM_CODE: ${A2A_CLAIM_CODE:-未设置}"
echo "AGENT_NAME: ${AGENT_NAME:-未设置}"

# 设置正确的环境变量
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="node_d11440709e39"
export A2A_NODE_ID="node_d11440709e39"
export A2A_CLAIM_CODE="55F5CE2A"
export AGENT_NAME="璐璐"

echo ""
echo "✅ 已设置环境变量:"
echo "A2A_SENDER_ID: $A2A_SENDER_ID"
echo "A2A_NODE_ID: $A2A_NODE_ID"
echo "A2A_CLAIM_CODE: $A2A_CLAIM_CODE"
echo "AGENT_NAME: $AGENT_NAME"

# 验证节点ID生成逻辑
echo ""
echo "🔍 验证节点ID生成逻辑..."
cd /root/.openclaw/workspace/evolver

# 创建一个测试脚本来验证节点ID
cat > test-node-id.js << 'EOF'
const crypto = require('crypto');

function getDeviceId() {
  const hostname = require('os').hostname();
  const raw = hostname + '|' + process.cwd();
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 32);
}

function getNodeId() {
  // 优先使用A2A_SENDER_ID，这是EvoMap要求的固定节点ID
  if (process.env.A2A_SENDER_ID) return String(process.env.A2A_SENDER_ID);
  if (process.env.A2A_NODE_ID) return String(process.env.A2A_NODE_ID);
  const deviceId = getDeviceId();
  const agentName = process.env.AGENT_NAME || 'default';
  const raw = deviceId + '|' + agentName + '|' + process.cwd();
  return 'node_' + crypto.createHash('sha256').update(raw).digest('hex').slice(0, 12);
}

console.log("测试节点ID生成:");
console.log("1. 使用环境变量 A2A_SENDER_ID:", process.env.A2A_SENDER_ID || "未设置");
console.log("2. 生成的节点ID:", getNodeId());
console.log("3. 设备ID:", getDeviceId());
EOF

node test-node-id.js

# 清理测试文件
rm -f test-node-id.js

echo ""
echo "🚀 执行测试同步..."
echo "------------------"

# 执行hello消息测试
echo "1. 发送hello消息测试:"
node scripts/a2a_export.js --hello --protocol --persist 2>&1 | grep -A5 "sender_id" || echo "未找到sender_id信息"

echo ""
echo "2. 导出资产测试:"
node scripts/a2a_export.js --protocol --persist --include-events 2>&1 | tail -5

echo ""
echo "📊 验证结果:"
echo "预期的节点ID: node_d11440709e39"
echo "如果看到其他节点ID，请检查环境变量是否生效"

# 创建永久修复方案
echo ""
echo "💾 创建永久修复方案..."
cat > /root/.openclaw/workspace/evolver/run-with-env.sh << 'EOF'
#!/bin/bash
# EvoMap同步脚本 - 确保正确的环境变量

cd /root/.openclaw/workspace/evolver

# 设置环境变量
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="node_d11440709e39"
export A2A_NODE_ID="node_d11440709e39"
export A2A_CLAIM_CODE="55F5CE2A"
export AGENT_NAME="璐璐"

# 执行命令
exec "$@"
EOF

chmod +x /root/.openclaw/workspace/evolver/run-with-env.sh

echo "✅ 已创建永久修复脚本: run-with-env.sh"
echo ""
echo "使用方法:"
echo "  cd /root/.openclaw/workspace/evolver"
echo "  ./run-with-env.sh node scripts/a2a_export.js --hello --protocol --persist"
echo ""
echo "修复完成！现在所有EvoMap通信都将使用正确的节点ID: node_d11440709e39"