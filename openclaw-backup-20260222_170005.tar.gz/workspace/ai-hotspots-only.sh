#!/bin/bash
# AI热点专用工作流（最终可靠版）

echo "🤖 AI热点工作流启动"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 配置
BASE_DIR="/root/.openclaw/workspace"
CONFIG_AI="$BASE_DIR/configs/ai-digest-optimized"
OUTPUT_DIR="$BASE_DIR/ai-hotspots-only"
LOG_FILE="/var/log/ai-hotspots-only/$(date +%Y%m%d-%H%M%S).log"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 创建目录
mkdir -p "$OUTPUT_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

# 设置环境
export BRAVE_API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
export TZ='Asia/Shanghai'
export TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-8289858508:AAGacfYMR0PmKVvMHfrSWTntccwxB5LsQfA}"
export TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-8375286112}"

cd /root/.openclaw/workspace/skills/tech-news-digest || {
    echo "❌ 无法进入技能目录" | tee -a "$LOG_FILE"
    exit 1
}

# 发送开始通知
START_MSG="🚀 AI热点收集开始
时间: $(date '+%Y-%m-%d %H:%M')

预计: 50-100条高质量AI热点
包含英文标题翻译和详细报告
---

#AI热点 #自动收集"

curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
  -d "chat_id=${TELEGRAM_CHAT_ID}" \
  -d "text=${START_MSG}" \
  -d "parse_mode=Markdown" > /dev/null 2>&1

echo "✅ 开始通知已发送" | tee -a "$LOG_FILE"

# 数据收集
echo "1. 收集AI热点..." | tee -a "$LOG_FILE"
AI_DATA_FILE="/tmp/ai-$TIMESTAMP.json"
AI_REPORT_FILE="$OUTPUT_DIR/daily-$TIMESTAMP.md"

python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_AI" \
  --hours 24 \
  --output "$AI_DATA_FILE" \
  2>&1 | tee -a "$LOG_FILE"

if [ -f "$AI_DATA_FILE" ]; then
    AI_SIZE=$(wc -c < "$AI_DATA_FILE")
    echo "✅ AI数据收集完成: $AI_SIZE 字节" | tee -a "$LOG_FILE"
    
    # 生成详细报告
    python3 /root/.openclaw/workspace/scripts/optimized-scoring-report.py "$AI_DATA_FILE" "$AI_REPORT_FILE" 2>&1 | tee -a "$LOG_FILE"
    
    # 统计热点数量
    TOTAL_HOTSPOTS=$(grep -c "### " "$AI_REPORT_FILE" 2>/dev/null || echo "0")
    HIGH_SCORE_HOTSPOTS=$(grep -c "评分.*[89]\|10\.0" "$AI_REPORT_FILE" 2>/dev/null || echo "0")
    
    echo "📊 报告统计: $TOTAL_HOTSPOTS 条热点，其中 $HIGH_SCORE_HOTSPOTS 条高评分(≥8分)" | tee -a "$LOG_FILE"
else
    echo "❌ AI数据收集失败" | tee -a "$LOG_FILE"
    exit 1
fi

# 生成Telegram摘要（使用简单可靠版本）
echo "2. 生成Telegram摘要..." | tee -a "$LOG_FILE"
AI_SUMMARY_FILE="$OUTPUT_DIR/summary-$TIMESTAMP.md"

# 使用简单可靠的生成器
python3 /root/.openclaw/workspace/scripts/simple-reliable-generator.py "$(date +'%Y-%m-%d %H:%M')" > "$AI_SUMMARY_FILE"

echo "✅ 摘要生成完成" | tee -a "$LOG_FILE"

# 发送到Telegram
echo "3. 发送到Telegram..." | tee -a "$LOG_FILE"
if [ -f "$AI_SUMMARY_FILE" ] && [ -s "$AI_SUMMARY_FILE" ]; then
    SUMMARY_CONTENT=$(cat "$AI_SUMMARY_FILE")
    
    TELEGRAM_API="https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage"
    RESPONSE=$(curl -s -X POST "$TELEGRAM_API" \
      -d "chat_id=${TELEGRAM_CHAT_ID}" \
      -d "text=${SUMMARY_CONTENT}" \
      -d "parse_mode=Markdown")
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        echo "✅ Telegram推送成功！" | tee -a "$LOG_FILE"
        echo "   消息ID: $(echo "$RESPONSE" | grep -o '"message_id":[0-9]*' | cut -d: -f2)" | tee -a "$LOG_FILE"
    else
        echo "❌ Telegram推送失败" | tee -a "$LOG_FILE"
        echo "   响应: $RESPONSE" | tee -a "$LOG_FILE"
    fi
else
    echo "⚠️ 摘要为空，跳过Telegram推送" | tee -a "$LOG_FILE"
fi

# 归档处理
echo "4. 归档处理..." | tee -a "$LOG_FILE"
if [ -f "$AI_DATA_FILE" ]; then
    ARCHIVE_DIR="$OUTPUT_DIR/archive"
    mkdir -p "$ARCHIVE_DIR"
    ARCHIVE_FILE="$ARCHIVE_DIR/$(basename "$AI_DATA_FILE").gz"
    
    if gzip -c "$AI_DATA_FILE" > "$ARCHIVE_FILE" 2>/dev/null; then
        echo "✅ 数据归档完成: $(basename "$ARCHIVE_FILE")" | tee -a "$LOG_FILE"
    else
        echo "⚠️  数据归档失败" | tee -a "$LOG_FILE"
    fi
fi

# 清理临时文件
find /tmp -name "ai-*" -mtime +1 -delete 2>/dev/null
find /tmp -name "td-*.json" -mtime +1 -delete 2>/dev/null

# 发送完成通知
COMPLETE_MSG="✅ AI热点收集完成
时间: $(date '+%Y-%m-%d %H:%M')

收集结果:
• 热点总数: ${TOTAL_HOTSPOTS}条
• 高评分热点: ${HIGH_SCORE_HOTSPOTS}条
• 推送摘要: 已发送
• 详细报告: 已生成

查看详细报告:
/root/.openclaw/workspace/scripts/view-ai-hotspots.sh

---
#AI热点 #完成"

curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
  -d "chat_id=${TELEGRAM_CHAT_ID}" \
  -d "text=${COMPLETE_MSG}" \
  -d "parse_mode=Markdown" > /dev/null 2>&1

echo "✅ 完成通知已发送" | tee -a "$LOG_FILE"

echo "" | tee -a "$LOG_FILE"
echo "🎉 AI热点工作流执行完成！" | tee -a "$LOG_FILE"
echo "总耗时: ${SECONDS}秒" | tee -a "$LOG_FILE"
echo "输出文件:" | tee -a "$LOG_FILE"
echo "  • 详细报告: $AI_REPORT_FILE" | tee -a "$LOG_FILE"
echo "  • 推送摘要: $AI_SUMMARY_FILE" | tee -a "$LOG_FILE"
echo "  • 运行日志: $LOG_FILE" | tee -a "$LOG_FILE"

# 7. 推送详细报告到Telegram
echo "7. 📤 推送详细报告到Telegram..." | tee -a "$LOG_FILE"
if [ -f "$AI_REPORT_FILE" ] && [ -s "$AI_REPORT_FILE" ]; then
    echo "   报告文件: $AI_REPORT_FILE" | tee -a "$LOG_FILE"
    echo "   文件大小: $(du -h "$AI_REPORT_FILE" | cut -f1)" | tee -a "$LOG_FILE"
    
    # 使用直接推送脚本
    python3 /root/.openclaw/workspace/scripts/direct-report-pusher.py \
        "$AI_REPORT_FILE" \
        "$TELEGRAM_BOT_TOKEN" \
        "$TELEGRAM_CHAT_ID" 2>&1 | tee -a "$LOG_FILE"
    
    echo "✅ 详细报告推送完成" | tee -a "$LOG_FILE"
else
    echo "⚠️  详细报告不存在或为空，跳过推送" | tee -a "$LOG_FILE"
fi
