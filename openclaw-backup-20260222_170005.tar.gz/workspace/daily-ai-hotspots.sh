#!/bin/bash
# 每日AI热点摘要脚本

echo "🤖 开始每日AI热点收集..."
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"

# 设置环境
export BRAVE_API_KEY="BSAGhr7xYgJZubiYo6EW2SzTaXvifq_"
cd /root/.openclaw/workspace/skills/tech-news-digest

# 1. 运行数据收集
echo "收集数据..."
python3 scripts/run-pipeline.py \
  --defaults /root/.openclaw/workspace/configs/ai-digest \
  --hours 24 \
  --output /tmp/daily-ai-digest.json \
  --verbose 2>&1 | grep -E "(items|Done)"

# 2. 生成热点报告
echo "生成报告..."
/root/.openclaw/workspace/scripts/generate-ai-hotspots.sh

# 3. 发送到Telegram（可选）
REPORT_FILE="/root/.openclaw/workspace/ai-hotspots/$(date +%Y%m%d).md"
if [ -f "$REPORT_FILE" ]; then
    echo "报告已生成: $REPORT_FILE"
    # 这里可以添加Telegram发送逻辑
else
    echo "警告: 报告文件未生成"
fi

echo "✅ 每日AI热点收集完成"
