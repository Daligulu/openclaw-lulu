#!/bin/bash
# 测试优化后的AI热点配置

echo "🧪 测试优化配置..."
echo ""

# 1. 准备配置目录
CONFIG_DIR="/root/.openclaw/workspace/configs/ai-digest-optimized"
mkdir -p "$CONFIG_DIR"

echo "1. 复制优化配置..."
cp /root/.openclaw/workspace/configs/ai-digest/topics-ai.json "$CONFIG_DIR/topics.json"
cp /root/.openclaw/workspace/configs/ai-digest/sources-optimized.json "$CONFIG_DIR/sources.json"
cp /root/.openclaw/workspace/configs/ai-digest/processing-override.json "$CONFIG_DIR/processing.json"

echo "   配置目录: $CONFIG_DIR"
ls -la "$CONFIG_DIR"/*.json
echo ""

# 2. 创建测试运行脚本
echo "2. 运行优化配置测试..."
cd /root/.openclaw/workspace/skills/tech-news-digest

# 先禁用Web搜索避免API限制
cat > "$CONFIG_DIR/override.yaml" << 'EOF'
processing:
  test_mode: true
  dry_run: false
output:
  formats:
    markdown:
      enabled: true
    telegram:
      enabled: false
EOF

echo "   运行pipeline测试..."
timeout 45 python3 scripts/run-pipeline.py \
  --defaults "$CONFIG_DIR" \
  --hours 24 \
  --output /tmp/ai-optimized-test.json \
  --verbose 2>&1 | tail -20

# 3. 分析结果
echo ""
echo "3. 分析测试结果..."

if [ -f "/tmp/ai-optimized-test.json" ]; then
    echo "   ✅ 测试运行完成"
    
    # 使用Python分析
    python3 -c "
import json
import sys

try:
    with open('/tmp/ai-optimized-test.json', 'r') as f:
        data = json.load(f)
    
    print('📊 优化配置测试结果:')
    
    # 检查输出统计
    stats = data.get('output_stats', {})
    total = stats.get('total_articles', 0)
    topics = stats.get('topic_distribution', {})
    
    print(f'• 总文章数: {total}')
    
    if topics:
        print('• 主题分布:')
        for topic, count in topics.items():
            print(f'  - {topic}: {count}条')
    
    # 检查是否有加密货币相关内容
    print('\\n🔍 内容质量检查:')
    
    # 尝试查找文章数据
    items_found = False
    crypto_count = 0
    ai_count = 0
    
    # 检查不同可能的数据位置
    for key in ['items', 'articles', 'merged']:
        if key in data and isinstance(data[key], list):
            items = data[key]
            items_found = True
            
            for item in items[:10]:  # 检查前10条
                if isinstance(item, dict):
                    title = str(item.get('title', '')).lower()
                    if any(kw in title for kw in ['bitcoin', 'crypto', 'blockchain']):
                        crypto_count += 1
                    if any(kw in title for kw in ['ai', 'gpt', 'claude', '人工智能']):
                        ai_count += 1
            
            break
    
    if items_found:
        print(f'• AI相关文章: {ai_count}条')
        print(f'• 加密货币文章: {crypto_count}条')
        
        if crypto_count == 0:
            print('  ✅ 加密货币过滤成功')
        else:
            print(f'  ⚠️  仍有{crypto_count}条加密货币内容')
    else:
        print('• 未找到具体文章数据')
        
        # 显示数据结构
        print('\\n📁 数据结构:')
        for key in data.keys():
            value = data[key]
            if isinstance(value, dict):
                print(f'  {key}: dict ({len(value)} keys)')
            elif isinstance(value, list):
                print(f'  {key}: list ({len(value)} items)')
            else:
                print(f'  {key}: {type(value).__name__}')
                
except Exception as e:
    print(f'❌ 分析失败: {e}')
    import traceback
    traceback.print_exc()
"
else
    echo "   ❌ 测试输出文件未生成"
fi

# 4. 检查中间文件
echo ""
echo "4. 检查中间数据文件..."
RSS_FILE="/tmp/td-rss-optimized.json"
if [ -f "$RSS_FILE" ]; then
    echo "   RSS文件已生成"
    # 简单检查内容
    AI_COUNT=$(grep -i "ai\|gpt\|claude\|人工智能" "$RSS_FILE" | wc -l)
    CRYPTO_COUNT=$(grep -i "bitcoin\|crypto\|blockchain" "$RSS_FILE" | wc -l)
    echo "   AI相关内容: $AI_COUNT 处"
    echo "   加密货币内容: $CRYPTO_COUNT 处"
else
    echo "   RSS文件未找到"
fi

# 5. 创建质量评估报告
echo ""
echo "5. 创建质量评估报告..."
REPORT_FILE="/root/.openclaw/workspace/ai-hotspots/optimized-test-report.md"

cat > "$REPORT_FILE" << 'EOF'
# 🔧 AI热点配置优化测试报告

## 测试时间
$(date '+%Y-%m-%d %H:%M:%S')

## 优化内容
### 1. 数据源优化
- ✅ 加强核心AI源权重（OpenAI、DeepMind、Anthropic）
- ✅ 增加中文AI媒体（机器之心、量子位等）
- ✅ 禁用加密货币源（CoinDesk、Cointelegraph）
- ✅ 优化Reddit社区（增加r/OpenAI）

### 2. 过滤规则优化
- ✅ 添加加密货币排除关键词
- ✅ 设置AI内容必须包含规则
- ✅ 提高最低分数阈值（6.0分）
- ✅ 添加质量过滤器（标题长度、重复率）

### 3. 评分权重优化
- ✅ 核心AI源额外加分（+3分）
- ✅ 中文内容额外加分（+2分）
- ✅ 加密货币内容重罚（-10分）
- ✅ 时效性分级奖励（1h内+3分）

## 预期效果
1. **提高AI相关度**：从28%提升至>40%
2. **过滤加密货币**：完全排除无关内容
3. **提升内容质量**：更高评分阈值筛选
4. **加强中文内容**：更好服务国内读者

## 测试结果
（运行测试后填充）

## 下一步行动
1. 验证过滤效果
2. 测试完整工作流
3. 配置Telegram输出
4. 设置定时任务

---
*测试环境: OpenClaw + tech-news-digest v3.4.5*
EOF

echo "   报告已生成: $REPORT_FILE"

# 6. 下一步建议
echo ""
echo "6. 下一步建议:"
cat << 'EOF'
    ✅ 已完成:
    - 优化数据源配置
    - 设置过滤规则
    - 调整评分权重
    
    🔄 待验证:
    - 过滤效果（加密货币是否排除）
    - AI相关度提升
    - 内容质量改善
    
    🚀 立即行动:
    1. 查看测试详细结果
    2. 如果效果良好，建立完整工作流
    3. 配置Telegram自动发送
    4. 设置每日定时任务
    
    📊 验证命令:
    # 查看AI热点示例
    grep -i "ai\|gpt\|人工智能" /tmp/td-rss-optimized.json | head -5
    
    # 检查加密货币过滤
    grep -i "bitcoin\|crypto" /tmp/td-rss-optimized.json | wc -l
EOF

echo ""
echo "✅ 优化配置测试完成"
echo "请查看报告: $REPORT_FILE"
echo "验证过滤效果后决定是否继续"