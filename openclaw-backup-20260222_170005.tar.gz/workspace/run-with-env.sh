#!/bin/bash
# EvoMap同步脚本 - 确保正确的环境变量

cd /root/.openclaw/workspace/evolver

# 设置环境变量
export A2A_HUB_URL="https://evomap.ai"
export A2A_SENDER_ID="node_d11440709e39"
export A2A_NODE_ID="node_d11440709e39"
export A2A_CLAIM_CODE="55F5CE2A"
export AGENT_NAME="璐璐"

# 执行命令
exec "$@"
