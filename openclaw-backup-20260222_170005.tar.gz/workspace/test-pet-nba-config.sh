#!/bin/bash

echo "=== 测试宠物和NBA RSS配置 ==="
echo ""

# 测试AKC RSS
echo "1. 测试AKC RSS源:"
curl -s -I "https://www.akc.org/feed/" | head -3
echo ""

# 测试ESPN NBA RSS
echo "2. 测试ESPN NBA RSS源:"
curl -s -I "https://www.espn.com/espn/rss/nba/news" | head -3
echo ""

# 检查配置文件
echo "3. 检查主工作区配置文件:"
echo "   Sources配置:"
jq '.sources | length' /root/.openclaw/workspace/config/sources.json
echo "   Topics配置:"
jq '.topics | length' /root/.openclaw/workspace/config/topics.json
echo ""

echo "4. 检查Tech-News-Digest工作区配置文件:"
echo "   Sources配置:"
jq '.sources | length' /root/.openclaw/workspace/skills/tech-news-digest/workspace/config/sources.json
echo "   Topics配置:"
jq '.topics | length' /root/.openclaw/workspace/skills/tech-news-digest/workspace/config/topics.json
echo ""

echo "=== 配置摘要 ==="
echo "宠物狗狗源: AKC RSS (有效)"
echo "NBA源: ESPN NBA RSS (有效)"
echo "AI源: OpenAI, Anthropic, DeepSeek RSS + Twitter KOLs"
echo "Reddit源: r/dogs, r/nba, r/MachineLearning, r/OpenAI"
echo ""

echo "配置更新完成！现在Tech-News-Digest可以扫描："
echo "1. AI热点 (LLM, AI Agent)"
echo "2. 宠物狗狗热点 (AKC RSS + r/dogs)"
echo "3. NBA热点 (ESPN NBA RSS + r/nba)"