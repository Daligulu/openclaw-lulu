#!/bin/bash
# 测试版本差异报告功能

echo "测试版本差异报告..."
echo ""

# 1. 创建测试备份
echo "1. 创建测试备份文件..."
TEST_DIR="/tmp/test-backup-$$"
mkdir -p "$TEST_DIR"
echo "测试内容1" > "$TEST_DIR/test1.txt"
echo "测试内容2" > "$TEST_DIR/test2.txt"

tar -czf "/tmp/openclaw-backup-test1.tar.gz" -C "$TEST_DIR" .
tar -czf "/tmp/openclaw-backup-test2.tar.gz" -C "$TEST_DIR" .

# 2. 测试generate_changelog函数
echo ""
echo "2. 测试版本差异报告函数..."
cat > /tmp/test_changelog.sh << 'EOF'
#!/bin/bash
generate_changelog() {
    local backup_file="$1"
    echo "测试备份文件: $(basename "$backup_file")"
    
    # 模拟文件大小
    PREV_SIZE=102400  # 100KB
    CURR_SIZE=112640  # 110KB
    SIZE_DIFF=$((CURR_SIZE - PREV_SIZE))
    SIZE_PERCENT=$((SIZE_DIFF * 100 / PREV_SIZE))
    
    echo "📊 备份统计："
    echo "  • 前次备份: 2026-02-16 (100KB)"
    echo "  • 本次备份: 2026-02-17 (110KB)"
    echo "  • 大小变化: +10KB (+10%)"
    echo ""
    echo "🔍 关键文件状态："
    echo "最近24小时修改的文件："
    echo "  • workspace/memory/2026-02-16.md"
    echo "  • workspace/backup-openclaw.sh"
    echo "  • workspace/SOUL.md"
    echo "今日记忆记录: 15行"
    echo "身份文件今日有更新"
}

# 调用测试
generate_changelog "test.tar.gz"
EOF

chmod +x /tmp/test_changelog.sh
/tmp/test_changelog.sh

echo ""
echo "3. 查看实际备份脚本中的函数..."
grep -A 5 "generate_changelog()" /root/.openclaw/workspace/backup-openclaw.sh | head -10

echo ""
echo "4. 测试提交信息格式..."
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
BACKUP_NAME="openclaw-backup-$TIMESTAMP"

cat << EOF
示例提交信息：
🔧 OpenClaw备份 $BACKUP_NAME

备份时间: $(date '+%Y-%m-%d %H:%M:%S')
备份文件: $BACKUP_NAME.tar.gz

📋 版本变更概述：
📊 备份统计：
  • 前次备份: 2026-02-16 (100KB)
  • 本次备份: 2026-02-17 (110KB)
  • 大小变化: +10KB (+10%)

🔍 关键文件状态：
最近24小时修改的文件：
  • workspace/memory/2026-02-16.md
  • workspace/backup-openclaw.sh
  • workspace/SOUL.md
今日记忆记录: 15行
身份文件今日有更新

💾 恢复方式：解压后运行 restore-openclaw.sh
EOF

echo ""
echo "✅ 测试完成"
echo "实际备份时，GitHub提交信息将包含详细的版本差异报告"

# 清理
rm -rf "$TEST_DIR" /tmp/test_changelog.sh /tmp/openclaw-backup-test*.tar.gz