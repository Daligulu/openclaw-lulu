/**
 * LanceDB operations for agent memories.
 * L0/L1/L2 tiered schema with category-filtered vector search.
 */
import { type AgentMemoryRow, type MemoryCategory, type PluginLogger } from "./types.js";
import { type DecayConfigType } from "./config.js";
export declare function assertCategory(value: string): void;
export declare function assertUuid(value: string): void;
/**
 * Computes decay-adjusted score for memory search results.
 *
 * Formula:
 *   decayScore = vectorScore * timeDecay * activeBoost
 *
 * Where:
 *   - timeDecay = 2^(-ageDays / halfLifeDays)  (exponential decay)
 *   - activeBoost = 1 + activeWeight * log(1 + activeCount)  (logarithmic boost)
 *
 * @param vectorScore - Original similarity score from vector search (0-1)
 * @param createdAt - Memory creation timestamp in milliseconds
 * @param activeCount - Number of times this memory was activated/recalled
 * @param config - Decay configuration
 * @returns Decay-adjusted score
 */
export declare function computeDecayScore(vectorScore: number, createdAt: number, activeCount: number, config: Required<DecayConfigType>): number;
export type MemorySearchResult = {
    entry: AgentMemoryRow;
    score: number;
};
export declare class MemoryDB {
    private readonly dbPath;
    private readonly vectorDim;
    private readonly logger;
    private db;
    private table;
    private initPromise;
    private writeLock;
    private readonly decayConfig;
    constructor(dbPath: string, vectorDim: number, logger: PluginLogger, decayConfig?: DecayConfigType);
    /** Serialize all write operations to prevent concurrent read-modify-write races. */
    private withWriteLock;
    private ensureInit;
    private doInit;
    store(entry: Omit<AgentMemoryRow, "id" | "created_at" | "updated_at" | "active_count">): Promise<AgentMemoryRow>;
    search(vector: number[], limit?: number, minScore?: number, categoryFilter?: MemoryCategory): Promise<MemorySearchResult[]>;
    findByCategory(category: MemoryCategory): Promise<AgentMemoryRow[]>;
    getById(id: string): Promise<AgentMemoryRow | null>;
    update(id: string, fields: Partial<AgentMemoryRow>): Promise<void>;
    incrementActiveCount(id: string): Promise<void>;
    /**
     * Get all memories from the database.
     * Used by QMD projection to generate daily summaries.
     *
     * @param maxLimit - Maximum number of records to return (default: 10000)
     * @returns Array of all memory entries
     */
    getAll(maxLimit?: number): Promise<AgentMemoryRow[]>;
}
//# sourceMappingURL=db.d.ts.map