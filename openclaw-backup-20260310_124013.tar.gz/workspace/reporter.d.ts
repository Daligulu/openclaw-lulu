/**
 * Memory Reporter for epro-memory.
 *
 * Records memory changes and generates human-readable reports.
 * Supports daily summaries and notification marking for important changes.
 *
 * @see ITERATION-SPEC.md P2-001
 */
import type { ExtractionStats, PluginLogger } from "./types.js";
/** Configuration for the reporter */
export interface ReporterConfig {
    /** Whether reporting is enabled */
    enabled: boolean;
    /** Path for storing report logs */
    logPath: string;
    /** Whether to generate daily summaries */
    dailySummary: boolean;
    /** Whether to mark pivotal changes for notification */
    notifyOnPivotal: boolean;
}
/** Default reporter configuration */
export declare const DEFAULT_REPORTER_CONFIG: ReporterConfig;
/** A single memory change report from one extraction session */
export interface MemoryChangeReport {
    /** Timestamp of the report */
    timestamp: number;
    /** Session key identifying the extraction */
    sessionKey: string;
    /** Change statistics */
    changes: ExtractionStats;
    /** Important changes (L0 abstracts of created/merged memories) */
    highlights: string[];
    /** User identifier */
    user: string;
}
/** Notification record for pending notifications */
export interface PendingNotification {
    timestamp: number;
    sessionKey: string;
    message: string;
    sent: boolean;
}
/**
 * MemoryReporter tracks and reports memory changes.
 */
export declare class MemoryReporter {
    private logPath;
    private logger;
    private config;
    private pendingNotifications;
    constructor(config: ReporterConfig, logger: PluginLogger);
    /**
     * Ensure log directory exists.
     */
    private ensureDir;
    /**
     * Get the log file path for a specific date.
     */
    private getLogPath;
    /**
     * Get the notification queue file path.
     */
    private getNotificationPath;
    /**
     * Record a memory change report.
     * Appends to daily log file and optionally marks for notification.
     */
    record(report: MemoryChangeReport): Promise<void>;
    /**
     * Check if a report contains pivotal (important) changes.
     */
    private isPivotal;
    /**
     * Mark a report for notification.
     */
    private markForNotification;
    /**
     * Format a notification message for a report.
     */
    private formatNotificationMessage;
    /**
     * Save pending notifications to disk.
     */
    private savePendingNotifications;
    /**
     * Load pending notifications from disk.
     */
    loadPendingNotifications(): Promise<PendingNotification[]>;
    /**
     * Mark notifications as sent.
     */
    markNotificationsSent(sessionKeys: string[]): Promise<void>;
    /**
     * Load reports for a specific date from log file.
     */
    loadReportsForDate(date: string): Promise<MemoryChangeReport[]>;
    /**
     * Generate a daily summary report.
     */
    generateDailyReport(date?: string): Promise<string>;
    /**
     * Create a report from extraction stats.
     */
    createReport(sessionKey: string, stats: ExtractionStats, highlights: string[], user: string): MemoryChangeReport;
}
//# sourceMappingURL=reporter.d.ts.map