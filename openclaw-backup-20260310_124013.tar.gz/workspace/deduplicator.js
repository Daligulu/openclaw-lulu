/**
 * Memory deduplicator.
 * Two-stage pipeline: vector pre-filter -> LLM decision (CREATE/MERGE/SKIP).
 * Ported from OpenViking's memory_deduplicator.py.
 */
import { buildDedupPrompt } from "./prompts.js";
const SIMILARITY_THRESHOLD = 0.7;
const MAX_SIMILAR_FOR_PROMPT = 3;
const VALID_DECISIONS = new Set(["create", "merge", "skip"]);
export class MemoryDeduplicator {
    db;
    llm;
    logger;
    constructor(db, llm, logger) {
        this.db = db;
        this.llm = llm;
        this.logger = logger;
    }
    async deduplicate(candidate, candidateVector) {
        // Stage 1: Vector pre-filter — find similar memories in same category
        const similar = await this.db.search(candidateVector, 5, SIMILARITY_THRESHOLD, candidate.category);
        if (similar.length === 0) {
            return {
                decision: "create",
                reason: "No similar memories found",
            };
        }
        // Stage 2: LLM decision
        return this.llmDecision(candidate, similar);
    }
    async llmDecision(candidate, similar) {
        const topSimilar = similar.slice(0, MAX_SIMILAR_FOR_PROMPT);
        const existingFormatted = topSimilar
            .map((r, i) => `${i + 1}. [${r.entry.category}] ${r.entry.abstract}\n   Overview: ${r.entry.overview}\n   Score: ${r.score.toFixed(3)}`)
            .join("\n");
        const prompt = buildDedupPrompt(candidate.abstract, candidate.overview, candidate.content, existingFormatted);
        try {
            const data = await this.llm.completeJson(prompt);
            if (!data) {
                this.logger.warn("epro-memory: dedup LLM returned unparseable response, defaulting to CREATE");
                return { decision: "create", reason: "LLM response unparseable" };
            }
            const decision = (data.decision?.toLowerCase() ??
                "create");
            if (!VALID_DECISIONS.has(decision)) {
                return {
                    decision: "create",
                    reason: `Unknown decision: ${data.decision}`,
                };
            }
            // Resolve merge target from LLM's match_index (1-based), fall back to top result
            const idx = data.match_index;
            const matchEntry = typeof idx === "number" && idx >= 1 && idx <= topSimilar.length
                ? topSimilar[idx - 1]
                : topSimilar[0];
            return {
                decision,
                reason: data.reason ?? "",
                matchId: decision === "merge" ? matchEntry?.entry.id : undefined,
            };
        }
        catch (err) {
            this.logger.warn(`epro-memory: dedup LLM failed: ${String(err)}`);
            return { decision: "create", reason: `LLM failed: ${String(err)}` };
        }
    }
}
//# sourceMappingURL=deduplicator.js.map