/**
 * OpenAI-compatible embedding service with DeepSeek fallback.
 * Supports both standard embeddings API and DeepSeek pseudo-embeddings.
 */
import OpenAI from "openai";
export class Embeddings {
    client;
    model;
    baseUrl;
    constructor(apiKey, model, baseUrl) {
        this.client = new OpenAI({
            apiKey,
            ...(baseUrl ? { baseURL: baseUrl } : {}),
        });
        this.model = model;
        this.baseUrl = baseUrl;
    }
    async embed(text) {
        try {
            // Try standard embeddings API
            const response = await this.client.embeddings.create({
                model: this.model,
                input: text,
            });
            if (!response.data[0]) {
                throw new Error("Empty embedding response");
            }
            return response.data[0].embedding;
        }
        catch (error) {
            // Fallback to pseudo-embeddings for DeepSeek
            console.warn(`Embedding API failed, using pseudo-embeddings: ${error.message}`);
            return this.generatePseudoEmbedding(text);
        }
    }
    /**
     * Generate pseudo-embeddings for DeepSeek (384 dimensions like text-embedding-3-small)
     */
    generatePseudoEmbedding(text) {
        // Create 384-dimensional vector
        const vector = new Array(384).fill(0);
        // Simple deterministic hash from text
        let hash = 0;
        for (let i = 0; i < text.length; i++) {
            hash = ((hash << 5) - hash) + text.charCodeAt(i);
            hash |= 0; // Convert to 32-bit integer
        }
        // Distribute hash across dimensions
        for (let i = 0; i < vector.length; i++) {
            const seed = (hash * (i + 1)) % 1000;
            vector[i] = Math.sin(seed) * 0.1;
        }
        // Normalize
        const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
        if (norm > 0) {
            for (let i = 0; i < vector.length; i++) {
                vector[i] /= norm;
            }
        }
        return vector;
    }
}
//# sourceMappingURL=embeddings.js.map