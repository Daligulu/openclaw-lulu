#!/bin/bash
# EvoMap自动化cron配置脚本

set -e

echo "⏰ EvoMap自动化cron配置脚本"
echo "========================================"
echo ""

# 检查当前cron配置
echo "📋 当前cron配置:"
crontab -l 2>/dev/null | grep -E "evomap|keep-evo-node" || echo "  (无EvoMap相关配置)"
echo ""

# 配置保持在线cron job
KEEPALIVE_SCRIPT="/root/.openclaw/workspace/keep-evo-node-online-feng-new.sh"
KEEPALIVE_LOG="/root/.openclaw/workspace/evomap-keepalive-feng.log"

if [ ! -f "$KEEPALIVE_SCRIPT" ]; then
    echo "❌ 保持在线脚本不存在: $KEEPALIVE_SCRIPT"
    exit 1
fi

echo "🔧 配置保持在线cron job..."
KEEPALIVE_CRON="*/30 * * * * $KEEPALIVE_SCRIPT >> $KEEPALIVE_LOG 2>&1"

# 移除旧的cron job
(crontab -l 2>/dev/null | grep -v "$KEEPALIVE_SCRIPT" | grep -v "keep-evo-node-online-feng-new.sh") | crontab -

# 添加新的cron job
(crontab -l 2>/dev/null; echo "$KEEPALIVE_CRON") | crontab -
echo "✅ 保持在线cron job已配置: 每30分钟执行一次"
echo "   - 脚本: $KEEPALIVE_SCRIPT"
echo "   - 日志: $KEEPALIVE_LOG"
echo ""

# 配置每日状态报告
REPORT_SCRIPT="/root/.openclaw/workspace/evomap-node-manager.sh"
REPORT_LOG="/root/.openclaw/workspace/evomap-daily-report.log"

if [ -f "$REPORT_SCRIPT" ]; then
    echo "📊 配置每日状态报告cron job..."
    REPORT_CRON="0 9 * * * $REPORT_SCRIPT --daily-report >> $REPORT_LOG 2>&1"
    
    # 移除旧的报告cron job
    (crontab -l 2>/dev/null | grep -v "$REPORT_SCRIPT" | grep -v "evomap-node-manager.sh") | crontab -
    
    # 添加新的报告cron job
    (crontab -l 2>/dev/null; echo "$REPORT_CRON") | crontab -
    echo "✅ 每日状态报告cron job已配置: 每天9:00执行"
    echo "   - 脚本: $REPORT_SCRIPT"
    echo "   - 日志: $REPORT_LOG"
else
    echo "⚠️ 节点管理器脚本不存在，跳过每日报告配置"
fi
echo ""

# 配置每周清理日志
CLEANUP_SCRIPT="/root/.openclaw/workspace/cleanup-evo-logs.sh"
cat > "$CLEANUP_SCRIPT" << 'EOF'
#!/bin/bash
# 清理EvoMap日志脚本

LOG_DIR="/root/.openclaw/workspace"
DAYS_TO_KEEP=7

echo "🧹 清理EvoMap日志文件 (保留最近${DAYS_TO_KEEP}天)"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 清理保持在线日志
if [ -f "${LOG_DIR}/evomap-keepalive-feng.log" ]; then
    echo "📝 清理保持在线日志..."
    tail -n 1000 "${LOG_DIR}/evomap-keepalive-feng.log" > "${LOG_DIR}/evomap-keepalive-feng.log.tmp"
    mv "${LOG_DIR}/evomap-keepalive-feng.log.tmp" "${LOG_DIR}/evomap-keepalive-feng.log"
    echo "✅ 保持在线日志已清理"
fi

# 清理管理器日志
if [ -f "${LOG_DIR}/evomap-manager.log" ]; then
    echo "📝 清理管理器日志..."
    tail -n 500 "${LOG_DIR}/evomap-manager.log" > "${LOG_DIR}/evomap-manager.log.tmp"
    mv "${LOG_DIR}/evomap-manager.log.tmp" "${LOG_DIR}/evomap-manager.log"
    echo "✅ 管理器日志已清理"
fi

# 清理旧日志文件
echo "🗑️ 删除超过${DAYS_TO_KEEP}天的旧日志..."
find "${LOG_DIR}" -name "evomap-*.log.*" -type f -mtime +${DAYS_TO_KEEP} -delete 2>/dev/null || true
find "${LOG_DIR}" -name "evomap_*.log" -type f -mtime +${DAYS_TO_KEEP} -delete 2>/dev/null || true

echo ""
echo "🎯 日志清理完成"
EOF

chmod +x "$CLEANUP_SCRIPT"
echo "🧹 创建日志清理脚本: $CLEANUP_SCRIPT"

# 配置每周清理cron job
CLEANUP_CRON="0 0 * * 0 $CLEANUP_SCRIPT >> ${LOG_DIR}/evomap-cleanup.log 2>&1"
(crontab -l 2>/dev/null; echo "$CLEANUP_CRON") | crontab -
echo "✅ 每周日志清理cron job已配置: 每周日0:00执行"
echo ""

# 验证cron配置
echo "🔍 验证cron配置..."
echo "当前所有EvoMap相关cron job:"
crontab -l 2>/dev/null | grep -E "evomap|keep-evo-node|cleanup-evo" || echo "  (无相关配置)"
echo ""

# 创建监控脚本
MONITOR_SCRIPT="/root/.openclaw/workspace/monitor-evo-status.sh"
cat > "$MONITOR_SCRIPT" << 'EOF'
#!/bin/bash
# EvoMap节点状态监控脚本

CONFIG_FILE="/root/.openclaw/workspace/evomap-feng-config.json"
STATUS_FILE="/root/.openclaw/workspace/evomap-status.json"
ALERT_FILE="/root/.openclaw/workspace/evomap-alerts.log"

# 加载配置
if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ 配置文件不存在" >> "$ALERT_FILE"
    exit 1
fi

NODE_ID=$(jq -r '.node_id' "$CONFIG_FILE")

# 检查节点状态
check_status() {
    local response=$(curl -s -X POST https://evomap.ai/a2a/hello \
        -H "Content-Type: application/json" \
        -d '{
            "protocol": "gep-a2a",
            "protocol_version": "1.0.0",
            "message_type": "hello",
            "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
            "sender_id": "'$NODE_ID'",
            "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
            "payload": {
                "capabilities": {},
                "env_fingerprint": { "platform": "linux", "arch": "x64" }
            }
        }')
    
    local status=$(echo "$response" | jq -r '.payload.status // "unknown"')
    local credits=$(echo "$response" | jq -r '.payload.credit_balance // 0')
    local survival=$(echo "$response" | jq -r '.payload.survival_status // "unknown"')
    
    # 保存状态
    cat > "$STATUS_FILE" << STATUS_EOF
{
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "node_id": "$NODE_ID",
    "status": "$status",
    "credits": $credits,
    "survival_status": "$survival",
    "last_check": "$(date '+%Y-%m-%d %H:%M:%S %Z')"
}
STATUS_EOF
    
    # 检查警报条件
    if [ "$status" != "acknowledged" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警报: 节点状态异常 - $status" >> "$ALERT_FILE"
    fi
    
    if [ "$credits" -lt 100 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警报: 积分过低 - $credits" >> "$ALERT_FILE"
    fi
    
    if [ "$survival_status" != "alive" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警报: 生存状态异常 - $survival" >> "$ALERT_FILE"
    fi
    
    echo "✅ 状态检查完成: status=$status, credits=$credits, survival=$survival"
}

# 执行检查
check_status
EOF

chmod +x "$MONITOR_SCRIPT"
echo "📊 创建状态监控脚本: $MONITOR_SCRIPT"

# 配置每小时监控cron job
MONITOR_CRON="0 * * * * $MONITOR_SCRIPT >> ${LOG_DIR}/evomap-monitor.log 2>&1"
(crontab -l 2>/dev/null; echo "$MONITOR_CRON") | crontab -
echo "✅ 每小时状态监控cron job已配置"
echo ""

# 总结
echo "🎯 EvoMap自动化cron配置完成"
echo "========================================"
echo "已配置的cron job:"
echo "1. 📡 保持在线: 每30分钟一次"
echo "2. 📊 状态监控: 每小时一次"
echo "3. 📈 每日报告: 每天9:00"
echo "4. 🧹 每周清理: 每周日0:00"
echo ""
echo "📁 相关文件:"
echo "   - 配置文件: /root/.openclaw/workspace/evomap-feng-config.json"
echo "   - 保持在线脚本: $KEEPALIVE_SCRIPT"
echo "   - 节点管理器: $REPORT_SCRIPT"
echo "   - 状态监控: $MONITOR_SCRIPT"
echo "   - 日志清理: $CLEANUP_SCRIPT"
echo ""
echo "🔍 查看cron配置: crontab -l"
echo "📝 查看保持在线日志: tail -f $KEEPALIVE_LOG"
echo "🎯 手动运行节点管理器: $REPORT_SCRIPT"
echo ""
echo "✅ 所有配置已完成！节点将自动保持在线状态。"