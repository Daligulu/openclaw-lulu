/**
 * Config schema for ePro memory plugin.
 */
import { type Static } from "@sinclair/typebox";
declare const DecayConfig: import("@sinclair/typebox").TObject<{
    enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    halfLifeDays: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    activeWeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
}>;
declare const QmdProjectionConfig: import("@sinclair/typebox").TObject<{
    enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    qmdPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    includeL1: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    categorySeparateFiles: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    dailyTrigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
declare const CheckpointConfig: import("@sinclair/typebox").TObject<{
    enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    path: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    autoRecoverOnStart: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
declare const ReporterConfig: import("@sinclair/typebox").TObject<{
    enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    logPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    dailySummary: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    notifyOnPivotal: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
declare const BootstrapConfig: import("@sinclair/typebox").TObject<{
    enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    patternPromotionThreshold: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    skillDraftPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    minConfidence: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
}>;
declare const EproConfigSchema: import("@sinclair/typebox").TObject<{
    embedding: import("@sinclair/typebox").TObject<{
        model: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
        apiKey: import("@sinclair/typebox").TString;
        baseUrl: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    }>;
    llm: import("@sinclair/typebox").TObject<{
        model: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
        apiKey: import("@sinclair/typebox").TString;
        baseUrl: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    }>;
    dbPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    autoCapture: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    autoRecall: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    recallLimit: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    recallMinScore: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    extractMinMessages: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    extractMaxChars: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    decay: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        halfLifeDays: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        activeWeight: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>;
    qmdProjection: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        qmdPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
        includeL1: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        categorySeparateFiles: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        dailyTrigger: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>>;
    checkpoint: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        path: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
        autoRecoverOnStart: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>>;
    reporting: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        logPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
        dailySummary: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        notifyOnPivotal: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    }>>;
    bootstrap: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        enabled: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
        patternPromotionThreshold: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
        skillDraftPath: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
        minConfidence: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TNumber>;
    }>>;
}>;
type EproConfig = Static<typeof EproConfigSchema>;
export type DecayConfigType = Static<typeof DecayConfig>;
export type QmdProjectionConfigType = Static<typeof QmdProjectionConfig>;
export type CheckpointConfigType = Static<typeof CheckpointConfig>;
export type ReporterConfigType = Static<typeof ReporterConfig>;
export type BootstrapConfigType = Static<typeof BootstrapConfig>;
export declare const DEFAULTS: {
    readonly embeddingModel: "text-embedding-3-small";
    readonly llmModel: "gpt-4o-mini";
    readonly dbPath: "~/.clawdbot/memory/epro-lancedb";
    readonly autoCapture: true;
    readonly autoRecall: true;
    readonly recallLimit: 5;
    readonly recallMinScore: 0.3;
    readonly extractMinMessages: 4;
    readonly extractMaxChars: 8000;
    readonly decay: {
        readonly enabled: false;
        readonly halfLifeDays: 30;
        readonly activeWeight: 0.1;
    };
    readonly qmdProjection: {
        readonly enabled: false;
        readonly qmdPath: "~/.clawdbot/memory/qmd";
        readonly includeL1: true;
        readonly categorySeparateFiles: true;
        readonly dailyTrigger: true;
    };
    readonly checkpoint: {
        readonly enabled: false;
        readonly path: "~/.clawdbot/memory/checkpoints";
        readonly autoRecoverOnStart: true;
    };
    readonly reporting: {
        readonly enabled: false;
        readonly logPath: "~/.clawdbot/memory/reports";
        readonly dailySummary: true;
        readonly notifyOnPivotal: true;
    };
    readonly bootstrap: {
        readonly enabled: false;
        readonly patternPromotionThreshold: 5;
        readonly skillDraftPath: "~/.clawdbot/memory/skill-drafts";
        readonly minConfidence: 0.7;
    };
};
export declare function vectorDimsForModel(model: string): number;
export declare function parseConfig(raw: unknown): EproConfig;
export {};
//# sourceMappingURL=config.d.ts.map