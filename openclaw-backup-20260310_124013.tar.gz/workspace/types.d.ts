/**
 * Shared types for ePro memory plugin.
 *
 * 6-category classification from OpenViking:
 * - UserMemory: profile, preferences, entities, events
 * - AgentMemory: cases, patterns
 */
export declare const MEMORY_CATEGORIES: readonly ["profile", "preferences", "entities", "events", "cases", "patterns"];
export type MemoryCategory = (typeof MEMORY_CATEGORIES)[number];
/** Categories that always merge (skip dedup). */
export declare const ALWAYS_MERGE_CATEGORIES: Set<"profile" | "preferences" | "entities" | "events" | "cases" | "patterns">;
/** Categories that support MERGE decision from LLM dedup. */
export declare const MERGE_SUPPORTED_CATEGORIES: Set<"profile" | "preferences" | "entities" | "events" | "cases" | "patterns">;
/** A candidate memory extracted from conversation by LLM. */
export type CandidateMemory = {
    category: MemoryCategory;
    abstract: string;
    overview: string;
    content: string;
};
/** A row in the LanceDB agent_memories table. */
export type AgentMemoryRow = {
    id: string;
    category: MemoryCategory;
    abstract: string;
    overview: string;
    content: string;
    vector: number[];
    source_session: string;
    active_count: number;
    created_at: number;
    updated_at: number;
};
/** Dedup decision from LLM. */
export type DedupDecision = "create" | "merge" | "skip";
export type DedupResult = {
    decision: DedupDecision;
    reason: string;
    matchId?: string;
};
export type ExtractionStats = {
    created: number;
    merged: number;
    skipped: number;
};
export type PluginLogger = {
    debug?: (msg: string) => void;
    info: (msg: string) => void;
    warn: (msg: string) => void;
    error: (msg: string) => void;
};
//# sourceMappingURL=types.d.ts.map