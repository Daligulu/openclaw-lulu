/**
 * Memory extraction orchestrator for DeepSeek.
 * Modified to work with DeepSeekEmbeddings.
 *
 * Pipeline: extract candidates -> dedup -> persist to LanceDB.
 * Ported from OpenViking's compressor.py.
 *
 * P2-002: Added checkpoint support for resumable extraction.
 */
import { buildExtractionPrompt, buildMergePrompt } from "./prompts.js";
import { ALWAYS_MERGE_CATEGORIES, MERGE_SUPPORTED_CATEGORIES, MEMORY_CATEGORIES, } from "./types.js";
export class MemoryExtractorDeepSeek {
    db;
    embeddings;
    llm;
    deduplicator;
    logger;
    constructor(db, embeddings, llm, deduplicator, logger) {
        this.db = db;
        this.embeddings = embeddings;
        this.llm = llm;
        this.deduplicator = deduplicator;
        this.logger = logger;
    }
    /**
     * Extract memories from conversation text and persist to LanceDB.
     * Main entry point for non-checkpoint extraction.
     */
    async extractAndPersist(conversationText, sessionKey, user) {
        const candidates = await this.extractCandidates(conversationText, user);
        return this.processCandidates(candidates, sessionKey);
    }
    /**
     * Extract with checkpoint support (P2-002).
     * Saves progress after each candidate to allow crash recovery.
     */
    async extractWithCheckpoint(conversationText, sessionKey, user, checkpointMgr) {
        const checkpoint = {
            sessionKey,
            user,
            conversationText,
            candidatesProcessed: 0,
            totalCandidates: 0,
            stats: { created: 0, merged: 0, skipped: 0 },
            startedAt: Date.now(),
        };
        try {
            const candidates = await this.extractCandidates(conversationText, user);
            checkpoint.totalCandidates = candidates.length;
            // Save initial checkpoint
            await checkpointMgr.save(checkpoint);
            const stats = { created: 0, merged: 0, skipped: 0 };
            for (let i = 0; i < candidates.length; i++) {
                const candidate = candidates[i];
                const result = await this.processSingleCandidate(candidate, sessionKey);
                stats.created += result.created;
                stats.merged += result.merged;
                stats.skipped += result.skipped;
                // Update checkpoint
                checkpoint.candidatesProcessed = i + 1;
                checkpoint.stats = stats;
                await checkpointMgr.save(checkpoint);
            }
            // Clear checkpoint on success
            await checkpointMgr.clear();
            return stats;
        }
        catch (error) {
            this.logger.warn(`extractWithCheckpoint failed, checkpoint saved: ${String(error)}`);
            throw error;
        }
    }
    /**
     * Resume incomplete extraction from checkpoint (P2-002).
     */
    async resumeIncomplete(checkpointMgr) {
        const incomplete = await checkpointMgr.findIncomplete();
        const results = [];
        for (const checkpoint of incomplete) {
            try {
                this.logger.info(`Resuming extraction from checkpoint: ${checkpoint.sessionKey} (${checkpoint.candidatesProcessed}/${checkpoint.totalCandidates})`);
                // Re-extract candidates (idempotent)
                const candidates = await this.extractCandidates(checkpoint.conversationText, checkpoint.user);
                const stats = { created: 0, merged: 0, skipped: 0 };
                // Process remaining candidates
                for (let i = checkpoint.candidatesProcessed; i < candidates.length; i++) {
                    const candidate = candidates[i];
                    const result = await this.processSingleCandidate(candidate, checkpoint.sessionKey);
                    stats.created += result.created;
                    stats.merged += result.merged;
                    stats.skipped += result.skipped;
                    // Update checkpoint
                    checkpoint.candidatesProcessed = i + 1;
                    checkpoint.stats = stats;
                    await checkpointMgr.save(checkpoint);
                }
                // Clear checkpoint on success
                await checkpointMgr.clear();
                results.push(stats);
            }
            catch (error) {
                this.logger.warn(`Failed to resume checkpoint ${checkpoint.sessionKey}: ${String(error)}`);
            }
        }
        return results;
    }
    /**
     * Extract candidate memories from conversation text using LLM.
     */
    async extractCandidates(conversationText, user) {
        const prompt = buildExtractionPrompt(conversationText, user);
        const response = await this.llm.chat(prompt);
        // Parse JSON from LLM response
        const jsonMatch = response.match(/```json\n([\s\S]*?)\n```/) ||
            response.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
            this.logger.warn("No JSON found in LLM extraction response");
            return [];
        }
        try {
            const parsed = JSON.parse(jsonMatch[0]);
            if (!parsed.memories || !Array.isArray(parsed.memories)) {
                this.logger.warn("Invalid extraction response format");
                return [];
            }
            // Validate candidate memories
            const candidates = [];
            for (const mem of parsed.memories) {
                if (mem.category &&
                    MEMORY_CATEGORIES.includes(mem.category) &&
                    mem.abstract &&
                    mem.overview &&
                    mem.content) {
                    candidates.push({
                        category: mem.category,
                        abstract: String(mem.abstract).trim(),
                        overview: String(mem.overview).trim(),
                        content: String(mem.content).trim(),
                    });
                }
            }
            this.logger.info(`Extracted ${candidates.length} candidate memories`);
            return candidates;
        }
        catch (error) {
            this.logger.warn(`Failed to parse extraction JSON: ${String(error)}`);
            return [];
        }
    }
    /**
     * Process a batch of candidates through dedup pipeline.
     */
    async processCandidates(candidates, sessionKey) {
        const stats = { created: 0, merged: 0, skipped: 0 };
        for (const candidate of candidates) {
            const result = await this.processSingleCandidate(candidate, sessionKey);
            stats.created += result.created;
            stats.merged += result.merged;
            stats.skipped += result.skipped;
        }
        this.logger.info(`Processed ${candidates.length} candidates: ` +
            `created=${stats.created}, merged=${stats.merged}, skipped=${stats.skipped}`);
        return stats;
    }
    /**
     * Process a single candidate through the dedup pipeline.
     */
    async processSingleCandidate(candidate, sessionKey) {
        // Profile always merges (skip dedup)
        if (ALWAYS_MERGE_CATEGORIES.has(candidate.category)) {
            const existing = await this.db.findByCategory("profile", 1);
            if (existing.length > 0) {
                await this.mergeProfile(existing[0].entry, candidate, sessionKey);
                return { created: 0, merged: 1, skipped: 0 };
            }
            else {
                await this.createMemory(candidate, sessionKey);
                return { created: 1, merged: 0, skipped: 0 };
            }
        }
        // For other categories, run dedup pipeline
        const vector = await this.embeddings.embed(candidate.abstract + " " + candidate.content);
        const similar = await this.db.searchByCategory(candidate.category, vector, 5, // limit
        0.7);
        if (similar.length === 0) {
            // No similar memories → CREATE
            await this.createMemory(candidate, sessionKey);
            return { created: 1, merged: 0, skipped: 0 };
        }
        // Run LLM dedup decision
        const dedupResult = await this.deduplicator.decide(candidate, similar.map(s => s.entry));
        switch (dedupResult.decision) {
            case "create":
                await this.createMemory(candidate, sessionKey);
                return { created: 1, merged: 0, skipped: 0 };
            case "merge":
                if (!MERGE_SUPPORTED_CATEGORIES.has(candidate.category)) {
                    this.logger.warn(`LLM requested merge for non-mergeable category: ${candidate.category}`);
                    return { created: 0, merged: 0, skipped: 1 };
                }
                if (!dedupResult.matchId) {
                    this.logger.warn("LLM merge decision missing matchId");
                    return { created: 0, merged: 0, skipped: 1 };
                }
                const existing = await this.db.getById(dedupResult.matchId);
                if (!existing) {
                    this.logger.warn(`Match ID not found: ${dedupResult.matchId}`);
                    return { created: 0, merged: 0, skipped: 1 };
                }
                await this.mergeMemory(existing, candidate, sessionKey);
                return { created: 0, merged: 1, skipped: 0 };
            case "skip":
                this.logger.debug(`Skipping duplicate: ${candidate.abstract}`);
                return { created: 0, merged: 0, skipped: 1 };
            default:
                this.logger.warn(`Unknown dedup decision: ${dedupResult.decision}`);
                return { created: 0, merged: 0, skipped: 1 };
        }
    }
    /**
     * Create a new memory in LanceDB.
     */
    async createMemory(candidate, sessionKey) {
        const vector = await this.embeddings.embed(candidate.abstract + " " + candidate.content);
        await this.db.store({
            ...candidate,
            vector,
            source_session: sessionKey,
            active_count: 0,
            created_at: Date.now(),
            updated_at: Date.now(),
        });
        this.logger.debug(`Created memory: ${candidate.abstract}`);
    }
    /**
     * Merge candidate into existing profile memory.
     */
    async mergeProfile(existing, // Using any to avoid type issues
    candidate, sessionKey) {
        const prompt = buildMergePrompt(existing, candidate, "profile");
        const response = await this.llm.chat(prompt);
        const jsonMatch = response.match(/```json\n([\s\S]*?)\n```/) ||
            response.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
            this.logger.warn("No JSON found in profile merge response");
            return;
        }
        try {
            const merged = JSON.parse(jsonMatch[0]);
            await this.db.update(existing.id, {
                abstract: merged.abstract || existing.abstract,
                overview: merged.overview || existing.overview,
                content: merged.content || existing.content,
                updated_at: Date.now(),
            });
            this.logger.debug(`Merged profile: ${candidate.abstract}`);
        }
        catch (error) {
            this.logger.warn(`Failed to parse profile merge JSON: ${String(error)}`);
        }
    }
    /**
     * Merge candidate into existing memory (non-profile).
     */
    async mergeMemory(existing, // Using any to avoid type issues
    candidate, sessionKey) {
        const prompt = buildMergePrompt(existing, candidate, candidate.category);
        const response = await this.llm.chat(prompt);
        const jsonMatch = response.match(/```json\n([\s\S]*?)\n```/) ||
            response.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
            this.logger.warn("No JSON found in merge response");
            return;
        }
        try {
            const merged = JSON.parse(jsonMatch[0]);
            await this.db.update(existing.id, {
                abstract: merged.abstract || existing.abstract,
                overview: merged.overview || existing.overview,
                content: merged.content || existing.content,
                updated_at: Date.now(),
            });
            this.logger.debug(`Merged ${candidate.category}: ${candidate.abstract}`);
        }
        catch (error) {
            this.logger.warn(`Failed to parse merge JSON: ${String(error)}`);
        }
    }
}
//# sourceMappingURL=extractor-deepseek.js.map