#!/usr/bin/env node

// my writer skill - 触发工作流脚本
// 当检测到特定指令时，自动触发内容创作工作流

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// 触发指令列表
const TRIGGER_COMMANDS = [
  '创作内容',
  '请写作',
  '请创作',
  '写一篇文章',
  '生成内容',
  '内容创作',
  '帮我写篇文章',
  '开始创作',
  'create content',
  'write article',
  'generate content'
];

// 工作流脚本路径
const WORKFLOW_SCRIPT = '/root/.openclaw/workspace/content-creation-workflow.sh';
const SIMPLE_SCRIPT = '/root/.openclaw/workspace/创作内容.sh';

// 检查是否触发
function checkTrigger(message) {
  const lowerMessage = message.toLowerCase();
  return TRIGGER_COMMANDS.some(cmd => 
    lowerMessage.includes(cmd.toLowerCase())
  );
}

// 执行工作流
function executeWorkflow() {
  console.log('🚀 检测到内容创作指令，开始执行工作流...');
  
  try {
    // 检查脚本是否存在
    if (!fs.existsSync(SIMPLE_SCRIPT)) {
      console.error('❌ 工作流脚本不存在:', SIMPLE_SCRIPT);
      return false;
    }
    
    // 执行工作流
    const result = execSync(`bash "${SIMPLE_SCRIPT}"`, {
      encoding: 'utf8',
      stdio: 'pipe'
    });
    
    console.log('✅ 工作流执行完成');
    console.log(result);
    return true;
    
  } catch (error) {
    console.error('❌ 工作流执行失败:', error.message);
    return false;
  }
}

// 主函数
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log('📝 my writer skill - 内容创作技能');
    console.log('📋 触发指令:', TRIGGER_COMMANDS.join(', '));
    console.log('🚀 使用方式: node trigger-workflow.js "创作内容"');
    return;
  }
  
  const message = args.join(' ');
  
  if (checkTrigger(message)) {
    console.log(`✅ 检测到触发指令: "${message}"`);
    const success = executeWorkflow();
    
    if (success) {
      console.log('🎉 内容创作工作流已成功触发！');
      console.log('📋 请查看生成的Notion链接和内容文件。');
    } else {
      console.log('⚠️  工作流执行遇到问题，请检查错误信息。');
    }
  } else {
    console.log(`❌ 未检测到触发指令: "${message}"`);
    console.log('📋 支持的触发指令:', TRIGGER_COMMANDS.join(', '));
  }
}

// 执行
if (require.main === module) {
  main();
}

module.exports = {
  checkTrigger,
  executeWorkflow,
  TRIGGER_COMMANDS
};