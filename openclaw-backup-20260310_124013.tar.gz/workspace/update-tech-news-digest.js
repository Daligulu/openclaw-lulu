const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新Tech-News-Digest运行状态
state.lastTechNewsDigestRun = nowISO;
state.articlesCollected = 117; // 去重后文章数

// 更新新热点发现
state.newHotspotsFound = {
  timestamp: nowISO,
  aiTopics: 24,
  dogTopics: 0,
  nbaTopics: 0,
  total: 24,
  status: "needs_reporting",
  telegramMessageId: null,
  hotspots: [
    {
      title: "LLM News Today (February 2026) – Open Source LLM Updates & AI Model Releases",
      category: "AI-开源动态",
      priority: "⭐⭐⭐⭐",
      source: "https://llm-stats.com/ai-news",
      description: "2026年2月开源LLM更新和AI模型发布汇总，质量分数7.0"
    },
    {
      title: "AI Updates Today (February 2026) – Latest AI Model Releases",
      category: "AI-模型发布",
      priority: "⭐⭐⭐⭐",
      source: "https://llm-stats.com/llm-updates",
      description: "最新AI模型发布动态，质量分数7.0"
    },
    {
      title: "Crittora Makes OpenClaw Enterprise-Ready by Eliminating Ambient Authority in Autonomous Agents",
      category: "AI-企业应用",
      priority: "⭐⭐⭐⭐⭐",
      source: "https://finance.yahoo.com/news/crittora-makes-openclaw-enterprise-ready-155800602.html",
      description: "Crittora通过消除自主代理中的环境权限使OpenClaw企业就绪，质量分数7.0"
    },
    {
      title: "Arvind KC appointed Chief People Officer",
      category: "AI-人事变动",
      priority: "⭐⭐⭐",
      source: "https://openai.com/index/arvind-kc-chief-people-officer",
      description: "OpenAI任命Arvind KC为首席人事官，质量分数5.0"
    },
    {
      title: "Gemini tops benchmarks, again",
      category: "AI-模型性能",
      priority: "⭐⭐⭐⭐",
      source: "https://www.bensbites.com/p/gemini-tops-benchmarks-again",
      description: "谷歌Gemini再次登顶基准测试，质量分数5.0"
    }
  ]
};

// 更新当前任务
state.currentTasks = [
  "Tech-News-Digest运行完成（09:00），发现24个AI热点待汇报",
  "每日记忆整理完成（08:00）",
  "Content Agent每日选题执行完成（07:30，耗时23.24秒）",
  "OpenClaw备份完成（07:00），+100KB（+1%），Telegram消息ID: 2546",
  "EvoMap同步完成（22:57），下次同步01:58"
];

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新，包含Tech-News-Digest热点发现');
