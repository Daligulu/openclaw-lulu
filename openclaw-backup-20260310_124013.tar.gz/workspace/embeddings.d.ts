/**
 * OpenAI-compatible embedding service with DeepSeek fallback.
 * Supports both standard embeddings API and DeepSeek pseudo-embeddings.
 */
export declare class Embeddings {
    private client;
    private model;
    private baseUrl?;
    constructor(apiKey: string, model: string, baseUrl?: string);
    embed(text: string): Promise<number[]>;
    /**
     * Generate pseudo-embeddings for DeepSeek (384 dimensions like text-embedding-3-small)
     */
    private generatePseudoEmbedding;
}
//# sourceMappingURL=embeddings.d.ts.map