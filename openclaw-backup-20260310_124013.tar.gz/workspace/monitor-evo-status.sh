#!/bin/bash
# EvoMap节点状态监控脚本

CONFIG_FILE="/root/.openclaw/workspace/evomap-feng-config.json"
STATUS_FILE="/root/.openclaw/workspace/evomap-status.json"
ALERT_FILE="/root/.openclaw/workspace/evomap-alerts.log"

# 加载配置
if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ 配置文件不存在" >> "$ALERT_FILE"
    exit 1
fi

NODE_ID=$(jq -r '.node_id' "$CONFIG_FILE")

# 检查节点状态
check_status() {
    local response=$(curl -s -X POST https://evomap.ai/a2a/hello \
        -H "Content-Type: application/json" \
        -d '{
            "protocol": "gep-a2a",
            "protocol_version": "1.0.0",
            "message_type": "hello",
            "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
            "sender_id": "'$NODE_ID'",
            "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
            "payload": {
                "capabilities": {},
                "env_fingerprint": { "platform": "linux", "arch": "x64" }
            }
        }')
    
    local status=$(echo "$response" | jq -r '.payload.status // "unknown"')
    local credits=$(echo "$response" | jq -r '.payload.credit_balance // 0')
    local survival=$(echo "$response" | jq -r '.payload.survival_status // "unknown"')
    
    # 保存状态
    cat > "$STATUS_FILE" << STATUS_EOF
{
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "node_id": "$NODE_ID",
    "status": "$status",
    "credits": $credits,
    "survival_status": "$survival",
    "last_check": "$(date '+%Y-%m-%d %H:%M:%S %Z')"
}
STATUS_EOF
    
    # 检查警报条件
    if [ "$status" != "acknowledged" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警报: 节点状态异常 - $status" >> "$ALERT_FILE"
    fi
    
    if [ "$credits" -lt 100 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警报: 积分过低 - $credits" >> "$ALERT_FILE"
    fi
    
    if [ "$survival_status" != "alive" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 警报: 生存状态异常 - $survival" >> "$ALERT_FILE"
    fi
    
    echo "✅ 状态检查完成: status=$status, credits=$credits, survival=$survival"
}

# 执行检查
check_status
