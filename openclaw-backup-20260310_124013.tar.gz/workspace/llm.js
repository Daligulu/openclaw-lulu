/**
 * LLM client for memory extraction, dedup, and merge.
 * Uses OpenAI-compatible chat completions API.
 */
import OpenAI from "openai";
export class LlmClient {
    client;
    model;
    constructor(apiKey, model, baseUrl) {
        this.client = new OpenAI({
            apiKey,
            ...(baseUrl ? { baseURL: baseUrl } : {}),
        });
        this.model = model;
    }
    async complete(prompt) {
        const response = await this.client.chat.completions.create({
            model: this.model,
            messages: [{ role: "user", content: prompt }],
            temperature: 0,
        });
        return response.choices[0]?.message?.content?.trim() ?? "";
    }
    async completeJson(prompt) {
        const raw = await this.complete(prompt);
        return parseJsonFromResponse(raw);
    }
}
/** Extract JSON from LLM response that may contain markdown fences. */
export function parseJsonFromResponse(text) {
    // Try direct parse first
    try {
        return JSON.parse(text);
    }
    catch {
        // noop
    }
    // Try extracting from markdown code fence
    const fenceMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    if (fenceMatch) {
        try {
            return JSON.parse(fenceMatch[1]);
        }
        catch {
            // noop
        }
    }
    // Try balanced brace extraction — scan for { and its matching }
    // Tracks string context to avoid counting braces inside JSON string literals.
    // On parse failure, continues scanning from the next { (does not give up).
    let searchFrom = 0;
    while (searchFrom < text.length) {
        const braceStart = text.indexOf("{", searchFrom);
        if (braceStart === -1)
            break;
        let depth = 0;
        let inString = false;
        let escaped = false;
        let foundEnd = -1;
        for (let i = braceStart; i < text.length; i++) {
            const ch = text[i];
            if (escaped) {
                escaped = false;
                continue;
            }
            if (ch === "\\" && inString) {
                escaped = true;
                continue;
            }
            if (ch === '"') {
                inString = !inString;
                continue;
            }
            if (!inString) {
                if (ch === "{")
                    depth++;
                else if (ch === "}")
                    depth--;
                if (depth === 0) {
                    foundEnd = i;
                    break;
                }
            }
        }
        if (foundEnd !== -1) {
            try {
                return JSON.parse(text.slice(braceStart, foundEnd + 1));
            }
            catch {
                // This balanced block wasn't valid JSON — try the next {
                searchFrom = braceStart + 1;
                continue;
            }
        }
        // Unbalanced block — skip past this { and try later ones
        searchFrom = braceStart + 1;
    }
    return null;
}
//# sourceMappingURL=llm.js.map