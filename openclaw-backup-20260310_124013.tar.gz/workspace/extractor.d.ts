/**
 * Memory extraction orchestrator.
 * Pipeline: extract candidates -> dedup -> persist to LanceDB.
 * Ported from OpenViking's compressor.py.
 *
 * P2-002: Added checkpoint support for resumable extraction.
 */
import type { MemoryDB } from "./db.js";
import type { MemoryDeduplicator } from "./deduplicator.js";
import type { Embeddings } from "./embeddings.js";
import type { LlmClient } from "./llm.js";
import { type ExtractionStats, type PluginLogger } from "./types.js";
import type { CheckpointManager } from "./checkpoint.js";
export declare class MemoryExtractor {
    private db;
    private embeddings;
    private llm;
    private deduplicator;
    private logger;
    constructor(db: MemoryDB, embeddings: Embeddings, llm: LlmClient, deduplicator: MemoryDeduplicator, logger: PluginLogger);
    extractAndPersist(conversationText: string, sessionKey: string, user: string): Promise<ExtractionStats>;
    private extractCandidates;
    private processCandidate;
    private handleProfileMerge;
    private handleMerge;
    private mergeMemory;
    /**
     * Extract and persist memories with checkpoint support for resumability.
     * If interrupted, can resume from the last saved checkpoint.
     *
     * P2-002: Checkpoint-based extraction for fault tolerance.
     *
     * @param conversationText - The conversation to extract memories from
     * @param sessionKey - Unique key identifying this extraction session
     * @param user - User identifier
     * @param checkpointMgr - CheckpointManager instance for persistence
     * @returns Extraction statistics
     */
    extractWithCheckpoint(conversationText: string, sessionKey: string, user: string, checkpointMgr: CheckpointManager): Promise<ExtractionStats>;
    /**
     * Resume incomplete extractions found at startup.
     * Used for auto-recovery when checkpoint.autoRecoverOnStart is enabled.
     *
     * @param checkpointMgr - CheckpointManager instance
     * @returns Array of extraction stats for each resumed extraction
     */
    resumeIncomplete(checkpointMgr: CheckpointManager): Promise<ExtractionStats[]>;
    /**
     * Resume extraction from a specific checkpoint.
     * Internal method for resumeIncomplete.
     */
    private resumeFromCheckpoint;
}
//# sourceMappingURL=extractor.d.ts.map