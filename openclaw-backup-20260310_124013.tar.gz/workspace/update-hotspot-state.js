const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastHeartbeatReport = nowISO;

// 添加新热点发现
state.newHotspotsFound = {
  timestamp: nowISO,
  aiTopics: 1,
  dogTopics: 0,
  nbaTopics: 2,
  total: 3,
  status: "needs_reporting",
  hotspots: [
    {
      title: "Anthropic指控DeepSeek等中国AI大模型抄袭Claude模型",
      category: "AI-行业争议",
      priority: "⭐⭐⭐⭐⭐",
      source: "https://k.sina.com.cn/article_7857201856_1d45362c001902ko5u.html",
      description: "美国AI独角兽Anthropic指控中国三家头部大模型企业DeepSeek、Moonshot AI和MiniMax对其Claude模型实施工业规模的蒸馏攻击，马斯克也加入争议"
    },
    {
      title: "莱昂纳德与快船合同可能无效，湖人等队将疯狂追求",
      category: "NBA-合同纠纷",
      priority: "⭐⭐⭐⭐",
      source: "https://k.sina.com.cn/article_7857201856_1d45362c001902kmcg.html",
      description: "因阴阳合同问题，NBA可能宣布莱昂纳德与快船合同无效，一旦成为自由球员，湖人、勇士、尼克斯等球队会疯狂追求"
    },
    {
      title: "火箭与老鹰商讨1换2交易，申京可能离队",
      category: "NBA-交易传闻",
      priority: "⭐⭐⭐⭐",
      source: "https://sports.sina.cn/2026-02-24/detail-inhnxaes3102507.d.html",
      description: "火箭和老鹰正在商讨申京换奥孔武和里萨谢的1换2交易，预计夏天达成，火箭更衣室因杜兰特小号事件陷入信任危机"
    }
  ]
};

// 更新当前任务
state.currentTasks = [
  "发现3个新热点（AI 1个，NBA 2个）",
  "Tech-News-Digest下次运行09:00",
  "Content Agent每日选题已生成（07:34）",
  "每日记忆整理已完成（08:00）",
  "OpenClaw备份已完成（07:00）"
];

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新，发现3个新热点');
