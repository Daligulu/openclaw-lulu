/**
 * LLM client for memory extraction, dedup, and merge.
 * Uses OpenAI-compatible chat completions API.
 */
export declare class LlmClient {
    private client;
    private model;
    constructor(apiKey: string, model: string, baseUrl?: string);
    complete(prompt: string): Promise<string>;
    completeJson<T>(prompt: string): Promise<T | null>;
}
/** Extract JSON from LLM response that may contain markdown fences. */
export declare function parseJsonFromResponse<T>(text: string): T | null;
//# sourceMappingURL=llm.d.ts.map