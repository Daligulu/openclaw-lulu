#!/bin/bash
# EvoMap节点保持在线脚本 - 使用已绑定的节点
# 节点ID: node_d11440709e39（已绑定到 gaojunfeng1108@gmail.com）

set -e

echo "🔗 EvoMap节点保持在线脚本 - 使用已绑定节点"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: node_d11440709e39（已绑定）"
echo "   - Hub节点ID: hub_0f978bbe1fb5"
echo "   - 用户账户: gaojunfeng1108@gmail.com"
echo "   - 状态: 已绑定到账户"
echo ""

# 发送hello消息保持节点活跃
echo "📡 发送hello消息..."
RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "node_d11440709e39",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {},
      "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
  }')

STATUS=$(echo "$RESPONSE" | jq -r '.payload.status // "unknown"')
CREDITS=$(echo "$RESPONSE" | jq -r '.payload.credit_balance // 0')
YOUR_NODE_ID=$(echo "$RESPONSE" | jq -r '.payload.your_node_id // "unknown"')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 返回的节点ID: $YOUR_NODE_ID"
echo "   - API返回积分: $CREDITS"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃（已绑定到账户）"
    
    # 发送心跳消息
    echo "💓 发送心跳消息..."
    curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "node_d11440709e39",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {}
        }
      }' > /dev/null && echo "✅ 心跳消息发送完成"
    
    # 检查evolver运行状态
    echo ""
    echo "🔄 检查evolver运行状态..."
    if pgrep -f "evolver" > /dev/null; then
        echo "✅ evolver正在运行"
        EVOLVER_PID=$(pgrep -f "evolver")
        echo "   - 进程ID: $EVOLVER_PID"
        
        # 检查evolver配置
        if [ -f "/root/.openclaw/workspace/evolver/.env" ]; then
            echo "   - 当前配置的节点ID:"
            grep "A2A_NODE_ID" /root/.openclaw/workspace/evolver/.env || echo "     (未找到配置)"
        fi
    else
        echo "⚠️ evolver未运行"
        echo "💡 建议启动evolver进行资产同步:"
        echo "   cd /root/.openclaw/workspace/evolver"
        echo "   npm start"
    fi
else
    echo "❌ 节点状态异常: $STATUS"
    if [ "$STATUS" = "rejected" ]; then
        REASON=$(echo "$RESPONSE" | jq -r '.payload.reason // "unknown"')
        echo "   - 原因: $REASON"
    fi
fi

echo ""
echo "📋 重要说明:"
echo "1. ✅ 你的节点已成功绑定到账户 gaojunfeng1108@gmail.com"
echo "2. 🔗 在EvoMap Web客户端查看实际积分余额"
echo "3. ⚡ API返回的积分可能是缓存值，以Web客户端为准"
echo "4. 🎯 节点保持在线的主要目的是维持连接状态"
echo "5. 📊 实际积分和资产在Web客户端查看"

echo ""
echo "🎯 脚本执行完成 - 节点保持在线状态已更新"