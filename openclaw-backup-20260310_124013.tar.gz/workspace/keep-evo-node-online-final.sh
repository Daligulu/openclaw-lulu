#!/bin/bash
# EvoMap节点保持在线脚本 - 最终版本
# 使用正确的节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198

set -e

echo "🔗 EvoMap节点保持在线脚本 - 最终版本"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198（已绑定）"
echo "   - Hub节点ID: hub_0f978bbe1fb5"
echo "   - 认领码: L5KD-XQRX（已使用）"
echo "   - 用户账户: gaojunfeng1108@gmail.com（已绑定）"
echo ""

# 发送hello消息
echo "📡 发送hello消息..."
RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "node_d0cf2a3b4b3946a492a8e72e381e1198",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {},
      "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
  }')

STATUS=$(echo "$RESPONSE" | jq -r '.payload.status // "unknown"')
CREDITS=$(echo "$RESPONSE" | jq -r '.payload.credit_balance // 0')
YOUR_NODE_ID=$(echo "$RESPONSE" | jq -r '.payload.your_node_id // "unknown"')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 节点ID: $YOUR_NODE_ID"
echo "   - API积分: $CREDITS"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃（已绑定到账户）"
    
    # 发送心跳
    echo "💓 发送心跳消息..."
    curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "node_d0cf2a3b4b3946a492a8e72e381e1198",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {}
        }
      }' > /dev/null && echo "✅ 心跳发送完成"
    
    echo ""
    echo "🔄 系统状态检查:"
    
    # 检查evolver配置
    if [ -f "/root/.openclaw/workspace/evolver/.env" ]; then
        CONFIG_NODE=$(grep "A2A_NODE_ID" /root/.openclaw/workspace/evolver/.env | cut -d= -f2)
        echo "   - evolver配置节点: $CONFIG_NODE"
        if [ "$CONFIG_NODE" = "node_d0cf2a3b4b3946a492a8e72e381e1198" ]; then
            echo "   - ✅ 配置正确"
        else
            echo "   - ⚠️ 配置不匹配，需要更新"
        fi
    fi
    
    # 检查cron job
    echo "   - cron job状态:"
    if crontab -l 2>/dev/null | grep -q "node_d0cf2a3b4b3946a492a8e72e381e1198"; then
        echo "   - ✅ 已配置保持在线cron"
    else
        echo "   - ⚠️ 需要配置cron"
    fi
    
else
    echo "❌ 节点状态异常: $STATUS"
fi

echo ""
echo "🎯 总结:"
echo "1. ✅ 使用正确的节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198"
echo "2. ✅ 节点状态: $STATUS（acknowledged表示已绑定）"
echo "3. 🔗 实际积分请在EvoMap Web客户端查看"
echo "4. ⏰ 建议配置cron job保持节点在线"
echo ""
echo "📋 配置cron job命令:"
echo "crontab -e"
echo "添加: */30 * * * * /root/.openclaw/workspace/keep-evo-node-online-final.sh >> /root/.openclaw/workspace/evomap-online.log 2>&1"

echo ""
echo "🚀 脚本执行完成"