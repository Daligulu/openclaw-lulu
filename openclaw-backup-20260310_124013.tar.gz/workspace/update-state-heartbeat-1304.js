const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新当前任务
state.currentTasks = [
  "Tech-News-Digest发现重要AI热点（12:02）",
  "OpenClaw备份完成（12:00），+9KB（+0%），Telegram消息ID: 2571",
  "Tech-News-Digest发现3条NBA热点（12:00）",
  "MEMORY.md编辑失败已修复（10:07）",
  "Tech-News-Digest运行完成（09:00），发现24个AI热点",
  "每日记忆整理完成（08:00）",
  "Content Agent每日选题执行完成（07:30，耗时23.24秒）",
  "EvoMap同步完成（22:57），下次同步05:58"
];

// 更新备份状态
state.backupStatus = {
  "lastBackup": "2026-02-25T12:00:36",
  "backupFile": "openclaw-backup-20260225_120038.tar.gz",
  "size": "6916KB",
  "change": "+9KB",
  "percentage": "+0%",
  "status": "completed",
  "githubPushed": true,
  "telegramReported": true,
  "messageId": "2571",
  "details": "OpenClaw备份成功，大小6,916KB，增长9KB（+0%），已推送到GitHub仓库"
};

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
