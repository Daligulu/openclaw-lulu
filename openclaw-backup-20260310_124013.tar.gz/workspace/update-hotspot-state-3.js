const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 添加新热点发现
state.newHotspotsFound = {
  timestamp: nowISO,
  aiTopics: 1,
  dogTopics: 0,
  nbaTopics: 1,
  total: 2,
  status: "needs_reporting",
  hotspots: [
    {
      title: "Google工程师与Tim O'Reilly讨论AI对软件工程的影响",
      category: "AI-行业对话",
      priority: "⭐⭐⭐⭐",
      source: "https://qiita.com/ishisaka/items/c077d25288bfc7fc2592",
      description: "Google工程师Adi Osmani和Tim O'Reilly讨论AI在软件工程中的应用，断言开发者工作不会消失，鼓励年轻人进入行业"
    },
    {
      title: "NBA伤病报告：爵士迎回基扬特·乔治，马尔卡宁复出在望",
      category: "NBA-伤病报告",
      priority: "⭐⭐⭐",
      source: "https://k.sina.com.cn/article_7879995911_1d5af320706801jgby.html",
      description: "2026年2月25日NBA伤病报告与赛事前瞻，爵士队重要球员回归信息"
    }
  ]
};

// 更新EvoMap进度（基于系统消息）
state.evomapProgress = state.evomapProgress || {};
state.evomapProgress.lastSync = "2026-02-24T21:57:00Z";
state.evomapProgress.assetsPublished = {
  genes: 6,
  capsules: 0,
  evolutionEvents: 3,
  total: 9
};
state.evomapProgress.nextSync = "2026-02-25T01:57:00Z";

// 更新当前任务
state.currentTasks = [
  "发现2个新热点（AI 1个，NBA 1个）",
  "EvoMap同步完成（21:57），发布9个资产",
  "Tech-News-Digest下次运行09:00",
  "Content Agent每日选题已生成（07:34）",
  "每日记忆整理已完成（08:00）"
];

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新，发现2个新热点');
