/**
 * DeepSeek-compatible embedding service using chat model for pseudo-embeddings.
 * Since DeepSeek doesn't support embeddings API, we use chat model to generate
 * text representations that can be used for similarity search.
 */
import OpenAI from "openai";
export class DeepSeekEmbeddings {
    client;
    model;
    constructor(apiKey, model, baseUrl) {
        this.client = new OpenAI({
            apiKey,
            ...(baseUrl ? { baseURL: baseUrl } : {}),
        });
        this.model = model;
    }
    /**
     * Generate a pseudo-embedding using DeepSeek chat model.
     * This creates a text representation that can be used for basic similarity.
     * Note: This is a workaround since DeepSeek doesn't have embeddings API.
     */
    async embed(text) {
        try {
            // First try the standard embeddings API (in case DeepSeek adds support)
            const response = await this.client.embeddings.create({
                model: this.model,
                input: text,
            }).catch(() => null);
            if (response && response.data[0]) {
                return response.data[0].embedding;
            }
            // Fallback: Generate pseudo-embedding using chat model
            console.warn(`DeepSeek embeddings API not available, using chat-based pseudo-embedding for: ${text.substring(0, 50)}...`);
            return await this.generatePseudoEmbedding(text);
        }
        catch (error) {
            console.error(`Embedding failed, using fallback: ${error.message}`);
            return await this.generatePseudoEmbedding(text);
        }
    }
    /**
     * Generate a simple pseudo-embedding vector.
     * This creates a 384-dimensional vector based on text characteristics.
     * For production use, consider using a local embedding model.
     */
    async generatePseudoEmbedding(text) {
        // Create a simple hash-based vector (384 dimensions like text-embedding-3-small)
        const vector = new Array(384).fill(0);
        // Simple hash-based approach for consistency
        let hash = 0;
        for (let i = 0; i < text.length; i++) {
            hash = ((hash << 5) - hash) + text.charCodeAt(i);
            hash |= 0; // Convert to 32-bit integer
        }
        // Distribute hash across dimensions
        for (let i = 0; i < vector.length; i++) {
            // Use different parts of the hash for different dimensions
            const seed = (hash * (i + 1)) % 1000;
            vector[i] = Math.sin(seed) * 0.1; // Small values for similarity search
        }
        // Normalize the vector
        const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
        if (norm > 0) {
            for (let i = 0; i < vector.length; i++) {
                vector[i] /= norm;
            }
        }
        return vector;
    }
    /**
     * Alternative: Use chat model to generate semantic summary for embedding
     * This is more accurate but slower and uses more tokens.
     */
    async generateSemanticEmbedding(text) {
        try {
            // Ask the model to create a semantic summary for embedding
            const response = await this.client.chat.completions.create({
                model: this.model,
                messages: [
                    {
                        role: "system",
                        content: "Create a concise semantic summary of the following text for vector embedding. Output only the summary."
                    },
                    {
                        role: "user",
                        content: text.substring(0, 1000) // Limit length
                    }
                ],
                max_tokens: 100,
                temperature: 0.1,
            });
            const summary = response.choices[0]?.message?.content || text;
            // Use the summary text to generate pseudo-embedding
            return this.generatePseudoEmbedding(summary);
        }
        catch (error) {
            console.error(`Semantic embedding failed: ${error.message}`);
            return this.generatePseudoEmbedding(text);
        }
    }
}
//# sourceMappingURL=embeddings-deepseek.js.map