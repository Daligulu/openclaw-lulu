/**
 * LanceDB operations for agent memories.
 * L0/L1/L2 tiered schema with category-filtered vector search.
 */
import * as lancedb from "@lancedb/lancedb";
import { randomUUID } from "node:crypto";
import { MEMORY_CATEGORIES, } from "./types.js";
import { DEFAULTS } from "./config.js";
const TABLE_NAME = "agent_memories";
// --- Input sanitization (CRITICAL: prevents LanceDB filter injection) ---
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const VALID_CATEGORIES = new Set(MEMORY_CATEGORIES);
export function assertCategory(value) {
    if (!VALID_CATEGORIES.has(value)) {
        throw new Error(`Invalid memory category: ${value}`);
    }
}
export function assertUuid(value) {
    if (!UUID_RE.test(value)) {
        throw new Error(`Invalid UUID: ${value}`);
    }
}
function rowToEntry(row) {
    return {
        id: row.id,
        category: row.category,
        abstract: row.abstract,
        overview: row.overview,
        content: row.content,
        vector: Array.from(row.vector),
        source_session: row.source_session,
        active_count: row.active_count,
        created_at: row.created_at,
        updated_at: row.updated_at,
    };
}
/**
 * Computes decay-adjusted score for memory search results.
 *
 * Formula:
 *   decayScore = vectorScore * timeDecay * activeBoost
 *
 * Where:
 *   - timeDecay = 2^(-ageDays / halfLifeDays)  (exponential decay)
 *   - activeBoost = 1 + activeWeight * log(1 + activeCount)  (logarithmic boost)
 *
 * @param vectorScore - Original similarity score from vector search (0-1)
 * @param createdAt - Memory creation timestamp in milliseconds
 * @param activeCount - Number of times this memory was activated/recalled
 * @param config - Decay configuration
 * @returns Decay-adjusted score
 */
export function computeDecayScore(vectorScore, createdAt, activeCount, config) {
    if (!config.enabled)
        return vectorScore;
    const ageDays = (Date.now() - createdAt) / (1000 * 60 * 60 * 24);
    const timeDecay = Math.pow(2, -ageDays / config.halfLifeDays);
    const activeBoost = 1 + config.activeWeight * Math.log(1 + activeCount);
    return vectorScore * timeDecay * activeBoost;
}
export class MemoryDB {
    dbPath;
    vectorDim;
    logger;
    db = null;
    table = null;
    initPromise = null;
    writeLock = Promise.resolve();
    decayConfig;
    constructor(dbPath, vectorDim, logger, decayConfig) {
        this.dbPath = dbPath;
        this.vectorDim = vectorDim;
        this.logger = logger;
        // Merge provided config with defaults
        this.decayConfig = {
            enabled: decayConfig?.enabled ?? DEFAULTS.decay.enabled,
            halfLifeDays: decayConfig?.halfLifeDays ?? DEFAULTS.decay.halfLifeDays,
            activeWeight: decayConfig?.activeWeight ?? DEFAULTS.decay.activeWeight,
        };
    }
    /** Serialize all write operations to prevent concurrent read-modify-write races. */
    async withWriteLock(fn) {
        const prev = this.writeLock;
        let resolve;
        this.writeLock = new Promise((r) => {
            resolve = r;
        });
        await prev;
        try {
            return await fn();
        }
        finally {
            resolve();
        }
    }
    async ensureInit() {
        if (this.table)
            return;
        if (this.initPromise)
            return this.initPromise;
        this.initPromise = this.doInit().catch((err) => {
            this.initPromise = null;
            throw err;
        });
        return this.initPromise;
    }
    async doInit() {
        this.db = await lancedb.connect(this.dbPath);
        const tables = await this.db.tableNames();
        if (tables.includes(TABLE_NAME)) {
            this.table = await this.db.openTable(TABLE_NAME);
        }
        else {
            // Create table with schema row then delete it
            this.table = await this.db.createTable(TABLE_NAME, [
                {
                    id: "__schema__",
                    category: "patterns",
                    abstract: "",
                    overview: "",
                    content: "",
                    vector: new Array(this.vectorDim).fill(0),
                    source_session: "",
                    active_count: 0,
                    created_at: 0,
                    updated_at: 0,
                },
            ]);
            await this.table.delete('id = "__schema__"');
            this.logger.info("epro-memory: created agent_memories table");
        }
    }
    async store(entry) {
        await this.ensureInit();
        const now = Date.now();
        const row = {
            ...entry,
            id: randomUUID(),
            active_count: 0,
            created_at: now,
            updated_at: now,
        };
        await this.table.add([row]);
        return row;
    }
    async search(vector, limit = 5, minScore = 0.3, categoryFilter) {
        await this.ensureInit();
        // When decay is enabled, fetch more candidates to ensure enough results after scoring
        const fetchLimit = this.decayConfig.enabled ? Math.max(limit * 3, 20) : limit;
        let query = this.table.vectorSearch(vector).limit(fetchLimit);
        if (categoryFilter) {
            assertCategory(categoryFilter);
            query = query.where(`category = '${categoryFilter}'`);
        }
        const results = await query.toArray();
        return results
            .map((row) => {
            const distance = row._distance ?? 0;
            const vectorScore = 1 / (1 + distance);
            const entry = rowToEntry(row);
            // Apply decay scoring
            const score = computeDecayScore(vectorScore, entry.created_at, entry.active_count, this.decayConfig);
            return { entry, score };
        })
            .sort((a, b) => b.score - a.score)
            .filter((r) => r.score >= minScore)
            .slice(0, limit);
    }
    async findByCategory(category) {
        await this.ensureInit();
        assertCategory(category);
        const results = await this.table.query()
            .where(`category = '${category}'`)
            .limit(100)
            .toArray();
        return results.map((row) => rowToEntry(row));
    }
    async getById(id) {
        await this.ensureInit();
        assertUuid(id);
        const results = await this.table.query()
            .where(`id = '${id}'`)
            .limit(1)
            .toArray();
        if (results.length === 0)
            return null;
        return rowToEntry(results[0]);
    }
    async update(id, fields) {
        await this.ensureInit();
        assertUuid(id);
        await this.withWriteLock(async () => {
            const existing = await this.table.query()
                .where(`id = '${id}'`)
                .limit(1)
                .toArray();
            if (existing.length === 0)
                return;
            // Strip Arrow/Lance internal fields via rowToEntry before writing back
            const clean = rowToEntry(existing[0]);
            // Prevent callers from overwriting immutable fields
            const { id: _id, created_at: _ca, source_session: _ss, ...safeFields } = fields;
            const updated = { ...clean, ...safeFields, updated_at: Date.now() };
            // Delete then add with same ID; restore original on add failure
            await this.table.delete(`id = '${id}'`);
            try {
                await this.table.add([updated]);
            }
            catch (err) {
                await this.table.add([clean]);
                throw err;
            }
        });
    }
    async incrementActiveCount(id) {
        await this.ensureInit();
        assertUuid(id);
        await this.withWriteLock(async () => {
            const existing = await this.table.query()
                .where(`id = '${id}'`)
                .limit(1)
                .toArray();
            if (existing.length === 0)
                return;
            // Strip Arrow/Lance internal fields via rowToEntry before writing back
            const clean = rowToEntry(existing[0]);
            const updated = {
                ...clean,
                active_count: (clean.active_count || 0) + 1,
                updated_at: Date.now(),
            };
            // Delete then add with same ID; restore original on add failure
            await this.table.delete(`id = '${id}'`);
            try {
                await this.table.add([updated]);
            }
            catch (err) {
                await this.table.add([clean]);
                throw err;
            }
        });
    }
    /**
     * Get all memories from the database.
     * Used by QMD projection to generate daily summaries.
     *
     * @param maxLimit - Maximum number of records to return (default: 10000)
     * @returns Array of all memory entries
     */
    async getAll(maxLimit = 10000) {
        await this.ensureInit();
        const results = await this.table.query().limit(maxLimit).toArray();
        return results.map((row) => rowToEntry(row));
    }
}
//# sourceMappingURL=db.js.map