#!/bin/bash
# 注册新的EvoMap节点脚本
# 为峰峰生成新的唯一节点ID

set -e

echo "🆕 EvoMap新节点注册脚本启动"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 检查依赖
if ! command -v jq &> /dev/null; then
    echo "❌ 需要安装jq工具"
    echo "💡 安装命令: apt-get install jq 或 yum install jq"
    exit 1
fi

if ! command -v curl &> /dev/null; then
    echo "❌ 需要安装curl工具"
    echo "💡 安装命令: apt-get install curl 或 yum install curl"
    exit 1
fi

# 生成新的唯一节点ID
NEW_NODE_ID="node_$(uuidgen | tr -d '-')"
echo "🎯 生成新的节点ID: $NEW_NODE_ID"
echo ""

# 1. 发送hello消息注册新节点
echo "📡 发送hello消息注册新节点..."
HELLO_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "'$NEW_NODE_ID'",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {
        "ai_assistant": true,
        "content_creation": true,
        "data_analysis": true,
        "automation": true,
        "web_scraping": true,
        "api_integration": true,
        "content_strategy": true,
        "hotspot_analysis": true,
        "multi_platform_content": true
      },
      "env_fingerprint": { 
        "platform": "linux", 
        "arch": "x64",
        "agent": "璐璐 - 峰峰的内容助手",
        "version": "2.0.0",
        "owner": "峰峰",
        "email": "gaojunfeng1108@gmail.com"
      }
    }
  }')

echo "✅ Hello消息发送完成"

# 解析响应
if [ -z "$HELLO_RESPONSE" ]; then
    echo "❌ 未收到响应，检查网络连接"
    exit 1
fi

echo "📄 响应内容:"
echo "$HELLO_RESPONSE" | jq .

# 2. 检查注册状态
echo ""
echo "🔍 检查注册状态..."
STATUS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.status // "unknown"')
YOUR_NODE_ID=$(echo "$HELLO_RESPONSE" | jq -r '.payload.your_node_id // "unknown"')
HUB_NODE_ID=$(echo "$HELLO_RESPONSE" | jq -r '.payload.hub_node_id // "unknown"')
CREDITS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.credit_balance // 0')
CLAIM_CODE=$(echo "$HELLO_RESPONSE" | jq -r '.payload.claim_code // "unknown"')
CLAIM_URL=$(echo "$HELLO_RESPONSE" | jq -r '.payload.claim_url // "unknown"')

echo "📊 注册结果:"
echo "   - 状态: $STATUS"
echo "   - 你的节点ID: $YOUR_NODE_ID"
echo "   - Hub节点ID: $HUB_NODE_ID"
echo "   - 初始积分: $CREDITS"
echo "   - 认领码: $CLAIM_CODE"
echo "   - 认领URL: $CLAIM_URL"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 新节点注册成功!"
    
    # 保存节点配置
    echo ""
    echo "💾 保存节点配置..."
    CONFIG_FILE="/root/.openclaw/workspace/evomap-feng-config.json"
    cat > "$CONFIG_FILE" << EOF
{
  "node_id": "$YOUR_NODE_ID",
  "hub_node_id": "$HUB_NODE_ID",
  "claim_code": "$CLAIM_CODE",
  "claim_url": "$CLAIM_URL",
  "user_account": "gaojunfeng1108@gmail.com",
  "initial_credits": $CREDITS,
  "registration_time": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "agent_name": "璐璐 - 峰峰的内容助手",
  "owner": "峰峰",
  "capabilities": [
    "ai_assistant",
    "content_creation",
    "data_analysis",
    "automation",
    "web_scraping",
    "api_integration",
    "content_strategy",
    "hotspot_analysis",
    "multi_platform_content"
  ]
}
EOF
    
    echo "✅ 配置已保存到: $CONFIG_FILE"
    
    # 创建新的保持在线脚本
    echo ""
    echo "📝 创建新的保持在线脚本..."
    KEEPALIVE_SCRIPT="/root/.openclaw/workspace/keep-evo-node-online-feng-new.sh"
    cat > "$KEEPALIVE_SCRIPT" << 'EOF'
#!/bin/bash
# EvoMap节点保持在线脚本 - 峰峰新节点专用
# 使用新注册的节点ID

set -e

# 读取配置
CONFIG_FILE="/root/.openclaw/workspace/evomap-feng-config.json"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ 配置文件不存在: $CONFIG_FILE"
    exit 1
fi

NODE_ID=$(jq -r '.node_id' "$CONFIG_FILE")
HUB_NODE_ID=$(jq -r '.hub_node_id' "$CONFIG_FILE")
CLAIM_CODE=$(jq -r '.claim_code' "$CONFIG_FILE")
USER_ACCOUNT=$(jq -r '.user_account' "$CONFIG_FILE")

echo "🔗 EvoMap节点保持在线脚本启动"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: $NODE_ID"
echo "   - Hub节点ID: $HUB_NODE_ID"
echo "   - 认领码: $CLAIM_CODE"
echo "   - 用户账户: $USER_ACCOUNT"
echo ""

# 发送hello消息保持节点活跃
echo "📡 发送hello消息..."
HELLO_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "'$NODE_ID'",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {},
      "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
  }')

STATUS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.status // "unknown"')
CREDITS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.credit_balance // 0')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 积分余额: $CREDITS"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃"
    
    # 发送心跳消息
    echo "💓 发送心跳消息..."
    curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "'$NODE_ID'",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {}
        }
      }' > /dev/null && echo "✅ 心跳消息发送完成"
else
    echo "⚠️ 节点状态: $STATUS"
fi

echo ""
echo "🎯 脚本执行完成"
EOF
    
    chmod +x "$KEEPALIVE_SCRIPT"
    echo "✅ 保持在线脚本已创建: $KEEPALIVE_SCRIPT"
    
    # 配置cron job
    echo ""
    echo "⏰ 配置cron job保持节点在线..."
    CRON_JOB="*/30 * * * * $KEEPALIVE_SCRIPT >> /root/.openclaw/workspace/evomap-keepalive-feng.log 2>&1"
    
    # 检查是否已存在cron job
    if crontab -l 2>/dev/null | grep -q "$KEEPALIVE_SCRIPT"; then
        echo "✅ cron job已存在"
    else
        (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
        echo "✅ cron job已添加: 每30分钟执行一次"
    fi
    
    # 测试保持在线脚本
    echo ""
    echo "🧪 测试保持在线脚本..."
    "$KEEPALIVE_SCRIPT"
    
    echo ""
    echo "📋 下一步操作指南:"
    echo "1. 🔗 打开认领URL绑定节点到你的账户:"
    echo "   $CLAIM_URL"
    echo "2. 📊 使用账户 gaojunfeng1108@gmail.com 登录EvoMap Web客户端"
    echo "3. 🎯 查看新节点状态和积分"
    echo "4. ⏰ cron job已配置: 每30分钟保持节点在线"
    echo "5. 📝 查看日志: tail -f /root/.openclaw/workspace/evomap-keepalive-feng.log"
    
else
    echo "❌ 节点注册失败: $STATUS"
    echo "💡 可能的原因:"
    echo "   1. 网络连接问题"
    echo "   2. EvoMap Hub服务异常"
    echo "   3. 生成的节点ID仍然冲突"
fi

echo ""
echo "🎯 新节点注册流程完成"