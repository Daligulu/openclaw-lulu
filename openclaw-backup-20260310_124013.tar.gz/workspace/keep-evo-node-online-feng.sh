#!/bin/bash
# EvoMap节点保持在线脚本 - 峰峰专用
# 节点ID: node_d11440709e39
# Hub节点ID: hub_0f978bbe1fb5
# 认领码: L5KD-XQRX
# 认领URL: https://evomap.ai/claim/L5KD-XQRX
# 用户账户: gaojunfeng1108@gmail.com

set -e

echo "🔗 EvoMap节点保持在线脚本启动 - 峰峰专用"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: node_d11440709e39"
echo "   - Hub节点ID: hub_0f978bbe1fb5"
echo "   - 认领码: L5KD-XQRX"
echo "   - 认领URL: https://evomap.ai/claim/L5KD-XQRX"
echo "   - 用户账户: gaojunfeng1108@gmail.com"
echo ""

# 检查依赖
if ! command -v jq &> /dev/null; then
    echo "❌ 需要安装jq工具"
    echo "💡 安装命令: apt-get install jq 或 yum install jq"
    exit 1
fi

if ! command -v curl &> /dev/null; then
    echo "❌ 需要安装curl工具"
    echo "💡 安装命令: apt-get install curl 或 yum install curl"
    exit 1
fi

# 1. 发送hello消息保持节点活跃
echo "📡 发送hello消息到EvoMap Hub..."
HELLO_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "node_d11440709e39",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {
        "ai_assistant": true,
        "content_creation": true,
        "data_analysis": true,
        "automation": true,
        "web_scraping": true,
        "api_integration": true
      },
      "env_fingerprint": { 
        "platform": "linux", 
        "arch": "x64",
        "agent": "璐璐",
        "version": "1.0.0"
      },
      "referrer": "node_d11440709e39"
    }
  }')

echo "✅ Hello消息发送完成"

# 解析响应
if [ -z "$HELLO_RESPONSE" ]; then
    echo "❌ 未收到响应，检查网络连接"
    exit 1
fi

echo "📄 响应内容:"
echo "$HELLO_RESPONSE" | jq .

# 2. 检查节点状态
echo ""
echo "🔍 检查节点状态..."
STATUS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.status // "unknown"')
NODE_ID=$(echo "$HELLO_RESPONSE" | jq -r '.payload.your_node_id // "unknown"')
HUB_NODE_ID=$(echo "$HELLO_RESPONSE" | jq -r '.payload.hub_node_id // "unknown"')
CREDITS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.credit_balance // 0')
CLAIM_CODE=$(echo "$HELLO_RESPONSE" | jq -r '.payload.claim_code // "unknown"')
CLAIM_URL=$(echo "$HELLO_RESPONSE" | jq -r '.payload.claim_url // "unknown"')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 节点ID: $NODE_ID"
echo "   - Hub节点ID: $HUB_NODE_ID"
echo "   - 积分余额: $CREDITS"
echo "   - 认领码: $CLAIM_CODE"
echo "   - 认领URL: $CLAIM_URL"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃"
    
    # 3. 发送心跳消息
    echo ""
    echo "💓 发送心跳消息..."
    HEARTBEAT_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "node_d11440709e39",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {},
          "last_activity": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"
        }
      }')
    
    if [ -n "$HEARTBEAT_RESPONSE" ]; then
        echo "✅ 心跳消息发送成功"
        echo "$HEARTBEAT_RESPONSE" | jq -r '.payload.message // "Heartbeat acknowledged"'
    else
        echo "⚠️ 心跳消息无响应"
    fi
    
    # 4. 检查evolver运行状态
    echo ""
    echo "🔄 检查evolver运行状态..."
    if pgrep -f "evolver" > /dev/null; then
        echo "✅ evolver正在运行"
        EVOLVER_PID=$(pgrep -f "evolver")
        echo "   - 进程ID: $EVOLVER_PID"
        
        # 检查evolver配置
        if [ -f "/root/.openclaw/workspace/evolver/.env" ]; then
            echo "   - 配置文件: /root/.openclaw/workspace/evolver/.env"
            echo "   - 配置内容:"
            grep -E "^(A2A|NODE)" /root/.openclaw/workspace/evolver/.env || echo "     (无相关配置)"
        fi
    else
        echo "⚠️ evolver未运行"
        echo "💡 建议启动evolver:"
        echo "   cd /root/.openclaw/workspace/evolver"
        echo "   npm start"
    fi
    
    # 5. 检查cron job状态
    echo ""
    echo "⏰ 检查cron job状态..."
    if crontab -l 2>/dev/null | grep -q "evomap\|keep-evo-node"; then
        echo "✅ EvoMap相关cron job已配置"
        crontab -l 2>/dev/null | grep -E "evomap|keep-evo-node" || true
    else
        echo "⚠️ EvoMap相关cron job未配置"
        echo "💡 建议配置每30分钟保持在线的cron job:"
        echo "   */30 * * * * /root/.openclaw/workspace/keep-evo-node-online-feng.sh >> /root/.openclaw/workspace/evomap-keepalive.log 2>&1"
    fi
    
    # 6. 检查资产状态
    echo ""
    echo "📦 检查资产状态..."
    ASSETS_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/fetch \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "fetch",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "node_d11440709e39",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "asset_type": "Capsule",
          "limit": 5
        }
      }')
    
    ASSET_COUNT=$(echo "$ASSETS_RESPONSE" | jq -r '.payload.assets | length // 0')
    echo "   - 可获取的Capsule资产数量: $ASSET_COUNT"
    
else
    echo "❌ 节点状态异常: $STATUS"
    echo "💡 可能的原因:"
    echo "   1. 节点ID已被其他用户认领"
    echo "   2. 网络连接问题"
    echo "   3. EvoMap Hub服务异常"
    echo ""
    echo "🔄 尝试重新注册新节点..."
    # 这里可以添加重新注册的逻辑
fi

echo ""
echo "📋 重要操作指南:"
echo "1. ✅ 使用正确的节点ID: node_d11440709e39"
echo "2. 🔗 在EvoMap Web客户端使用账户 gaojunfeng1108@gmail.com 查看节点状态"
echo "3. ⏰ 配置cron job保持节点在线:"
echo "   crontab -e"
echo "   添加: */30 * * * * /root/.openclaw/workspace/keep-evo-node-online-feng.sh >> /root/.openclaw/workspace/evomap-keepalive.log 2>&1"
echo "4. 🚀 启动evolver客户端:"
echo "   cd /root/.openclaw/workspace/evolver"
echo "   npm start"
echo "5. 📊 查看节点状态日志:"
echo "   tail -f /root/.openclaw/workspace/evomap-keepalive.log"

echo ""
echo "🎯 脚本执行完成 - 节点保持在线状态已更新"