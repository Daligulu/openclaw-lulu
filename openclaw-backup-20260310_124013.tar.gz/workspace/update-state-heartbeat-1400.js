const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新当前任务
state.currentTasks = [
  "EvoMap同步完成（13:57），发布6个Gene资产和3个EvolutionEvent资产",
  "Tech-News-Digest发现重要AI热点（12:02）",
  "OpenClaw备份完成（12:00），+9KB（+0%），Telegram消息ID: 2571",
  "Tech-News-Digest发现3条NBA热点（12:00）",
  "MEMORY.md编辑失败已修复（10:07）",
  "Tech-News-Digest运行完成（09:00），发现24个AI热点",
  "每日记忆整理完成（08:00）",
  "Content Agent每日选题执行完成（07:30，耗时23.24秒）"
];

// 更新EvoMap状态
state.evomapProgress = {
  "status": "sync_completed",
  "timestamp": "2026-02-25T05:57:00",
  "nodeId": "node_d0cf2a3b4b3946a492a8e72e381e1198",
  "hubNodeId": "hub_0f978bbe1fb5",
  "assetsPublished": {
    "genes": 6,
    "capsules": 0,
    "evolutionEvents": 3,
    "total": 9
  },
  "geneAssets": [
    "gene_gep_repair_from_errors",
    "gene_gep_optimize_prompt_and_assets", 
    "gene_gep_innovate_from_opportunity",
    "gene_agent_error_auto_repair",
    "gene_feishu_doc_error_fix",
    "gene_json_parse_watchdog_fix"
  ],
  "evolutionEventAssets": [
    "evt_1770477201173",
    "evt_1770477654236", 
    "evt_1770478341769"
  ],
  "expectedPoints": {
    "conservative": "1500-1800积分",
    "optimistic": "2000-2400积分"
  },
  "verificationTime": "预计几小时到24小时",
  "nextSync": "2026-02-25T09:57:00",
  "syncFrequency": "每4小时一次",
  "protocolVersion": "GEP-A2A v1.0.0",
  "signatureVerification": "全部通过",
  "connectionStatus": "活跃状态"
};

// 更新备份状态
state.backupStatus = {
  "lastBackup": "2026-02-25T12:00:36",
  "backupFile": "openclaw-backup-20260225_120038.tar.gz",
  "size": "6916KB",
  "change": "+9KB",
  "percentage": "+0%",
  "status": "completed",
  "githubPushed": true,
  "telegramReported": true,
  "messageId": "2571",
  "details": "OpenClaw备份成功，大小6,916KB，增长9KB（+0%），已推送到GitHub仓库"
};

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
