/**
 * Checkpoint manager for resumable memory extraction.
 * Enables extraction process to resume from where it left off if interrupted.
 *
 * P2-002 from ITERATION-SPEC.md
 */
import type { CandidateMemory, PluginLogger } from "./types.js";
/** Checkpoint configuration */
export interface CheckpointConfig {
    /** Whether checkpoint feature is enabled. Default: false for backward compatibility */
    enabled: boolean;
    /** Base path for storing checkpoint files */
    path: string;
    /** Whether to auto-recover incomplete extractions on startup. Default: true */
    autoRecoverOnStart: boolean;
}
/** Default checkpoint configuration */
export declare const CHECKPOINT_DEFAULTS: CheckpointConfig;
/** Stage of extraction process */
export type ExtractionStage = "extracting" | "deduping" | "storing";
/** Checkpoint data structure for persistence */
export interface ExtractionCheckpoint {
    /** Session key identifying this extraction */
    sessionKey: string;
    /** Current stage of extraction */
    stage: ExtractionStage;
    /** All candidate memories extracted */
    candidates: CandidateMemory[];
    /** Index of last successfully processed candidate (0-based, -1 means none processed) */
    processedIndex: number;
    /** Timestamp when checkpoint was created/updated */
    timestamp: number;
    /** User identifier */
    user: string;
}
/**
 * Manages checkpoint persistence for resumable extraction.
 */
export declare class CheckpointManager {
    private basePath;
    private logger;
    constructor(basePath: string, logger: PluginLogger);
    /**
     * Get the file path for a checkpoint.
     */
    private getPath;
    /**
     * Ensure checkpoint directory exists.
     */
    private ensureDir;
    /**
     * Save checkpoint to disk.
     * Called after each candidate is processed.
     */
    save(checkpoint: ExtractionCheckpoint): Promise<void>;
    /**
     * Load checkpoint from disk.
     * Returns null if no checkpoint exists.
     */
    load(sessionKey: string): Promise<ExtractionCheckpoint | null>;
    /**
     * Clear checkpoint after successful extraction completion.
     */
    clear(sessionKey: string): Promise<void>;
    /**
     * Find all incomplete extractions.
     * Used for startup recovery.
     */
    findIncomplete(): Promise<ExtractionCheckpoint[]>;
    /**
     * Create initial checkpoint for a new extraction.
     */
    createInitial(sessionKey: string, candidates: CandidateMemory[], user: string): ExtractionCheckpoint;
    /**
     * Update checkpoint after processing a candidate.
     */
    updateProgress(checkpoint: ExtractionCheckpoint, processedIndex: number, stage?: ExtractionStage): ExtractionCheckpoint;
}
//# sourceMappingURL=checkpoint.d.ts.map