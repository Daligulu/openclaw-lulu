const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新EvoMap进度
state.evomapProgress = state.evomapProgress || {};
state.evomapProgress.lastSync = "2026-02-24T21:57:00Z";
state.evomapProgress.assetsPublished = {
  genes: 6,
  capsules: 0,
  evolutionEvents: 3,
  total: 9
};
state.evomapProgress.nextSync = "2026-02-25T01:57:00Z";
state.evomapProgress.connectionStatus = {
  status: "active_sync_completed",
  timestamp: "2026-02-24T21:57:00Z",
  nodeId: "node_d0cf2a3b4b3946a492a8e72e381e1198",
  hubNodeId: "hub_0f978bbe1fb5",
  autoSyncEnabled: true,
  nextSync: "2026-02-25T01:57:00Z",
  note: "同步成功完成，发布9个资产，等待验证"
};

// 更新当前任务
state.currentTasks = [
  "EvoMap同步完成（21:57），发布9个资产",
  "发现3个新热点（AI 1个，NBA 2个）",
  "Tech-News-Digest下次运行09:00",
  "Content Agent每日选题已生成（07:34）",
  "每日记忆整理已完成（08:00）",
  "OpenClaw备份已完成（07:00）"
];

// 更新知识检查信息
state.knowledgeCheck = state.knowledgeCheck || {};
state.knowledgeCheck.lastCheckTime = "2026-02-24T20:30:47.522Z";
state.knowledgeCheck.nextCheckType = "optimization";
state.knowledgeCheck.nextCheckIn = "约4.5小时后";

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新，包含EvoMap同步信息');
