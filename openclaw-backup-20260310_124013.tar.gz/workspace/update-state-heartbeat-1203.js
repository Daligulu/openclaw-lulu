const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新当前任务
state.currentTasks = [
  "OpenClaw备份完成（12:00），+9KB（+0%），Telegram消息ID: 2571",
  "Tech-News-Digest发现3条NBA热点（12:00）",
  "MEMORY.md编辑失败已修复（10:07）",
  "Tech-News-Digest运行完成（09:00），发现24个AI热点",
  "每日记忆整理完成（08:00）",
  "Content Agent每日选题执行完成（07:30，耗时23.24秒）",
  "EvoMap同步完成（22:57），下次同步05:58"
];

// 更新备份状态
state.backupStatus = {
  "lastBackup": "2026-02-25T12:00:36",
  "backupFile": "openclaw-backup-20260225_120038.tar.gz",
  "size": "6916KB",
  "change": "+9KB",
  "percentage": "+0%",
  "status": "completed",
  "githubPushed": true,
  "telegramReported": true,
  "messageId": "2571",
  "details": "OpenClaw备份成功，大小6,916KB，增长9KB（+0%），已推送到GitHub仓库"
};

// 更新NBA热点发现
state.newHotspotsFound = {
  "timestamp": "2026-02-25T12:00:30",
  "aiTopics": 0,
  "dogTopics": 0,
  "nbaTopics": 3,
  "total": 3,
  "status": "needs_reporting",
  "telegramMessageId": null,
  "hotspots": [
    {
      "title": "步行者主帅怒喷NBA调查'荒谬'",
      "category": "NBA-联盟政策",
      "priority": "⭐⭐⭐⭐⭐",
      "source": "https://sports.yahoo.com/nba/article/pacers-coach-rick-carlisle-sounds-off-on-nbas-ridiculous-process-investigating-teams-alleged-tanking-efforts-211019648.html",
      "description": "步行者主帅里克·卡莱尔公开批评NBA对其球队'摆烂'指控的调查过程'荒谬'，此前球队因轮休多名主力被罚款10万美元"
    },
    {
      "title": "字母哥夏季交易传闻升温",
      "category": "NBA-交易流言",
      "priority": "⭐⭐⭐⭐⭐",
      "source": "https://www.totalprosports.com/nba/giannis-antetokounmpo-trade-rumors-nine-teams-monitoring-his-summer-availability/",
      "description": "据报道，包括热火、勇士、湖人、尼克斯在内的9支球队正在密切关注字母哥（Giannis Antetokounmpo）今年夏天的交易可能性"
    },
    {
      "title": "湖人瞄准骑士中锋贾勒特·艾伦",
      "category": "NBA-交易流言",
      "priority": "⭐⭐⭐⭐",
      "source": "https://timesofindia.indiatimes.com/sports/nba/top-stories/nba-trade-rumors-los-angeles-lakers-predicted-to-trade-for-131-million-cleveland-cavalier-superstar-to-bolster-roster-austin-reaves-key-trade-asset/articleshow/128734105.cms",
      "description": "湖人队考虑在交易截止日前交易骑士队中锋贾勒特·艾伦（价值1.31亿美元），可能送出奥斯汀·里夫斯和未来选秀权"
    }
  ]
};

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
