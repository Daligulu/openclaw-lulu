#!/bin/bash
# EvoMap节点管理器 - 峰峰专用
# 完整节点管理：保持在线、资产发布、任务处理、状态监控

set -e

CONFIG_FILE="/root/.openclaw/workspace/evomap-feng-config.json"
BASE_URL="https://evomap.ai/a2a"
LOG_FILE="/root/.openclaw/workspace/evomap-manager.log"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 加载配置
load_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        echo -e "${RED}❌ 配置文件不存在: $CONFIG_FILE${NC}"
        exit 1
    fi
    
    NODE_ID=$(jq -r '.node_id' "$CONFIG_FILE")
    HUB_NODE_ID=$(jq -r '.hub_node_id' "$CONFIG_FILE")
    CLAIM_CODE=$(jq -r '.claim_code' "$CONFIG_FILE")
    USER_ACCOUNT=$(jq -r '.user_account' "$CONFIG_FILE")
    
    echo -e "${BLUE}📊 加载配置:${NC}"
    echo -e "   - 节点ID: ${GREEN}$NODE_ID${NC}"
    echo -e "   - Hub节点ID: $HUB_NODE_ID"
    echo -e "   - 认领码: $CLAIM_CODE"
    echo -e "   - 用户账户: $USER_ACCOUNT"
    echo ""
}

# 生成消息ID
generate_message_id() {
    echo "msg_$(date +%s%N)_$(shuf -i 100000-999999 -n 1)"
}

# 发送API请求
send_request() {
    local endpoint="$1"
    local payload="$2"
    
    local response=$(curl -s -X POST "${BASE_URL}/${endpoint}" \
        -H "Content-Type: application/json" \
        -d "$payload" \
        --max-time 30)
    
    echo "$response"
}

# 保持节点在线
keep_online() {
    echo -e "${BLUE}🔗 保持节点在线${NC}"
    
    local payload=$(cat << EOF
{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "$(generate_message_id)",
    "sender_id": "$NODE_ID",
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "payload": {
        "capabilities": {},
        "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
}
EOF
    )
    
    local response=$(send_request "hello" "$payload")
    local status=$(echo "$response" | jq -r '.payload.status // "unknown"')
    local credits=$(echo "$response" | jq -r '.payload.credit_balance // 0')
    
    if [ "$status" = "acknowledged" ]; then
        echo -e "${GREEN}✅ 节点在线${NC} - 积分: $credits"
        
        # 发送心跳
        local heartbeat_payload=$(cat << EOF
{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "heartbeat",
    "message_id": "$(generate_message_id)",
    "sender_id": "$NODE_ID",
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "payload": {
        "status": "active",
        "capabilities": {}
    }
}
EOF
        )
        
        send_request "heartbeat" "$heartbeat_payload" > /dev/null
        echo -e "${GREEN}✅ 心跳发送完成${NC}"
    else
        echo -e "${RED}❌ 节点状态异常: $status${NC}"
    fi
    
    echo ""
}

# 获取资产
fetch_assets() {
    echo -e "${BLUE}📦 获取推荐资产${NC}"
    
    local payload=$(cat << EOF
{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "fetch",
    "message_id": "$(generate_message_id)",
    "sender_id": "$NODE_ID",
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "payload": {
        "asset_type": "Capsule",
        "limit": 5
    }
}
EOF
    )
    
    local response=$(send_request "fetch" "$payload")
    local asset_count=$(echo "$response" | jq -r '.payload.assets | length // 0')
    
    echo -e "📊 可获取资产数量: ${GREEN}$asset_count${NC}"
    
    if [ "$asset_count" -gt 0 ]; then
        echo -e "${GREEN}✅ 推荐资产:${NC}"
        echo "$response" | jq -r '.payload.assets[] | "  • \(.summary[:80])..."' | head -5
    fi
    
    echo ""
}

# 获取任务
fetch_tasks() {
    echo -e "${BLUE}🎯 获取可用任务${NC}"
    
    local payload=$(cat << EOF
{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "fetch",
    "message_id": "$(generate_message_id)",
    "sender_id": "$NODE_ID",
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "payload": {
        "include_tasks": true,
        "limit": 3
    }
}
EOF
    )
    
    local response=$(send_request "fetch" "$payload")
    local task_count=$(echo "$response" | jq -r '.payload.tasks | length // 0')
    
    echo -e "📊 可用任务数量: ${GREEN}$task_count${NC}"
    
    if [ "$task_count" -gt 0 ]; then
        echo -e "${GREEN}✅ 推荐任务:${NC}"
        echo "$response" | jq -r '.payload.tasks[] | "  • \(.title) (信誉要求: \(.min_reputation))"' | head -3
    fi
    
    echo ""
}

# 检查节点状态
check_status() {
    echo -e "${BLUE}📊 检查节点状态${NC}"
    
    local payload=$(cat << EOF
{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "$(generate_message_id)",
    "sender_id": "$NODE_ID",
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "payload": {
        "capabilities": {},
        "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
}
EOF
    )
    
    local response=$(send_request "hello" "$payload")
    
    echo "$response" | jq -r '.payload | "  状态: \(.status)\n  积分: \(.credit_balance)\n  生存状态: \(.survival_status)\n  心跳间隔: \(.heartbeat_interval_ms)ms\n  推荐资产数: \(.recommended_assets | length)"'
    
    echo ""
}

# 查看网络统计
network_stats() {
    echo -e "${BLUE}🌐 网络统计${NC}"
    
    local payload=$(cat << EOF
{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "$(generate_message_id)",
    "sender_id": "$NODE_ID",
    "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
    "payload": {
        "capabilities": {},
        "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
}
EOF
    )
    
    local response=$(send_request "hello" "$payload")
    local stats=$(echo "$response" | jq -r '.payload.network_manifest.stats')
    
    if [ "$stats" != "null" ]; then
        echo "$stats" | jq -r '"  总代理数: \(.total_agents)\n  24小时活跃: \(.active_24h)\n  总资产数: \(.total_assets)\n  已推广资产: \(.promoted_assets)"'
    else
        echo -e "${YELLOW}⚠️ 无法获取网络统计${NC}"
    fi
    
    echo ""
}

# 日志记录
log_message() {
    local message="$1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $message" >> "$LOG_FILE"
}

# 主菜单
main_menu() {
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}   EvoMap节点管理器 - 峰峰专用   ${NC}"
    echo -e "${BLUE}================================${NC}"
    echo ""
    
    load_config
    
    echo -e "${YELLOW}请选择操作:${NC}"
    echo "1. 🔗 保持节点在线"
    echo "2. 📊 检查节点状态"
    echo "3. 📦 获取推荐资产"
    echo "4. 🎯 获取可用任务"
    echo "5. 🌐 查看网络统计"
    echo "6. ⏰ 执行完整检查（所有功能）"
    echo "7. 📝 查看日志"
    echo "8. 🚪 退出"
    echo ""
    
    read -p "请输入选项 (1-8): " choice
    
    case $choice in
        1)
            log_message "执行: 保持节点在线"
            keep_online
            ;;
        2)
            log_message "执行: 检查节点状态"
            check_status
            ;;
        3)
            log_message "执行: 获取推荐资产"
            fetch_assets
            ;;
        4)
            log_message "执行: 获取可用任务"
            fetch_tasks
            ;;
        5)
            log_message "执行: 查看网络统计"
            network_stats
            ;;
        6)
            log_message "执行: 完整检查"
            keep_online
            check_status
            fetch_assets
            fetch_tasks
            network_stats
            ;;
        7)
            echo -e "${BLUE}📝 最近日志:${NC}"
            tail -20 "$LOG_FILE"
            echo ""
            ;;
        8)
            echo -e "${GREEN}👋 再见！${NC}"
            exit 0
            ;;
        *)
            echo -e "${RED}❌ 无效选项${NC}"
            echo ""
            ;;
    esac
    
    # 返回主菜单
    read -p "按回车键返回主菜单..."
    echo ""
    main_menu
}

# 检查依赖
check_dependencies() {
    if ! command -v jq &> /dev/null; then
        echo -e "${RED}❌ 需要安装jq工具${NC}"
        echo "安装命令: apt-get install jq 或 yum install jq"
        exit 1
    fi
    
    if ! command -v curl &> /dev/null; then
        echo -e "${RED}❌ 需要安装curl工具${NC}"
        echo "安装命令: apt-get install curl 或 yum install curl"
        exit 1
    fi
}

# 初始化日志
init_log() {
    if [ ! -f "$LOG_FILE" ]; then
        touch "$LOG_FILE"
        echo "EvoMap节点管理器日志 - 开始时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
        echo "节点ID: $NODE_ID" >> "$LOG_FILE"
        echo "用户账户: $USER_ACCOUNT" >> "$LOG_FILE"
        echo "========================================" >> "$LOG_FILE"
    fi
}

# 主函数
main() {
    check_dependencies
    init_log
    main_menu
}

# 执行主函数
main