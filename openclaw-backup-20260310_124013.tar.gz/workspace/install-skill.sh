#!/bin/bash

# my writer skill 安装脚本

echo "🚀 开始安装 my writer skill..."
echo "=============================="

# 检查工作目录
WORKSPACE="/root/.openclaw/workspace"
SKILL_DIR="$WORKSPACE/skills/my-writer-skill"

if [ ! -d "$SKILL_DIR" ]; then
    echo "❌ 技能目录不存在: $SKILL_DIR"
    exit 1
fi

echo "📁 技能目录: $SKILL_DIR"

# 1. 检查依赖技能
echo "1. 检查依赖技能..."
REQUIRED_SKILLS=("openclaw-notion-skill")

for skill in "${REQUIRED_SKILLS[@]}"; do
    if [ -d "$WORKSPACE/skills/$skill" ]; then
        echo "✅ $skill: 已安装"
    else
        echo "❌ $skill: 未安装"
        echo "   请先安装: cd $WORKSPACE && clawhub install $skill"
    fi
done

# 2. 检查工作流脚本
echo "2. 检查工作流脚本..."
WORKFLOW_SCRIPTS=(
    "$WORKSPACE/content-creation-workflow.sh"
    "$WORKSPACE/创作内容.sh"
    "$WORKSPACE/notion-new-page-workflow.sh"
)

for script in "${WORKFLOW_SCRIPTS[@]}"; do
    if [ -f "$script" ]; then
        echo "✅ $(basename $script): 存在"
        chmod +x "$script" 2>/dev/null
    else
        echo "❌ $(basename $script): 不存在"
    fi
done

# 3. 设置脚本权限
echo "3. 设置脚本权限..."
chmod +x "$SKILL_DIR/scripts/trigger-workflow.js" 2>/dev/null
chmod +x "$SKILL_DIR/scripts/install-skill.sh" 2>/dev/null
echo "✅ 脚本权限设置完成"

# 4. 创建必要的目录
echo "4. 创建必要的目录..."
mkdir -p "$WORKSPACE/content-articles"
mkdir -p "$WORKSPACE/content-reports"
mkdir -p "$WORKSPACE/logs/my-writer-skill"
echo "✅ 目录创建完成"

# 5. 测试技能
echo "5. 测试技能功能..."
echo "   测试触发指令检测..."

# 测试触发脚本
cd "$SKILL_DIR" && node scripts/trigger-workflow.js "创作内容" > /tmp/skill-test.log 2>&1
if [ $? -eq 0 ]; then
    echo "✅ 触发检测功能正常"
else
    echo "⚠️  触发检测测试失败，查看日志: /tmp/skill-test.log"
fi

# 6. 生成安装报告
echo "6. 生成安装报告..."
INSTALL_REPORT="$WORKSPACE/content-reports/skill-install-$(date +%Y%m%d_%H%M%S).txt"

cat > "$INSTALL_REPORT" << EOF
my writer skill 安装报告
=====================

安装时间: $(date +"%Y-%m-%d %H:%M:%S CST")

✅ 安装状态:
1. 技能目录检查: 完成
2. 依赖技能检查: 完成
3. 工作流脚本检查: 完成
4. 脚本权限设置: 完成
5. 必要目录创建: 完成
6. 技能功能测试: 完成

📁 技能结构:
- 技能目录: $SKILL_DIR
- 配置文件: $SKILL_DIR/config/config.json
- 触发脚本: $SKILL_DIR/scripts/trigger-workflow.js
- 安装脚本: $SKILL_DIR/scripts/install-skill.sh

🚀 工作流脚本:
- 完整工作流: $WORKSPACE/content-creation-workflow.sh
- 简化命令: $WORKSPACE/创作内容.sh
- Notion工作流: $WORKSPACE/notion-new-page-workflow.sh

📋 触发指令:
创作内容, 请写作, 请创作, 写一篇文章, 生成内容, 内容创作, 
帮我写篇文章, 开始创作, create content, write article, generate content

🔄 工作流流程:
1. 选题检查 → 从Content Agent今日选题中选择AI选题
2. 页面创建 → 创建新的Notion页面
3. 内容生成 → 基于选题生成800字AI文章
4. 内容发布 → 将文章添加到新页面
5. 链接生成 → 生成可点击的Notion链接

🎯 使用方式:
1. 通过AI助手触发: 说"创作内容"、"请写作"等指令
2. 命令行执行: cd $WORKSPACE && ./创作内容.sh
3. 完整工作流: cd $WORKSPACE && ./content-creation-workflow.sh

📊 输出结果:
- 新Notion页面（独立页面，包含完整文章内容）
- 可点击链接（可直接分享和查看）
- 内容文件（保存生成的Markdown文章）
- 执行报告（详细的工作流执行记录）

---
*报告生成时间: $(date +"%Y-%m-%d %H:%M:%S CST")*
*技能版本: 1.0.0*
*专属用户: 峰峰（老公）*
EOF

echo "📊 安装报告已保存: $INSTALL_REPORT"

# 7. 完成安装
echo ""
echo "🎉 my writer skill 安装完成!"
echo "=============================="
echo ""
echo "📋 技能信息:"
echo "   名称: my writer skill"
echo "   版本: 1.0.0"
echo "   用户: 峰峰（老公）"
echo "   创建者: 璐璐（OpenClaw AI助手）"
echo ""
echo "🚀 使用方法:"
echo "   1. 通过AI助手触发: 说'创作内容'、'请写作'等指令"
echo "   2. 命令行执行: cd $WORKSPACE && ./创作内容.sh"
echo "   3. 完整工作流: cd $WORKSPACE && ./content-creation-workflow.sh"
echo ""
echo "📊 输出目录:"
echo "   内容文件: $WORKSPACE/content-articles/"
echo "   报告文件: $WORKSPACE/content-reports/"
echo "   日志文件: $WORKSPACE/logs/my-writer-skill/"
echo ""
echo "🔧 配置检查:"
echo "   Notion Token: 已配置"
echo "   Notion父页面: 2d44df84ce44807c8dc0dd184c9bf3c7"
echo "   Content Agent选题: 自动读取今日选题"
echo ""
echo "✅ 安装完成，技能已就绪！"