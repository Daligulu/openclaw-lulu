/**
 * Shared types for ePro memory plugin.
 *
 * 6-category classification from OpenViking:
 * - UserMemory: profile, preferences, entities, events
 * - AgentMemory: cases, patterns
 */
export const MEMORY_CATEGORIES = [
    "profile",
    "preferences",
    "entities",
    "events",
    "cases",
    "patterns",
];
/** Categories that always merge (skip dedup). */
export const ALWAYS_MERGE_CATEGORIES = new Set(["profile"]);
/** Categories that support MERGE decision from LLM dedup. */
export const MERGE_SUPPORTED_CATEGORIES = new Set([
    "preferences",
    "entities",
    "patterns",
]);
//# sourceMappingURL=types.js.map