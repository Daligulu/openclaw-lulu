#!/bin/bash
# 检查已绑定节点的状态

echo "🔍 检查EvoMap已绑定节点状态"
echo "========================================"
echo ""

# 尝试多个可能的节点ID
NODE_IDS=(
    "node_d0cf2a3b4b3946a492a8e72e381e1198"
    "node_d0cf2a3b4b3946a492a8e72e381e1198"
    "node_d0cf2a3b4b3946a492a8e72e381e1198"
)

for NODE_ID in "${NODE_IDS[@]}"; do
    echo "📡 测试节点ID: $NODE_ID"
    
    RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
        -H "Content-Type: application/json" \
        -d '{
            "protocol": "gep-a2a",
            "protocol_version": "1.0.0",
            "message_type": "hello",
            "message_id": "msg_'"$(date +%s%N)"'_'"$(shuf -i 100000-999999 -n 1)"'",
            "sender_id": "'"$NODE_ID"'",
            "timestamp": "'"$(date -u +"%Y-%m-%dT%H:%M:%SZ")"'",
            "payload": {
                "capabilities": {},
                "env_fingerprint": { "platform": "linux", "arch": "x64" }
            }
        }')
    
    STATUS=$(echo "$RESPONSE" | jq -r '.payload.status // "unknown"')
    CREDITS=$(echo "$RESPONSE" | jq -r '.payload.credit_balance // 0')
    CLAIM_CODE=$(echo "$RESPONSE" | jq -r '.payload.claim_code // "null"')
    YOUR_NODE_ID=$(echo "$RESPONSE" | jq -r '.payload.your_node_id // "unknown"')
    
    echo "  状态: $STATUS"
    echo "  积分: $CREDITS"
    echo "  认领码: $CLAIM_CODE"
    echo "  返回的节点ID: $YOUR_NODE_ID"
    
    if [ "$STATUS" = "acknowledged" ] && [ "$CLAIM_CODE" = "null" ]; then
        echo "  ✅ 这个节点可能已被绑定到账户"
    fi
    
    if [ "$STATUS" = "rejected" ]; then
        REASON=$(echo "$RESPONSE" | jq -r '.payload.reason // "unknown"')
        echo "  ❌ 被拒绝: $REASON"
    fi
    
    echo ""
done

echo "📋 分析结果:"
echo "1. 如果节点状态是 'acknowledged' 且认领码为 'null'，说明节点已被绑定"
echo "2. 如果节点状态是 'rejected' 且原因是 'node_id_already_claimed'，说明节点已被其他用户占用"
echo "3. 积分为0可能是正常情况，需要登录EvoMap Web客户端查看实际余额"
echo ""
echo "🎯 建议操作:"
echo "1. 登录EvoMap Web客户端: https://evomap.ai"
echo "2. 使用账户: gaojunfeng1108@gmail.com"
echo "3. 在 'My Nodes' 中查看已绑定的节点"
echo "4. 查看实际积分余额和节点状态"