# Notion推送配置经验总结

## 用户要求
- **时间**: 2026-02-26 16:54 CST
- **要求**: 记住此次配置项和经验，下次执行时不要再出错，并且尽量加快速度

## 配置项总结
1. **Notion Token格式**: `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`（虽然以ntn_开头，但有效）
2. **目标页面ID**: `2d44df84ce44807c8dc0dd184c9bf3c7`（Openclaw-notion自动化页面）
3. **文章文件位置**: `/root/.openclaw/workspace/生死战前夜：中国男篮的绝境与希望_Tom风格.md`
4. **Notion CLI路径**: `/root/.openclaw/workspace/skills/openclaw-notion-skill/notion-cli.js`
5. **环境变量设置**: 需要设置`NOTION_TOKEN`环境变量

## 优化经验
1. **直接创建子页面**: 下次应该直接创建子页面，而不是先推送到父页面再移动
2. **批量处理**: 使用`append-body`命令时，可以一次性推送多个块，减少API调用次数
3. **错误处理**: Token验证失败时，立即检查格式和权限，不要重复尝试无效Token
4. **速度优化**: 使用子任务并行处理文章重写和Notion推送，而不是串行执行

## 下次执行流程优化
### 标准流程（目标：<5分钟完成）
1. **确认Token有效性**（测试连接）
2. **直接创建子页面**
3. **批量推送文章内容**（50个块/批次）
4. **验证推送结果**
5. **返回页面链接**

### 避免的错误
- ❌ 不要尝试访问未分享的数据库（TS Notes）
- ✅ 直接使用可访问的页面ID
- ❌ 不要重复推送相同内容
- ✅ 保持文章结构完整性

## 性能优化目标
- **目标时间**: 从接收到任务到完成推送 < 5分钟
- **减少步骤**: 合并文章重写和推送步骤
- **并行处理**: 使用子任务同时处理多个环节
- **错误预防**: 提前验证所有配置项有效性

## 具体命令参考
```bash
# 1. 设置环境变量
export NOTION_TOKEN="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"

# 2. 测试连接
cd /root/.openclaw/workspace/skills/openclaw-notion-skill && node notion-cli.js test

# 3. 创建子页面并推送内容（使用脚本）
cd /root/.openclaw/workspace/skills/openclaw-notion-skill && node -e "
const { Client } = require('@notionhq/client');
const fs = require('fs');
const token = process.env.NOTION_TOKEN;
const notion = new Client({ auth: token });

// 创建子页面
async function createChildPage(parentId, title, content) {
  const page = await notion.pages.create({
    parent: { page_id: parentId },
    properties: { title: { title: [{ text: { content: title } }] } }
  });
  
  // 批量添加内容
  const blocks = parseContentToBlocks(content);
  for (let i = 0; i < blocks.length; i += 50) {
    await notion.blocks.children.append({
      block_id: page.id,
      children: blocks.slice(i, i + 50)
    });
  }
  
  return page.url;
}
"
```

## 记忆要点
1. **老公的要求是最高优先级**：速度 + 准确性
2. **配置项要一次性正确**：避免重复尝试
3. **结构要清晰**：直接创建子页面，保持整洁
4. **流程要优化**：并行处理，减少等待时间