# epro-memory DeepSeek 配置指南

## 概述
由于 DeepSeek 不支持嵌入 API，本指南提供了使用 DeepSeek API 运行 epro-memory 的解决方案。

## 解决方案
使用伪嵌入（pseudo-embeddings）替代真实的向量嵌入。虽然精度不如专业嵌入模型，但可以正常工作。

## 安装步骤

### 1. 编译修改后的代码
```bash
cd /root/.openclaw/workspace/epro-memory

# 编译 DeepSeek 专用版本
npx tsc embeddings-deepseek.ts --outDir dist --module esnext --target es2022 --declaration --sourceMap --moduleResolution node
npx tsc extractor-deepseek.ts --outDir dist --module esnext --target es2022 --declaration --sourceMap --moduleResolution node
npx tsc index-deepseek.ts --outDir dist --module esnext --target es2022 --declaration --sourceMap --moduleResolution node
```

### 2. 创建 DeepSeek 配置文件
创建 `deepseek-config.json`：
```json
{
  "embedding": {
    "apiKey": "sk-60a64d923ab54478a5f43d4136280b52",
    "model": "deepseek-chat",
    "baseUrl": "https://api.deepseek.com/v1"
  },
  "llm": {
    "apiKey": "sk-60a64d923ab54478a5f43d4136280b52",
    "model": "deepseek-chat",
    "baseUrl": "https://api.deepseek.com/v1"
  },
  "dbPath": "~/.clawdbot/memory/epro-lancedb",
  "autoCapture": true,
  "autoRecall": true,
  "recallLimit": 5,
  "recallMinScore": 0.3,
  "extractMinMessages": 4,
  "extractMaxChars": 8000
}
```

### 3. 集成到 OpenClaw

#### 方法 A：作为独立插件
1. 将编译后的文件复制到 OpenClaw 的 extensions 目录
2. 在 OpenClaw 配置中添加：
```json
{
  "plugins": {
    "epro-memory-deepseek": {
      "embedding": {
        "apiKey": "sk-60a64d923ab54478a5f43d4136280b52",
        "model": "deepseek-chat",
        "baseUrl": "https://api.deepseek.com/v1"
      },
      "llm": {
        "apiKey": "sk-60a64d923ab54478a5f43d4136280b52",
        "model": "deepseek-chat",
        "baseUrl": "https://api.deepseek.com/v1"
      }
    }
  }
}
```

#### 方法 B：直接使用 API
```javascript
import { DeepSeekEmbeddings } from './embeddings-deepseek.js';
import { MemoryExtractorDeepSeek } from './extractor-deepseek.js';
import { MemoryDB } from './db.js';
import { LlmClient } from './llm.js';
import { MemoryDeduplicator } from './deduplicator.js';

// 初始化服务
const embeddings = new DeepSeekEmbeddings(
  'sk-60a64d923ab54478a5f43d4136280b52',
  'deepseek-chat',
  'https://api.deepseek.com/v1'
);

const llm = new LlmClient(
  'sk-60a64d923ab54478a5f43d4136280b52',
  'deepseek-chat',
  'https://api.deepseek.com/v1'
);

const db = new MemoryDB('~/.clawdbot/memory/epro-lancedb', 384);
const deduplicator = new MemoryDeduplicator(db, llm);
const extractor = new MemoryExtractorDeepSeek(db, embeddings, llm, deduplicator);

// 使用提取器
const conversation = "用户：我喜欢篮球和AI技术\n助手：好的，我会记住你的兴趣";
const stats = await extractor.extractAndPersist(conversation, 'session-123', 'user');
console.log(`提取结果：创建 ${stats.created}，合并 ${stats.merged}，跳过 ${stats.skipped}`);
```

## 技术细节

### 伪嵌入工作原理
1. **文本哈希**：使用文本内容生成确定性哈希
2. **向量生成**：将哈希映射到 384 维向量空间
3. **归一化**：确保向量长度一致
4. **相似性计算**：使用余弦相似度进行向量搜索

### 局限性
1. **精度有限**：伪嵌入不如专业嵌入模型准确
2. **语义理解有限**：基于文本哈希，不是真正的语义理解
3. **性能影响**：相似性搜索可能不如专业嵌入高效

### 改进建议
1. **本地嵌入模型**：安装 sentence-transformers 等本地模型
2. **混合方案**：使用免费嵌入服务（如 Jina AI）结合 DeepSeek
3. **缓存优化**：缓存常见文本的嵌入结果

## 测试验证

### 1. 测试 DeepSeek API 连接
```bash
curl -X POST \
  -H "Authorization: Bearer sk-60a64d923ab54478a5f43d4136280b52" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"Hello"}]}' \
  https://api.deepseek.com/v1/chat/completions
```

### 2. 测试伪嵌入
```javascript
const embeddings = new DeepSeekEmbeddings('sk-...', 'deepseek-chat');
const vector = await embeddings.embed("测试文本");
console.log(`向量维度：${vector.length}，示例值：${vector.slice(0, 5)}`);
```

## 故障排除

### 常见问题
1. **API 连接失败**：检查 API Key 和网络连接
2. **向量维度不匹配**：确保使用 384 维向量
3. **内存不足**：LanceDB 需要足够磁盘空间

### 日志查看
```bash
# 查看 OpenClaw 日志
tail -f /root/.openclaw/logs/openclaw.log | grep epro-memory
```

## 性能优化
1. **批量处理**：积累一定量对话后批量提取
2. **缓存嵌入**：缓存常见文本的嵌入结果
3. **定期清理**：清理旧的或不重要的记忆

## 安全注意事项
1. **保护 API Key**：不要将 API Key 提交到版本控制
2. **数据加密**：敏感记忆内容可考虑加密存储
3. **访问控制**：限制记忆数据库的访问权限