const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = new Date().toISOString();

// 更新知识检查信息
state.knowledgeCheck = state.knowledgeCheck || {};
state.knowledgeCheck.lastCheckTime = new Date().toISOString();
state.knowledgeCheck.nextCheckType = 'optimization'; // 根据脚本输出
state.knowledgeCheck.checkResult = '模型检查完成，检查大模型最新进展';
state.knowledgeCheck.nextCheckIn = '约6小时后';

// 更新当前任务
state.currentTasks = [
  "Tech-News-Digest下次运行09:00",
  "Content Agent每日选题已生成（07:34）",
  "每日记忆整理已完成（08:00）",
  "OpenClaw备份已完成（07:00）",
  "EvoMap同步已完成（17:57）",
  "知识技能检查完成（models类型）"
];

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
