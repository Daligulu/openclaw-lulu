#!/bin/bash
# x-tweet - 获取 X/Twitter 推文内容
# 使用 fxtwitter API，无需 API Key

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印帮助信息
print_help() {
    echo -e "${BLUE}════════════════════════════════════════${NC}"
    echo -e "${BLUE}  x-tweet - X/Twitter 推文获取工具${NC}"
    echo -e "${BLUE}════════════════════════════════════════${NC}"
    echo ""
    echo "用法：$0 <X 推文链接>"
    echo ""
    echo "示例:"
    echo "  $0 https://x.com/username/status/123456789"
    echo "  $0 https://twitter.com/username/status/123456789"
    echo ""
    echo "选项:"
    echo "  -h, --help      显示帮助信息"
    echo "  -z, --zh        获取中文翻译（如果可用）"
    echo "  -r, --raw       显示原始 JSON"
    echo ""
}

# 从 URL 提取 username 和 tweet_id
extract_tweet_info() {
    local url="$1"
    
    # 支持 x.com 和 twitter.com
    local pattern="(https?://)?(www\.)?(x\.com|twitter\.com)/([a-zA-Z0-9_]+)/status/([0-9]+)"
    
    if [[ $url =~ $pattern ]]; then
        USERNAME="${BASH_REMATCH[4]}"
        TWEET_ID="${BASH_REMATCH[5]}"
        return 0
    else
        return 1
    fi
}

# 获取推文数据
fetch_tweet() {
    local username="$1"
    local tweet_id="$2"
    local translate="$3"
    
    local api_url
    if [[ "$translate" == "zh" ]]; then
        api_url="https://api.fxtwitter.com/${username}/status/${tweet_id}/zh"
    else
        api_url="https://api.fxtwitter.com/${username}/status/${tweet_id}"
    fi
    
    # 调用 API
    local response
    response=$(curl -s "$api_url")
    
    # 检查响应
    if echo "$response" | jq -e '.error' > /dev/null 2>&1; then
        local error_msg
        error_msg=$(echo "$response" | jq -r '.error.message')
        echo -e "${RED}❌ 错误：${error_msg}${NC}"
        return 1
    fi
    
    echo "$response"
}

# 格式化输出推文信息
format_output() {
    local json="$1"
    
    # 提取字段
    local author_name=$(echo "$json" | jq -r '.tweet.author.name // "未知"')
    local author_screen=$(echo "$json" | jq -r '.tweet.author.screen_name // "未知"')
    local author_desc=$(echo "$json" | jq -r '.tweet.author.description // ""')
    local text=$(echo "$json" | jq -r '.tweet.text // "无内容"')
    local created_at=$(echo "$json" | jq -r '.tweet.created_at // "未知时间"')
    local likes=$(echo "$json" | jq -r '.tweet.likes // 0')
    local retweets=$(echo "$json" | jq -r '.tweet.retweets // 0')
    local replies=$(echo "$json" | jq -r '.tweet.replies // 0')
    local views=$(echo "$json" | jq -r '.tweet.views // 0')
    
    # 格式化数字
    format_number() {
        local num=$1
        if [[ $num -ge 1000000 ]]; then
            echo "$(echo "scale=1; $num/1000000" | bc)M"
        elif [[ $num -ge 1000 ]]; then
            echo "$(echo "scale=1; $num/1000" | bc)K"
        else
            echo "$num"
        fi
    }
    
    local likes_fmt=$(format_number $likes)
    local retweets_fmt=$(format_number $retweets)
    local replies_fmt=$(format_number $replies)
    local views_fmt=$(format_number $views)
    
    # 输出格式化内容
    echo -e "${BLUE}════════════════════════════════════════${NC}"
    echo -e "${GREEN}${author_name}${NC} @${author_screen}"
    if [[ -n "$author_desc" && "$author_desc" != "null" ]]; then
        echo -e "${YELLOW}简介：${author_desc}${NC}"
    fi
    echo -e "${BLUE}📅 ${created_at}${NC}"
    echo -e "${BLUE}════════════════════════════════════════${NC}"
    echo ""
    echo -e "${NC}> ${text}${NC}"
    echo ""
    echo -e "${BLUE}互动：${NC}❤️ ${likes_fmt} · 🔁 ${retweets_fmt} · 💬 ${replies_fmt} · 👁️ ${views_fmt}"
    echo -e "${BLUE}════════════════════════════════════════${NC}"
}

# 主函数
main() {
    local url=""
    local translate=""
    local raw=false
    
    # 解析参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                print_help
                exit 0
                ;;
            -z|--zh)
                translate="zh"
                shift
                ;;
            -r|--raw)
                raw=true
                shift
                ;;
            *)
                if [[ -z "$url" ]]; then
                    url="$1"
                else
                    echo -e "${RED}❌ 未知参数：$1${NC}"
                    print_help
                    exit 1
                fi
                shift
                ;;
        esac
    done
    
    # 检查 URL
    if [[ -z "$url" ]]; then
        echo -e "${RED}❌ 请提供 X 推文链接${NC}"
        print_help
        exit 1
    fi
    
    # 提取信息
    if ! extract_tweet_info "$url"; then
        echo -e "${RED}❌ 无效的 X 推文链接${NC}"
        echo "请确保链接格式为：https://x.com/username/status/tweet_id"
        exit 1
    fi
    
    echo -e "${BLUE}🔍 正在获取推文...${NC}"
    echo -e "   作者：@${USERNAME}"
    echo -e "   ID: ${TWEET_ID}"
    if [[ "$translate" == "zh" ]]; then
        echo -e "   翻译：中文"
    fi
    echo ""
    
    # 获取推文
    local response
    if ! response=$(fetch_tweet "$USERNAME" "$TWEET_ID" "$translate"); then
        exit 1
    fi
    
    # 输出结果
    if [[ "$raw" == true ]]; then
        echo "$response" | jq '.'
    else
        format_output "$response"
    fi
}

# 执行主函数
main "$@"
