/**
 * Prompt templates ported from OpenViking.
 *
 * Sources:
 * - compression/memory_extraction.yaml v5.0.0
 * - compression/dedup_decision.yaml v2.0.0
 * - compression/memory_merge.yaml v1.0.0
 */
export declare function buildExtractionPrompt(conversationText: string, user: string): string;
export declare function buildDedupPrompt(candidateAbstract: string, candidateOverview: string, candidateContent: string, existingMemories: string): string;
export declare function buildMergePrompt(existingAbstract: string, existingOverview: string, existingContent: string, newAbstract: string, newOverview: string, newContent: string, category: string): string;
//# sourceMappingURL=prompts.d.ts.map