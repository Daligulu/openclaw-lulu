# [cases] GitHub技能安装和使用

## L0: 摘要
从ClawHub安装GitHub技能，使用gh CLI与GitHub交互

## L1: 概述
- **问题描述**: 需要GitHub集成功能进行仓库管理和CI监控
- **问题类型**: 技能安装和配置
- **解决状态**: 已解决
- **解决方案**: 从ClawHub安装steipete/github技能，配置gh CLI
- **解决时间**: 2026-02-25 16:35
- **效果评估**: 好

## L2: 详细内容
### 问题背景
用户分享ClawHub技能链接 `https://clawhub.ai/steipete/github`，需要安装和使用GitHub集成功能。

### 解决过程
1. **发现技能**: 通过ClawHub搜索找到"Github"技能（steipete/github）
2. **技能信息**: 
   - 名称: github
   - 所有者: steipete
   - 版本: 1.0.0
   - 描述: 使用gh CLI与GitHub交互，支持issue、PR、CI运行和高级API查询
3. **安装过程**:
   ```bash
   clawhub install github
   ```
   - 安装位置: `/root/.openclaw/workspace/skills/github/`
   - 包含文件: SKILL.md（技能文档）、_meta.json（元数据）
4. **环境检查**:
   - gh CLI已安装: `/usr/bin/gh` (v2.87.3)
   - 需要GitHub认证: 运行 `gh auth login`

### 技能功能
#### 核心命令
1. **PR管理**: `gh pr checks <pr-number> --repo owner/repo`
2. **CI监控**: `gh run list --repo owner/repo --limit 10`
3. **Issue管理**: `gh issue list --repo owner/repo --json number,title`
4. **API查询**: `gh api repos/owner/repo/pulls/55 --jq '.title, .state'`

#### JSON输出支持
```bash
# 结构化输出
gh issue list --repo owner/repo --json number,title,state --jq '.[] | "\(.number): \(.title) (\(.state))"'
```

### 根本原因分析
- **直接原因**: 需要GitHub自动化管理功能
- **根本原因**: 内容创作和技术项目需要GitHub集成
- **系统性因素**: ClawHub技能生态系统提供标准化集成方案

## 元数据
- **创建时间**: 2026-02-25 16:36
- **解决时间**: 2026-02-25 16:35
- **复杂度**: 低
- **可复用性**: 高（标准技能安装流程）
- **相关技术**: ClawHub, GitHub CLI, API集成
- **来源**: ClawHub技能链接分享

## 知识沉淀
### 最佳实践
1. **技能发现**: 使用 `clawhub search <关键词>` 查找相关技能
2. **技能检查**: 使用 `clawhub inspect <slug>` 查看技能详情
3. **技能安装**: 使用 `clawhub install <slug>` 安装技能
4. **技能测试**: 创建测试脚本验证功能

### 避免的陷阱
1. 确保gh CLI已安装并配置认证
2. 指定 `--repo owner/repo` 参数当不在git目录中
3. 使用 `--json` 参数获取结构化输出
4. 利用 `--jq` 进行数据过滤和格式化

### 快速参考
```bash
# 安装GitHub技能
clawhub install github

# 配置GitHub认证
gh auth login

# 查看仓库信息
gh repo view openclaw/openclaw --json name,description,stargazersCount

# 监控CI状态
gh run list --repo openclaw/openclaw --limit 5 --json conclusion,status,workflowName
```

## 相关技能
- **agent-reach**: 提供GitHub仓库读取功能
- **tech-news-digest**: 使用GitHub releases作为数据源
- **find-skills**: 帮助发现和安装新技能

## 应用场景
1. **内容创作**: 监控GitHub趋势和热门项目
2. **技术监控**: 跟踪开源项目更新和CI状态
3. **项目管理**: 管理issue和PR工作流
4. **自动化**: 集成到内容创作和发布流程

## 更新记录
- 2026-02-25: 初始创建，记录技能安装和使用方法