/**
 * Memory extraction orchestrator for DeepSeek.
 * Modified to work with DeepSeekEmbeddings.
 *
 * Pipeline: extract candidates -> dedup -> persist to LanceDB.
 * Ported from OpenViking's compressor.py.
 *
 * P2-002: Added checkpoint support for resumable extraction.
 */
import type { MemoryDB } from "./db.js";
import type { MemoryDeduplicator } from "./deduplicator.js";
import type { DeepSeekEmbeddings } from "./embeddings-deepseek.js";
import type { LlmClient } from "./llm.js";
import { type ExtractionStats, type PluginLogger } from "./types.js";
import type { CheckpointManager } from "./checkpoint.js";
export declare class MemoryExtractorDeepSeek {
    private db;
    private embeddings;
    private llm;
    private deduplicator;
    private logger;
    constructor(db: MemoryDB, embeddings: DeepSeekEmbeddings, llm: LlmClient, deduplicator: MemoryDeduplicator, logger: PluginLogger);
    /**
     * Extract memories from conversation text and persist to LanceDB.
     * Main entry point for non-checkpoint extraction.
     */
    extractAndPersist(conversationText: string, sessionKey: string, user: string): Promise<ExtractionStats>;
    /**
     * Extract with checkpoint support (P2-002).
     * Saves progress after each candidate to allow crash recovery.
     */
    extractWithCheckpoint(conversationText: string, sessionKey: string, user: string, checkpointMgr: CheckpointManager): Promise<ExtractionStats>;
    /**
     * Resume incomplete extraction from checkpoint (P2-002).
     */
    resumeIncomplete(checkpointMgr: CheckpointManager): Promise<ExtractionStats[]>;
    /**
     * Extract candidate memories from conversation text using LLM.
     */
    private extractCandidates;
    /**
     * Process a batch of candidates through dedup pipeline.
     */
    private processCandidates;
    /**
     * Process a single candidate through the dedup pipeline.
     */
    private processSingleCandidate;
    /**
     * Create a new memory in LanceDB.
     */
    private createMemory;
    /**
     * Merge candidate into existing profile memory.
     */
    private mergeProfile;
    /**
     * Merge candidate into existing memory (non-profile).
     */
    private mergeMemory;
}
//# sourceMappingURL=extractor-deepseek.d.ts.map