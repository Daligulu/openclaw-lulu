/**
 * Memory deduplicator.
 * Two-stage pipeline: vector pre-filter -> LLM decision (CREATE/MERGE/SKIP).
 * Ported from OpenViking's memory_deduplicator.py.
 */
import type { MemoryDB } from "./db.js";
import type { LlmClient } from "./llm.js";
import type { CandidateMemory, DedupResult, PluginLogger } from "./types.js";
export declare class MemoryDeduplicator {
    private db;
    private llm;
    private logger;
    constructor(db: MemoryDB, llm: LlmClient, logger: PluginLogger);
    deduplicate(candidate: CandidateMemory, candidateVector: number[]): Promise<DedupResult>;
    private llmDecision;
}
//# sourceMappingURL=deduplicator.d.ts.map