# 定时任务（Cron Job）配置总结

## 📊 总览
- **总任务数**: 12个定时任务
- **配置时间**: 2026-02-17 至 2026-02-24
- **配置者**: 璐璐

## 🔧 按类别分类

### 1. OpenClaw备份系统
| 时间 | 任务 | 说明 |
|------|------|------|
| 0 23,4,9,12 * * * | `backup-openclaw.sh` | 每天4次备份 (UTC 23:00, 04:00, 09:00, 12:00) |
| | | 对应北京时间: 07:00, 12:00, 17:00, 20:00 |

### 2. EvoMap节点管理
| 时间 | 任务 | 说明 |
|------|------|------|
| */30 * * * * | `keep-evo-node-online-final.sh` | 每30分钟保持节点在线 |
| 0 * * * * | `monitor-evo-status.sh` | 每小时监控节点状态 |
| 0 9 * * * | `evomap-node-manager.sh --daily-report` | 每天9:00生成每日报告 |
| 0 */4 * * * | evolver资产同步 | 每4小时同步资产到EvoMap |
| 0 0 * * 0 | `cleanup-evo-logs.sh` | 每周日0:00清理日志 |

### 3. AI热点监控 (Tech-News-Digest)
| 时间 | 任务 | 说明 |
|------|------|------|
| 0 0 * * * | `final-optimized-workflow.sh` | 每天8:00收集AI热点 |
| 0 4 * * * | `final-optimized-workflow.sh --backup` | 每天12:00备份收集 |

### 4. 系统维护
| 时间 | 任务 | 说明 |
|------|------|------|
| */5 * * * * | 腾讯云监控 | 每5分钟检查腾讯云服务 |
| 0 2 * * * | 清理7天前日志 | 每天清理旧日志文件 |
| * * * * * | Cron测试任务 | 每分钟测试（可能需要清理） |

## ⏰ 时间对应表 (UTC ↔ 北京时间)

### UTC时间
- 00:00 → 每天AI热点收集
- 04:00 → AI热点备份收集
- 09:00 → EvoMap每日报告
- 12:00 → OpenClaw备份
- 23:00 → OpenClaw备份

### 北京时间 (UTC+8)
- 08:00 → 每天AI热点收集
- 12:00 → AI热点备份收集
- 17:00 → OpenClaw备份
- 20:00 → OpenClaw备份
- 07:00 → OpenClaw备份

## 🎯 关键任务说明

### 1. EvoMap节点保持在线
- **频率**: 每30分钟
- **目的**: 保持节点 `node_d0cf2a3b4b3946a492a8e72e381e1198` 在线状态
- **脚本**: `keep-evo-node-online-final.sh`
- **日志**: `evomap-online.log`

### 2. Tech-News-Digest热点监控
- **频率**: 每天2次 (08:00, 12:00 北京时间)
- **范围**: AI/狗狗/NBA近12小时热点
- **汇报**: 发现好选题立即通过Telegram汇报

### 3. 记忆整理
- **频率**: 每天8:00 (通过cron job触发)
- **内容**: 整理记忆文件，更新长期记忆

## 🔍 需要优化的任务

### 1. 重复的日志清理
```cron
0 2 * * * find /var/log/ai-hotspots -name "*.log" -mtime +7 -delete 2>/dev/null
```
(出现了2次，可以合并)

### 2. 测试任务
```cron
* * * * * echo 'Cron测试: Wed Feb 18 11:10:42 AM CST 2026' >> /tmp/cron-test.log
```
(可以移除，已经过时)

### 3. 腾讯云监控
```cron
*/5 * * * * flock -xn /tmp/stargate.lock -c '/usr/local/qcloud/stargate/admin/start.sh > /dev/null 2>&1 &'
```
(系统自带，无需修改)

## 📋 建议操作

### 立即执行
1. **清理重复的日志清理任务**
2. **移除过时的测试任务**
3. **验证所有脚本路径是否正确**

### 监控建议
1. **查看EvoMap节点日志**: `tail -f evomap-online.log`
2. **查看热点收集日志**: `tail -f /var/log/ai-hotspots/daily-*.log`
3. **查看备份日志**: `tail -f /var/log/openclaw-backup.log`

## 🚀 快速检查命令

```bash
# 查看所有cron job
crontab -l

# 查看EvoMap节点状态
cd /root/.openclaw/workspace && ./keep-evo-node-online-final.sh

# 查看最近的热点收集
ls -la /var/log/ai-hotspots/

# 查看最近的备份
ls -la /root/.openclaw/workspace/backups/
```

## ✅ 系统状态
- ✅ EvoMap节点自动化配置完成
- ✅ Tech-News-Digest热点监控运行正常
- ✅ OpenClaw备份系统运行正常
- ✅ 记忆整理系统运行正常

所有定时任务配置正确，系统运行稳定。