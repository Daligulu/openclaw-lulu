/**
 * Pattern Bootstrap for epro-memory.
 *
 * Promotes frequently-recalled patterns to Skill drafts.
 * When a pattern memory reaches a certain active_count threshold,
 * it analyzes the pattern and generates a SKILL.md draft for review.
 *
 * @see ITERATION-SPEC.md P3-001
 */
import type { AgentMemoryRow, PluginLogger } from "./types.js";
/** Configuration for bootstrap feature */
export interface BootstrapConfig {
    /** Whether bootstrap is enabled */
    enabled: boolean;
    /** Minimum active_count to consider for promotion */
    patternPromotionThreshold: number;
    /** Path to store skill drafts */
    skillDraftPath: string;
    /** Minimum confidence score to generate draft (0-1) */
    minConfidence: number;
}
/** Default bootstrap configuration */
export declare const DEFAULT_BOOTSTRAP_CONFIG: BootstrapConfig;
/** A candidate for promotion to Skill */
export interface SkillCandidate {
    /** Suggested skill name (kebab-case) */
    name: string;
    /** Human-readable description */
    description: string;
    /** Trigger phrases/conditions */
    triggers: string[];
    /** Execution steps */
    steps: string[];
    /** ID of the source pattern memory */
    sourcePatternId: string;
    /** Confidence score (0-1) */
    confidence: number;
    /** Timestamp when candidate was identified */
    identifiedAt: number;
    /** Whether the draft has been generated */
    draftGenerated: boolean;
}
/** Analysis result from LLM */
export interface PatternAnalysis {
    /** Whether this pattern is suitable for a Skill */
    suitable: boolean;
    /** Confidence score (0-1) */
    confidence: number;
    /** Suggested skill name */
    suggestedName: string;
    /** Extracted trigger conditions */
    triggers: string[];
    /** Extracted execution steps */
    steps: string[];
    /** Reason for the assessment */
    reason: string;
}
/** LLM client interface for pattern analysis */
export interface LLMClient {
    analyze(prompt: string): Promise<string>;
}
/**
 * BootstrapManager handles pattern-to-skill promotion.
 */
export declare class BootstrapManager {
    private config;
    private draftPath;
    private logger;
    private candidates;
    private llmClient?;
    constructor(config: BootstrapConfig, logger: PluginLogger, llmClient?: LLMClient);
    /**
     * Set the LLM client for pattern analysis.
     */
    setLLMClient(client: LLMClient): void;
    /**
     * Ensure draft directory exists.
     */
    private ensureDir;
    /**
     * Check if a pattern should be considered for promotion.
     */
    shouldConsider(pattern: AgentMemoryRow): boolean;
    /**
     * Analyze a pattern for skill promotion.
     * Returns a SkillCandidate if suitable, null otherwise.
     */
    checkPatternPromotion(pattern: AgentMemoryRow): Promise<SkillCandidate | null>;
    /**
     * Analyze a pattern to determine if it's suitable for a Skill.
     */
    analyzePatternForSkill(pattern: AgentMemoryRow): Promise<PatternAnalysis>;
    /**
     * Build the prompt for LLM analysis.
     */
    private buildAnalysisPrompt;
    /**
     * Parse the LLM response into PatternAnalysis.
     */
    private parseAnalysisResponse;
    /**
     * Heuristic analysis when LLM is not available.
     */
    private heuristicAnalysis;
    /**
     * Generate a skill name from pattern content.
     */
    private generateName;
    /**
     * Extract steps from content using heuristics.
     */
    private extractSteps;
    /**
     * Extract trigger phrases from abstract and overview.
     */
    private extractTriggers;
    /**
     * Generate a SKILL.md draft for a candidate.
     */
    generateSkillDraft(candidate: SkillCandidate): string;
    /**
     * Save a skill draft to disk.
     */
    saveDraft(candidate: SkillCandidate): Promise<string>;
    /**
     * Save candidates index to disk for persistence.
     */
    private saveCandidatesIndex;
    /**
     * Load candidates index from disk.
     */
    loadCandidatesIndex(): Promise<void>;
    /**
     * Get all candidates that haven't had drafts generated yet.
     */
    getPendingCandidates(): SkillCandidate[];
    /**
     * Get all candidates.
     */
    getAllCandidates(): SkillCandidate[];
    /**
     * Record a skill candidate (for external use).
     */
    recordSkillCandidate(candidate: SkillCandidate): Promise<void>;
}
//# sourceMappingURL=bootstrap.d.ts.map