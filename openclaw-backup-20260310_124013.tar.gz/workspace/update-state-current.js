const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新当前任务
state.currentTasks = [
  "每日记忆整理完成（08:00）",
  "Content Agent每日选题执行完成（07:30，耗时23.24秒）",
  "OpenClaw备份完成（07:00），+100KB（+1%），Telegram消息ID: 2546",
  "Tech-News-Digest下次运行09:00（当前时间）",
  "EvoMap同步完成（22:57），下次同步01:58"
];

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
