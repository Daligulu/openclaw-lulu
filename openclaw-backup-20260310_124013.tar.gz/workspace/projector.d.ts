/**
 * QMD Projection for epro-memory.
 *
 * Generates human-readable markdown files from agent memories:
 * - Per-category files with L0 + L1 content
 * - Daily summaries with statistics
 *
 * @see ITERATION-SPEC.md P1-002
 */
import type { AgentMemoryRow, MemoryCategory, PluginLogger } from "./types.js";
export interface ProjectionConfig {
    enabled: boolean;
    qmdPath: string;
    includeL1: boolean;
    categorySeparateFiles: boolean;
    dailyTrigger: boolean;
}
export declare const DEFAULT_PROJECTION_CONFIG: ProjectionConfig;
/**
 * Get the timestamp of the last projection.
 */
export declare function getLastProjectionTime(qmdPath: string): Promise<number>;
/**
 * Set the timestamp of the last projection.
 */
export declare function setLastProjectionTime(qmdPath: string, timestamp: number): Promise<void>;
/**
 * Format memories for a category as markdown.
 * Outputs L0 (abstract) and optionally L1 (overview), never L2 (content).
 */
export declare function formatCategoryMarkdown(category: MemoryCategory, memories: AgentMemoryRow[], includeL1: boolean): string;
/**
 * Generate a daily summary of all memories.
 * Includes statistics and highlights.
 */
export declare function generateDailySummary(memories: AgentMemoryRow[]): string;
export interface ProjectionResult {
    categoryFilesWritten: number;
    summaryWritten: boolean;
    totalMemories: number;
}
/**
 * Project all memories to QMD format.
 *
 * Creates:
 * - Per-category markdown files in `{qmdPath}/by-category/`
 * - Daily summary in `{qmdPath}/summaries/`
 */
export declare function projectToQMD(memories: AgentMemoryRow[], config: ProjectionConfig, qmdPath: string, logger: PluginLogger): Promise<ProjectionResult>;
/**
 * Check if projection should run based on daily trigger logic.
 * Returns true if more than 24 hours have passed since last projection.
 */
export declare function shouldRunProjection(lastProjection: number, now?: number): boolean;
//# sourceMappingURL=projector.d.ts.map