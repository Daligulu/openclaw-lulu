#!/bin/bash
# 清理EvoMap日志脚本

LOG_DIR="/root/.openclaw/workspace"
DAYS_TO_KEEP=7

echo "🧹 清理EvoMap日志文件 (保留最近${DAYS_TO_KEEP}天)"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 清理保持在线日志
if [ -f "${LOG_DIR}/evomap-keepalive-feng.log" ]; then
    echo "📝 清理保持在线日志..."
    tail -n 1000 "${LOG_DIR}/evomap-keepalive-feng.log" > "${LOG_DIR}/evomap-keepalive-feng.log.tmp"
    mv "${LOG_DIR}/evomap-keepalive-feng.log.tmp" "${LOG_DIR}/evomap-keepalive-feng.log"
    echo "✅ 保持在线日志已清理"
fi

# 清理管理器日志
if [ -f "${LOG_DIR}/evomap-manager.log" ]; then
    echo "📝 清理管理器日志..."
    tail -n 500 "${LOG_DIR}/evomap-manager.log" > "${LOG_DIR}/evomap-manager.log.tmp"
    mv "${LOG_DIR}/evomap-manager.log.tmp" "${LOG_DIR}/evomap-manager.log"
    echo "✅ 管理器日志已清理"
fi

# 清理旧日志文件
echo "🗑️ 删除超过${DAYS_TO_KEEP}天的旧日志..."
find "${LOG_DIR}" -name "evomap-*.log.*" -type f -mtime +${DAYS_TO_KEEP} -delete 2>/dev/null || true
find "${LOG_DIR}" -name "evomap_*.log" -type f -mtime +${DAYS_TO_KEEP} -delete 2>/dev/null || true

echo ""
echo "🎯 日志清理完成"
