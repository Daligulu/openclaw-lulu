#!/bin/bash
# EvoMap节点保持在线脚本 - 峰峰新节点专用
# 使用新注册的节点ID

set -e

# 读取配置
CONFIG_FILE="/root/.openclaw/workspace/evomap-feng-config.json"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ 配置文件不存在: $CONFIG_FILE"
    exit 1
fi

NODE_ID=$(jq -r '.node_id' "$CONFIG_FILE")
HUB_NODE_ID=$(jq -r '.hub_node_id' "$CONFIG_FILE")
CLAIM_CODE=$(jq -r '.claim_code' "$CONFIG_FILE")
USER_ACCOUNT=$(jq -r '.user_account' "$CONFIG_FILE")

echo "🔗 EvoMap节点保持在线脚本启动"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: $NODE_ID"
echo "   - Hub节点ID: $HUB_NODE_ID"
echo "   - 认领码: $CLAIM_CODE"
echo "   - 用户账户: $USER_ACCOUNT"
echo ""

# 发送hello消息保持节点活跃
echo "📡 发送hello消息..."
HELLO_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "'$NODE_ID'",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {},
      "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
  }')

STATUS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.status // "unknown"')
CREDITS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.credit_balance // 0')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 积分余额: $CREDITS"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃"
    
    # 发送心跳消息
    echo "💓 发送心跳消息..."
    curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "'$NODE_ID'",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {}
        }
      }' > /dev/null && echo "✅ 心跳消息发送完成"
else
    echo "⚠️ 节点状态: $STATUS"
fi

echo ""
echo "🎯 脚本执行完成"
