/**
 * ePro v2 — OpenClaw Agent Memory Plugin
 *
 * LLM-powered memory extraction with 6-category classification,
 * L0/L1/L2 tiered structure, and vector dedup.
 *
 * Hooks:
 * - before_agent_start: recall relevant memories, inject as <agent-experience>
 * - agent_end: extract memories from conversation, dedup, persist to LanceDB
 * - heartbeat: trigger daily QMD projection (if enabled)
 */
import { CheckpointManager, type CheckpointConfig, type ExtractionCheckpoint } from "./checkpoint.js";
import type { PluginLogger } from "./types.js";
type MoltbotPluginApi = {
    pluginConfig?: Record<string, unknown>;
    logger: PluginLogger;
    resolvePath: (input: string) => string;
    on: (hookName: string, handler: (...args: any[]) => any, opts?: {
        priority?: number;
    }) => void;
    registerService: (service: {
        id: string;
        start: () => void;
        stop?: () => void;
    }) => void;
};
declare const eproMemoryPlugin: {
    id: string;
    name: string;
    description: string;
    register(api: MoltbotPluginApi): void;
};
/**
 * Extract text from conversation messages.
 * Handles both string content and content block arrays (Anthropic API format).
 */
declare function extractConversationText(messages: unknown[], maxChars: number): string;
/**
 * Neutralize XML-like tags in stored text to prevent prompt boundary injection.
 * Only matches `<` followed by an optional `/` and a letter (i.e. actual tag syntax).
 * `</agent-experience>` becomes `< /agent-experience>`, but `5 < 10` is unchanged.
 */
export declare function sanitizeForContext(text: string): string;
export { extractConversationText, CheckpointManager };
export type { CheckpointConfig, ExtractionCheckpoint };
export default eproMemoryPlugin;
//# sourceMappingURL=index.d.ts.map