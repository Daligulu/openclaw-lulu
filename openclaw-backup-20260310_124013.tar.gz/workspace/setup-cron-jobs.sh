#!/bin/bash
# 设置AI热点定时任务

echo "⏰ 配置AI热点定时任务..."
echo ""

# 配置
WORKFLOW_SCRIPT="/root/.openclaw/workspace/scripts/daily-ai-hotspots-workflow.sh"
LOG_DIR="/var/log/ai-hotspots"
CRON_USER="root"

# 创建日志目录
mkdir -p "$LOG_DIR"
chmod 755 "$LOG_DIR"

echo "1. 检查工作流脚本..."
if [ ! -f "$WORKFLOW_SCRIPT" ]; then
    echo "❌ 工作流脚本不存在: $WORKFLOW_SCRIPT"
    exit 1
fi

chmod +x "$WORKFLOW_SCRIPT"
echo "   ✅ 脚本权限已设置"

echo ""
echo "2. 配置定时任务..."
echo "   建议运行时间:"
echo "   • 主要运行: 每天 9:00 (北京时间)"
echo "   • 备用运行: 每天 12:00 (北京时间)"
echo "   • 测试运行: 每天 18:00 (北京时间)"
echo ""

# UTC时间对应（北京时间 = UTC+8）
# 北京时间 9:00 = UTC 1:00
# 北京时间 12:00 = UTC 4:00  
# 北京时间 18:00 = UTC 10:00

CRON_JOBS=(
    "0 1 * * * $WORKFLOW_SCRIPT >> $LOG_DIR/daily-$(date +%Y%m%d).log 2>&1  # 每天9:00"
    "0 4 * * * $WORKFLOW_SCRIPT >> $LOG_DIR/backup-$(date +%Y%m%d).log 2>&1  # 每天12:00"
    "0 10 * * * $WORKFLOW_SCRIPT --test >> $LOG_DIR/test-$(date +%Y%m%d).log 2>&1  # 每天18:00"
)

echo "3. 添加定时任务到crontab..."
# 先移除旧的AI热点任务
TEMP_CRON=$(mktemp)
crontab -l 2>/dev/null | grep -v "daily-ai-hotspots-workflow" | grep -v "AI热点" > "$TEMP_CRON"

# 添加新任务
echo "" >> "$TEMP_CRON"
echo "# =========================================" >> "$TEMP_CRON"
echo "# AI热点自动收集任务" >> "$TEMP_CRON"
echo "# 配置时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$TEMP_CRON"
echo "# 配置者: 璐璐" >> "$TEMP_CRON"
echo "# =========================================" >> "$TEMP_CRON"

for job in "${CRON_JOBS[@]}"; do
    echo "$job" >> "$TEMP_CRON"
done

echo "" >> "$TEMP_CRON"
echo "# 日志轮转（每天清理7天前的日志）" >> "$TEMP_CRON"
echo "0 2 * * * find $LOG_DIR -name \"*.log\" -mtime +7 -delete 2>/dev/null" >> "$TEMP_CRON"

# 应用新的crontab
crontab "$TEMP_CRON"
rm -f "$TEMP_CRON"

echo "   ✅ 定时任务已配置"
echo ""

echo "4. 验证配置..."
crontab -l | grep -A5 -B5 "AI热点"

echo ""
echo "5. 创建监控脚本..."
cat > /root/.openclaw/workspace/scripts/monitor-ai-hotspots.sh << 'EOF'
#!/bin/bash
# AI热点系统监控脚本

echo "📊 AI热点系统监控"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# 1. 检查定时任务
echo "1. 定时任务状态:"
crontab -l | grep -E "(daily-ai-hotspots|AI热点)" | while read line; do
    echo "   ✅ $line"
done
echo ""

# 2. 检查日志文件
echo "2. 日志文件状态:"
LOG_DIR="/var/log/ai-hotspots"
if [ -d "$LOG_DIR" ]; then
    echo "   日志目录: $LOG_DIR"
    LATEST_LOG=$(ls -t "$LOG_DIR"/*.log 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "   最新日志: $LATEST_LOG"
        echo "   文件大小: $(du -h "$LATEST_LOG" | cut -f1)"
        echo "   最后修改: $(stat -c %y "$LATEST_LOG" | cut -d'.' -f1)"
        
        # 检查最近运行状态
        if tail -5 "$LATEST_LOG" | grep -q "执行完成"; then
            echo "   ✅ 最近运行成功"
        else
            echo "   ⚠️  最近运行状态未知"
        fi
    else
        echo "   ⚠️  暂无日志文件"
    fi
else
    echo "   ❌ 日志目录不存在"
fi
echo ""

# 3. 检查输出文件
echo "3. 输出文件状态:"
OUTPUT_DIR="/root/.openclaw/workspace/ai-hotspots"
if [ -d "$OUTPUT_DIR" ]; then
    echo "   输出目录: $OUTPUT_DIR"
    LATEST_REPORT=$(ls -t "$OUTPUT_DIR"/daily-*.md 2>/dev/null | head -1)
    if [ -n "$LATEST_REPORT" ]; then
        echo "   最新报告: $LATEST_REPORT"
        echo "   生成时间: $(stat -c %y "$LATEST_REPORT" | cut -d'.' -f1)"
        echo "   热点数量: $(grep -c "### " "$LATEST_REPORT" 2>/dev/null || echo "0")"
    else
        echo "   ⚠️  暂无报告文件"
    fi
    
    # 检查归档
    ARCHIVE_COUNT=$(find "$OUTPUT_DIR/archive" -name "*.json.gz" 2>/dev/null | wc -l)
    echo "   归档文件: $ARCHIVE_COUNT 个"
else
    echo "   ❌ 输出目录不存在"
fi
echo ""

# 4. 检查技能状态
echo "4. 技能状态:"
SKILL_DIR="/root/.openclaw/workspace/skills/tech-news-digest"
if [ -d "$SKILL_DIR" ]; then
    echo "   技能目录: $SKILL_DIR"
    if [ -f "$SKILL_DIR/SKILL.md" ]; then
        VERSION=$(grep "version:" "$SKILL_DIR/SKILL.md" | head -1 | cut -d'"' -f2)
        echo "   技能版本: $VERSION"
    fi
    
    # 检查Python依赖
    if python3 -c "import feedparser; import requests; print('✅ Python依赖正常')" 2>/dev/null; then
        echo "   ✅ Python依赖正常"
    else
        echo "   ⚠️  Python依赖可能有问题"
    fi
else
    echo "   ❌ 技能未安装"
fi
echo ""

# 5. API状态
echo "5. API状态:"
if [ -n "$BRAVE_API_KEY" ]; then
    echo "   ✅ Brave API密钥已配置"
    echo "   密钥: ${BRAVE_API_KEY:0:10}..."
else
    echo "   ⚠️  Brave API密钥未设置"
fi
echo ""

# 6. 系统资源
echo "6. 系统资源:"
echo "   磁盘空间:"
df -h /root | tail -1
echo "   内存使用:"
free -h | grep Mem
echo ""

echo "📋 总结:"
echo "运行 'crontab -l' 查看定时任务"
echo "运行 'tail -f /var/log/ai-hotspots/daily-*.log' 查看实时日志"
echo "运行 'cat /root/.openclaw/workspace/ai-hotspots/daily-*.md | head -30' 查看最新热点"
EOF

chmod +x /root/.openclaw/workspace/scripts/monitor-ai-hotspots.sh

echo "   监控脚本: /root/.openclaw/workspace/scripts/monitor-ai-hotspots.sh"
echo ""

echo "6. 创建手动测试脚本..."
cat > /root/.openclaw/workspace/scripts/test-manual-run.sh << 'EOF'
#!/bin/bash
# 手动测试AI热点收集

echo "🧪 手动测试AI热点系统..."
echo ""

# 运行测试
/root/.openclaw/workspace/scripts/daily-ai-hotspots-workflow.sh

echo ""
echo "📝 测试完成"
echo "查看报告: ls -la /root/.openclaw/workspace/ai-hotspots/"
echo "查看日志: tail -20 /var/log/ai-hotspots-*.log"
EOF

chmod +x /root/.openclaw/workspace/scripts/test-manual-run.sh

echo "   测试脚本: /root/.openclaw/workspace/scripts/test-manual-run.sh"
echo ""

echo "7. 使用说明..."
cat << 'EOF'
🎯 AI热点系统使用指南:

1. 手动运行测试:
   ./test-manual-run.sh

2. 查看系统状态:
   ./monitor-ai-hotspots.sh

3. 查看定时任务:
   crontab -l

4. 查看最新热点:
   cat /root/.openclaw/workspace/ai-hotspots/daily-*.md | head -30

5. 查看运行日志:
   tail -f /var/log/ai-hotspots/daily-*.log

6. 修改配置:
   • 数据源: /root/.openclaw/workspace/configs/ai-digest-optimized/
   • 工作流: /root/.openclaw/workspace/scripts/daily-ai-hotspots-workflow.sh

⏰ 定时任务安排:
   • 主要运行: 每天 9:00 (北京时间)
   • 备用运行: 每天 12:00 (北京时间) 
   • 测试运行: 每天 18:00 (北京时间)

📁 文件位置:
   • 配置: /root/.openclaw/workspace/configs/ai-digest-optimized/
   • 脚本: /root/.openclaw/workspace/scripts/
   • 输出: /root/.openclaw/workspace/ai-hotspots/
   • 日志: /var/log/ai-hotspots/
   • 归档: /root/.openclaw/workspace/ai-hotspots/archive/
EOF

echo ""
echo "✅ AI热点定时任务配置完成"
echo "系统将在每天9:00自动运行"
echo "立即测试: ./test-manual-run.sh"