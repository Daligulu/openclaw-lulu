/**
 * DeepSeek-compatible embedding service using chat model for pseudo-embeddings.
 * Since DeepSeek doesn't support embeddings API, we use chat model to generate
 * text representations that can be used for similarity search.
 */
export declare class DeepSeekEmbeddings {
    private client;
    private model;
    constructor(apiKey: string, model: string, baseUrl?: string);
    /**
     * Generate a pseudo-embedding using DeepSeek chat model.
     * This creates a text representation that can be used for basic similarity.
     * Note: This is a workaround since DeepSeek doesn't have embeddings API.
     */
    embed(text: string): Promise<number[]>;
    /**
     * Generate a simple pseudo-embedding vector.
     * This creates a 384-dimensional vector based on text characteristics.
     * For production use, consider using a local embedding model.
     */
    private generatePseudoEmbedding;
    /**
     * Alternative: Use chat model to generate semantic summary for embedding
     * This is more accurate but slower and uses more tokens.
     */
    private generateSemanticEmbedding;
}
//# sourceMappingURL=embeddings-deepseek.d.ts.map