/**
 * Memory Reporter for epro-memory.
 *
 * Records memory changes and generates human-readable reports.
 * Supports daily summaries and notification marking for important changes.
 *
 * @see ITERATION-SPEC.md P2-001
 */
import { writeFile, readFile, mkdir, appendFile } from "fs/promises";
import { join } from "path";
/** Default reporter configuration */
export const DEFAULT_REPORTER_CONFIG = {
    enabled: false,
    logPath: "~/.clawdbot/memory/reports",
    dailySummary: true,
    notifyOnPivotal: true,
};
/**
 * MemoryReporter tracks and reports memory changes.
 */
export class MemoryReporter {
    logPath;
    logger;
    config;
    pendingNotifications = [];
    constructor(config, logger) {
        this.config = config;
        this.logPath = config.logPath.replace(/^~/, process.env.HOME || "");
        this.logger = logger;
    }
    /**
     * Ensure log directory exists.
     */
    async ensureDir() {
        await mkdir(this.logPath, { recursive: true });
    }
    /**
     * Get the log file path for a specific date.
     */
    getLogPath(date) {
        return join(this.logPath, `${date}.jsonl`);
    }
    /**
     * Get the notification queue file path.
     */
    getNotificationPath() {
        return join(this.logPath, "pending-notifications.json");
    }
    /**
     * Record a memory change report.
     * Appends to daily log file and optionally marks for notification.
     */
    async record(report) {
        if (!this.config.enabled)
            return;
        await this.ensureDir();
        // Append to daily log (JSONL format)
        const date = new Date(report.timestamp).toISOString().split("T")[0];
        const logPath = this.getLogPath(date);
        const line = JSON.stringify(report) + "\n";
        await appendFile(logPath, line, "utf-8");
        this.logger.debug?.(`epro-memory: recorded report for ${report.sessionKey} ` +
            `(+${report.changes.created}, ~${report.changes.merged}, -${report.changes.skipped})`);
        // Mark for notification if there are important changes
        if (this.config.notifyOnPivotal && this.isPivotal(report)) {
            await this.markForNotification(report);
        }
    }
    /**
     * Check if a report contains pivotal (important) changes.
     */
    isPivotal(report) {
        // Consider pivotal if:
        // - New memories were created
        // - There are highlights
        return report.changes.created > 0 || report.highlights.length > 0;
    }
    /**
     * Mark a report for notification.
     */
    async markForNotification(report) {
        const message = this.formatNotificationMessage(report);
        const notification = {
            timestamp: report.timestamp,
            sessionKey: report.sessionKey,
            message,
            sent: false,
        };
        this.pendingNotifications.push(notification);
        await this.savePendingNotifications();
        this.logger.info(`epro-memory: marked pivotal change for notification: ${report.sessionKey}`);
    }
    /**
     * Format a notification message for a report.
     */
    formatNotificationMessage(report) {
        const parts = [`📝 Memory Update (${report.sessionKey})`];
        if (report.changes.created > 0) {
            parts.push(`+${report.changes.created} new`);
        }
        if (report.changes.merged > 0) {
            parts.push(`~${report.changes.merged} merged`);
        }
        if (report.highlights.length > 0) {
            parts.push("\nHighlights:");
            report.highlights.slice(0, 3).forEach((h) => {
                parts.push(`• ${h}`);
            });
            if (report.highlights.length > 3) {
                parts.push(`... and ${report.highlights.length - 3} more`);
            }
        }
        return parts.join("\n");
    }
    /**
     * Save pending notifications to disk.
     */
    async savePendingNotifications() {
        const path = this.getNotificationPath();
        await writeFile(path, JSON.stringify(this.pendingNotifications, null, 2), "utf-8");
    }
    /**
     * Load pending notifications from disk.
     */
    async loadPendingNotifications() {
        try {
            const path = this.getNotificationPath();
            const content = await readFile(path, "utf-8");
            this.pendingNotifications = JSON.parse(content);
            return this.pendingNotifications.filter((n) => !n.sent);
        }
        catch {
            return [];
        }
    }
    /**
     * Mark notifications as sent.
     */
    async markNotificationsSent(sessionKeys) {
        const keySet = new Set(sessionKeys);
        this.pendingNotifications = this.pendingNotifications.map((n) => keySet.has(n.sessionKey) ? { ...n, sent: true } : n);
        await this.savePendingNotifications();
    }
    /**
     * Load reports for a specific date from log file.
     */
    async loadReportsForDate(date) {
        try {
            const logPath = this.getLogPath(date);
            const content = await readFile(logPath, "utf-8");
            const lines = content.trim().split("\n").filter(Boolean);
            return lines.map((line) => JSON.parse(line));
        }
        catch {
            return [];
        }
    }
    /**
     * Generate a daily summary report.
     */
    async generateDailyReport(date) {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const reports = await this.loadReportsForDate(targetDate);
        if (reports.length === 0) {
            return `## epro-memory 每日报告 - ${targetDate}\n\n今日无记忆变更。\n`;
        }
        // Aggregate statistics
        const totalCreated = reports.reduce((s, r) => s + r.changes.created, 0);
        const totalMerged = reports.reduce((s, r) => s + r.changes.merged, 0);
        const totalSkipped = reports.reduce((s, r) => s + r.changes.skipped, 0);
        // Collect all highlights
        const allHighlights = reports.flatMap((r) => r.highlights);
        // Get unique users
        const users = [...new Set(reports.map((r) => r.user))];
        return `## epro-memory 每日报�� - ${targetDate}

### 统计

- 会话数: ${reports.length}
- 新增记忆: ${totalCreated}
- 合并记忆: ${totalMerged}
- 跳过重复: ${totalSkipped}
- 用户: ${users.join(", ") || "(未知)"}

### 重要变更

${allHighlights.length > 0 ? allHighlights.map((h) => `- ${h}`).join("\n") : "(无)"}

### 会话明细

${reports
            .map((r) => `- **${new Date(r.timestamp).toLocaleTimeString("zh-CN")}** ${r.sessionKey}: ` +
            `+${r.changes.created} ~${r.changes.merged} -${r.changes.skipped}`)
            .join("\n")}

---

> 自动生成于 ${new Date().toISOString()}
`;
    }
    /**
     * Create a report from extraction stats.
     */
    createReport(sessionKey, stats, highlights, user) {
        return {
            timestamp: Date.now(),
            sessionKey,
            changes: stats,
            highlights,
            user,
        };
    }
}
//# sourceMappingURL=reporter.js.map