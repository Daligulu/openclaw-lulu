/**
 * ePro v2 — OpenClaw Agent Memory Plugin (DeepSeek Edition)
 *
 * Modified to work with DeepSeek API which doesn't support embeddings.
 * Uses pseudo-embeddings for vector search.
 *
 * LLM-powered memory extraction with 6-category classification,
 * L0/L1/L2 tiered structure, and vector dedup.
 */
import { parseConfig, DEFAULTS } from "./config.js";
import { MemoryDB } from "./db.js";
import { DeepSeekEmbeddings } from "./embeddings-deepseek.js";
import { LlmClient } from "./llm.js";
import { MemoryDeduplicator } from "./deduplicator.js";
import { MemoryExtractor } from "./extractor.js";
import { projectToQMD, getLastProjectionTime, setLastProjectionTime, shouldRunProjection, } from "./projector.js";
import { CheckpointManager, } from "./checkpoint.js";
const eproMemoryPlugin = {
    id: "epro-memory-deepseek",
    name: "ePro Memory (DeepSeek)",
    description: "LLM-powered agent memory with DeepSeek API support (pseudo-embeddings)",
    register(api) {
        const cfg = parseConfig(api.pluginConfig ?? {});
        const logger = api.logger;
        // Resolve config with defaults
        const embeddingModel = cfg.embedding.model ?? DEFAULTS.embeddingModel;
        const llmModel = cfg.llm.model ?? DEFAULTS.llmModel;
        const dbPath = api.resolvePath(cfg.dbPath ?? DEFAULTS.dbPath);
        const autoCapture = cfg.autoCapture ?? DEFAULTS.autoCapture;
        const autoRecall = cfg.autoRecall ?? DEFAULTS.autoRecall;
        const recallLimit = cfg.recallLimit ?? DEFAULTS.recallLimit;
        const recallMinScore = cfg.recallMinScore ?? DEFAULTS.recallMinScore;
        const extractMinMessages = cfg.extractMinMessages ?? DEFAULTS.extractMinMessages;
        const extractMaxChars = cfg.extractMaxChars ?? DEFAULTS.extractMaxChars;
        // QMD Projection config
        const qmdProjectionConfig = {
            enabled: cfg.qmdProjection?.enabled ?? DEFAULTS.qmdProjection.enabled,
            qmdPath: api.resolvePath(cfg.qmdProjection?.qmdPath ?? DEFAULTS.qmdProjection.qmdPath),
            includeL1: cfg.qmdProjection?.includeL1 ?? DEFAULTS.qmdProjection.includeL1,
            categorySeparateFiles: cfg.qmdProjection?.categorySeparateFiles ?? DEFAULTS.qmdProjection.categorySeparateFiles,
            dailyTrigger: cfg.qmdProjection?.dailyTrigger ?? DEFAULTS.qmdProjection.dailyTrigger,
        };
        // Checkpoint config (P2-002: Resumable extraction)
        const checkpointEnabled = cfg.checkpoint?.enabled ?? DEFAULTS.checkpoint.enabled;
        const checkpointPath = api.resolvePath(cfg.checkpoint?.path ?? DEFAULTS.checkpoint.path);
        const checkpointAutoRecover = cfg.checkpoint?.autoRecoverOnStart ?? DEFAULTS.checkpoint.autoRecoverOnStart;
        // Initialize services with DeepSeek embeddings
        const vectorDim = 384; // Fixed dimension for pseudo-embeddings
        const db = new MemoryDB(dbPath, vectorDim, logger, cfg.decay);
        const embeddings = new DeepSeekEmbeddings(cfg.embedding.apiKey, embeddingModel, cfg.embedding.baseUrl);
        const llm = new LlmClient(cfg.llm.apiKey, llmModel, cfg.llm.baseUrl);
        const deduplicator = new MemoryDeduplicator(db, llm, logger);
        const extractor = new MemoryExtractor(db, embeddings, llm, deduplicator, logger);
        // Initialize checkpoint manager (P2-002)
        const checkpointMgr = checkpointEnabled
            ? new CheckpointManager(checkpointPath, logger)
            : null;
        // Register service lifecycle
        api.registerService({
            id: "epro-memory-deepseek",
            start: async () => {
                logger.info(`epro-memory-deepseek: initialized (db: ${dbPath}, embed: ${embeddingModel}, llm: ${llmModel}` +
                    (checkpointEnabled ? `, checkpoint: ${checkpointPath}` : "") +
                    ")");
                // Auto-recover incomplete extractions on startup (P2-002)
                if (checkpointMgr && checkpointAutoRecover) {
                    try {
                        const resumeResults = await extractor.resumeIncomplete(checkpointMgr);
                        if (resumeResults.length > 0) {
                            const total = resumeResults.reduce((acc, r) => ({
                                created: acc.created + r.created,
                                merged: acc.merged + r.merged,
                                skipped: acc.skipped + r.skipped,
                            }), { created: 0, merged: 0, skipped: 0 });
                            logger.info(`epro-memory-deepseek: auto-recovered ${resumeResults.length} incomplete extractions ` +
                                `(created=${total.created}, merged=${total.merged}, skipped=${total.skipped})`);
                        }
                    }
                    catch (err) {
                        logger.warn(`epro-memory-deepseek: auto-recovery failed: ${String(err)}`);
                    }
                }
            },
        });
        // Hook: before_agent_start — recall relevant memories
        if (autoRecall) {
            api.on("before_agent_start", async (event) => {
                if (!event.prompt || event.prompt.length < 5)
                    return;
                try {
                    const vector = await embeddings.embed(event.prompt);
                    const results = await db.search(vector, recallLimit, recallMinScore);
                    if (results.length === 0)
                        return;
                    // Increment active_count for recalled memories
                    for (const r of results) {
                        db.incrementActiveCount(r.entry.id).catch((err) => {
                            logger.warn(`epro-memory-deepseek: incrementActiveCount failed: ${String(err)}`);
                        });
                    }
                    // Format as L0 abstracts grouped by category
                    const grouped = new Map();
                    for (const r of results) {
                        const cat = r.entry.category;
                        if (!grouped.has(cat))
                            grouped.set(cat, []);
                        grouped.get(cat).push(`- ${sanitizeForContext(r.entry.abstract)}`);
                    }
                    const lines = [];
                    for (const [cat, items] of grouped) {
                        lines.push(`[${cat}]`);
                        lines.push(...items);
                    }
                    const memoryContext = lines.join("\n");
                    logger.info(`epro-memory-deepseek: injecting ${results.length} agent memories`);
                    return {
                        prependContext: `\nThe following agent experiences may be relevant:\n${memoryContext}\n`,
                    };
                }
                catch (err) {
                    logger.warn(`epro-memory-deepseek: recall failed: ${String(err)}`);
                }
            });
        }
        // Hook: agent_end — extract and persist memories
        if (autoCapture) {
            api.on("agent_end", async (event, ctx) => {
                if (!event.success)
                    return;
                if (!event.messages || event.messages.length < extractMinMessages)
                    return;
                try {
                    const conversationText = extractConversationText(event.messages, extractMaxChars);
                    if (!conversationText || conversationText.length < 50)
                        return;
                    const sessionKey = ctx?.sessionKey ?? "unknown";
                    const user = ctx?.agentId ?? "agent";
                    // Use checkpoint-based extraction if enabled (P2-002)
                    if (checkpointMgr) {
                        await extractor.extractWithCheckpoint(conversationText, sessionKey, user, checkpointMgr);
                    }
                    else {
                        await extractor.extractAndPersist(conversationText, sessionKey, user);
                    }
                }
                catch (err) {
                    logger.warn(`epro-memory-deepseek: extraction failed: ${String(err)}`);
                }
            });
        }
        // Hook: heartbeat — trigger daily QMD projection
        if (qmdProjectionConfig.enabled && qmdProjectionConfig.dailyTrigger) {
            api.on("heartbeat", async () => {
                try {
                    const lastProjection = await getLastProjectionTime(qmdProjectionConfig.qmdPath);
                    const now = Date.now();
                    if (!shouldRunProjection(lastProjection, now)) {
                        return;
                    }
                    logger.info("epro-memory-deepseek: starting daily QMD projection");
                    const memories = await db.getAll();
                    const result = await projectToQMD(memories, qmdProjectionConfig, qmdProjectionConfig.qmdPath, logger);
                    await setLastProjectionTime(qmdProjectionConfig.qmdPath, now);
                    logger.info(`epro-memory-deepseek: QMD projection complete (${result.categoryFilesWritten} category files, ${result.totalMemories} memories)`);
                }
                catch (err) {
                    logger.warn(`epro-memory-deepseek: QMD projection failed: ${String(err)}`);
                }
            });
        }
    },
};
/**
 * Extract text from conversation messages.
 * Handles both string content and content block arrays (Anthropic API format).
 */
function extractConversationText(messages, maxChars) {
    const parts = [];
    for (const msg of messages) {
        if (!msg || typeof msg !== "object")
            continue;
        const msgObj = msg;
        const role = msgObj.role;
        if (role !== "user" && role !== "assistant")
            continue;
        const prefix = role === "user" ? "Human" : "Assistant";
        const content = msgObj.content;
        if (typeof content === "string") {
            parts.push(`${prefix}: ${content}`);
            continue;
        }
        if (Array.isArray(content)) {
            for (const block of content) {
                if (block &&
                    typeof block === "object" &&
                    "type" in block &&
                    block.type === "text" &&
                    "text" in block &&
                    typeof block.text === "string") {
                    parts.push(`${prefix}: ${block.text}`);
                }
            }
        }
    }
    const text = parts.join("\n\n");
    if (text.length <= maxChars)
        return text;
    let truncated = text.slice(0, maxChars);
    // Avoid splitting UTF-16 surrogate pairs
    const lastChar = truncated.charCodeAt(truncated.length - 1);
    if (lastChar >= 0xd800 && lastChar <= 0xdbff) {
        truncated = truncated.slice(0, -1);
    }
    return truncated + "\u2026";
}
/**
 * Neutralize XML-like tags in stored text to prevent prompt boundary injection.
 * Only matches `<` followed by an optional `/` and a letter (i.e. actual tag syntax).
 * `<agent-experience>` becomes `< /agent-experience>`, but `5 < 10` is unchanged.
 */
export function sanitizeForContext(text) {
    return text.replace(/<(\/?)([a-zA-Z])/g, "< $1$2");
}
export { extractConversationText, CheckpointManager };
export default eproMemoryPlugin;
//# sourceMappingURL=index-deepseek.js.map