#!/bin/bash
# EvoMap节点保持在线脚本
# 节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198
# Hub节点ID: hub_0f978bbe1fb5
# 认领码: L5KD-XQRX
# 用户账户: gaojunfeng1108@gmail.com

set -e

echo "🔗 EvoMap节点保持在线脚本启动"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198"
echo "   - Hub节点ID: hub_0f978bbe1fb5"
echo "   - 认领码: L5KD-XQRX"
echo "   - 用户账户: gaojunfeng1108@gmail.com"
echo ""

# 1. 发送hello消息保持节点活跃
echo "📡 发送hello消息..."
HELLO_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "node_d0cf2a3b4b3946a492a8e72e381e1198",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {},
      "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
  }')

echo "✅ Hello消息发送完成"

# 2. 检查节点状态
echo ""
echo "🔍 检查节点状态..."
STATUS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.status // "unknown"')
NODE_ID=$(echo "$HELLO_RESPONSE" | jq -r '.payload.your_node_id // "unknown"')
CREDITS=$(echo "$HELLO_RESPONSE" | jq -r '.payload.credit_balance // 0')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 节点ID: $NODE_ID"
echo "   - 积分余额: $CREDITS"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃"
    
    # 3. 发送心跳消息（如果需要）
    echo ""
    echo "💓 发送心跳消息..."
    HEARTBEAT_RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "node_d0cf2a3b4b3946a492a8e72e381e1198",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {}
        }
      }')
    
    echo "✅ 心跳消息发送完成"
    
    # 4. 检查evolver运行状态
    echo ""
    echo "🔄 检查evolver运行状态..."
    if pgrep -f "evolver" > /dev/null; then
        echo "✅ evolver正在运行"
        EVOLVER_PID=$(pgrep -f "evolver")
        echo "   - 进程ID: $EVOLVER_PID"
    else
        echo "⚠️ evolver未运行"
        echo "💡 建议启动evolver: cd /root/.openclaw/workspace/evolver && npm start"
    fi
    
    # 5. 检查cron job状态
    echo ""
    echo "⏰ 检查cron job状态..."
    if crontab -l | grep -q "evomap"; then
        echo "✅ EvoMap同步cron job已配置"
    else
        echo "⚠️ EvoMap同步cron job未配置"
        echo "💡 建议配置每4小时同步的cron job"
    fi
    
else
    echo "❌ 节点状态异常: $STATUS"
    echo "💡 建议检查节点配置和网络连接"
fi

echo ""
echo "📋 建议操作:"
echo "1. 使用正确的节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198"
echo "2. 确保evolver客户端运行: cd /root/.openclaw/workspace/evolver && npm start"
echo "3. 配置cron job每4小时自动同步"
echo "4. 定期发送hello消息保持活跃"
echo "5. 在EvoMap Web客户端使用账户 gaojunfeng1108@gmail.com 查看节点状态"

echo ""
echo "🎯 脚本执行完成"