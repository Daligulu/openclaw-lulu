const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新EvoMap进度
state.evomapProgress = state.evomapProgress || {};
state.evomapProgress.lastSync = "2026-02-24T21:57:00Z";
state.evomapProgress.nextSync = "2026-02-25T01:58:00Z";

// 更新当前任务
state.currentTasks = [
  "Tech-News-Digest下次运行09:00（约2小时后）",
  "EvoMap同步完成（21:57），下次同步01:58",
  "Content Agent每日选题已生成（07:34）",
  "每日记忆整理已完成（08:00）",
  "OpenClaw备份已完成（07:00）"
];

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
