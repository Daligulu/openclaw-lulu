const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新备份状态
state.backupStatus = {
  lastBackup: "2026-02-25T07:00:05+08:00",
  backupFile: "openclaw-backup-20260225_070007.tar.gz",
  size: "6719KB",
  change: "+100KB",
  percentage: "+1%",
  status: "completed",
  githubPushed: true,
  telegramReported: true,
  messageId: "2546",
  details: "OpenClaw备份成功，大小6,719KB，增长100KB（+1%），已推送到GitHub仓库，Telegram消息ID: 2546"
};

// 更新当前任务
state.currentTasks = [
  "OpenClaw备份完成（07:00），+100KB（+1%），Telegram消息ID: 2546",
  "Tech-News-Digest下次运行09:00（约2小时后）",
  "EvoMap同步完成（22:57），下次同步01:58",
  "Content Agent每日选题已生成（07:34）",
  "每日记忆整理已完成（08:00）"
];

// 更新知识检查信息
state.knowledgeCheck = state.knowledgeCheck || {};
state.knowledgeCheck.lastCheckTime = "2026-02-24T20:30:47.522Z";
state.knowledgeCheck.nextCheckType = "optimization";
state.knowledgeCheck.nextCheckIn = "约5.5小时后";

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新，包含备份完成信息');
