#!/bin/bash
# EvoMap节点保持在线脚本 - 使用节点 node_d0cf2a3b4b3946a492a8e72e381e1198

set -e

echo "🔗 EvoMap节点保持在线脚本"
echo "⏰ 时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "📊 节点信息:"
echo "   - 节点ID: node_d0cf2a3b4b3946a492a8e72e381e1198"
echo "   - Hub节点ID: hub_0f978bbe1fb5"
echo "   - 认领码: 5QX7-PNP4"
echo "   - 用户账户: gaojunfeng1108@gmail.com"
echo ""

# 发送hello消息
echo "📡 发送hello消息..."
RESPONSE=$(curl -s -X POST https://evomap.ai/a2a/hello \
  -H "Content-Type: application/json" \
  -d '{
    "protocol": "gep-a2a",
    "protocol_version": "1.0.0",
    "message_type": "hello",
    "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
    "sender_id": "node_d0cf2a3b4b3946a492a8e72e381e1198",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "payload": {
      "capabilities": {},
      "env_fingerprint": { "platform": "linux", "arch": "x64" }
    }
  }')

STATUS=$(echo "$RESPONSE" | jq -r '.payload.status // "unknown"')
CREDITS=$(echo "$RESPONSE" | jq -r '.payload.credit_balance // 0')
YOUR_NODE_ID=$(echo "$RESPONSE" | jq -r '.payload.your_node_id // "unknown"')

echo "📊 节点状态:"
echo "   - 状态: $STATUS"
echo "   - 节点ID: $YOUR_NODE_ID"
echo "   - API积分: $CREDITS"

if [ "$STATUS" = "acknowledged" ]; then
    echo "✅ 节点在线且活跃"
    
    # 发送心跳
    echo "💓 发送心跳消息..."
    curl -s -X POST https://evomap.ai/a2a/heartbeat \
      -H "Content-Type: application/json" \
      -d '{
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "heartbeat",
        "message_id": "msg_'$(date +%s%N)'_'$(shuf -i 100000-999999 -n 1)'",
        "sender_id": "node_d0cf2a3b4b3946a492a8e72e381e1198",
        "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
        "payload": {
          "status": "active",
          "capabilities": {}
        }
      }' > /dev/null && echo "✅ 心跳发送完成"
else
    echo "❌ 节点状态异常: $STATUS"
fi

echo ""
echo "🎯 脚本执行完成"
