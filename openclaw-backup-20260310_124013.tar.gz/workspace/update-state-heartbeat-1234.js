const fs = require('fs');
const stateFile = 'memory/heartbeat-state.json';
const now = Math.floor(Date.now() / 1000);
const nowISO = new Date().toISOString();

let state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));

// 更新heartbeat时间
state.lastHeartbeatTime = now;
state.lastQuietHeartbeat = nowISO;

// 更新当前任务
state.currentTasks = [
  "Tech-News-Digest发现重要AI热点（12:02）",
  "OpenClaw备份完成（12:00），+9KB（+0%），Telegram消息ID: 2571",
  "Tech-News-Digest发现3条NBA热点（12:00）",
  "MEMORY.md编辑失败已修复（10:07）",
  "Tech-News-Digest运行完成（09:00），发现24个AI热点",
  "每日记忆整理完成（08:00）",
  "Content Agent每日选题执行完成（07:30，耗时23.24秒）",
  "EvoMap同步完成（22:57），下次同步05:58"
];

// 更新备份状态
state.backupStatus = {
  "lastBackup": "2026-02-25T12:00:36",
  "backupFile": "openclaw-backup-20260225_120038.tar.gz",
  "size": "6916KB",
  "change": "+9KB",
  "percentage": "+0%",
  "status": "completed",
  "githubPushed": true,
  "telegramReported": true,
  "messageId": "2571",
  "details": "OpenClaw备份成功，大小6,916KB，增长9KB（+0%），已推送到GitHub仓库"
};

// 更新AI热点发现
state.newHotspotsFound = {
  "timestamp": "2026-02-25T12:02:00",
  "aiTopics": 4,
  "dogTopics": 1,
  "nbaTopics": 0,
  "total": 5,
  "status": "needs_reporting",
  "telegramMessageId": null,
  "hotspots": [
    {
      "title": "OpenClaw v2026.2.24发布",
      "category": "AI-工具更新",
      "priority": "⭐⭐⭐⭐⭐⭐⭐⭐⭐⭐",
      "source": "https://github.com/openclaw/openclaw/releases/tag/v2026.2.24",
      "description": "GitHub发布，质量分数10.0，Auto-reply/Abort shortcuts扩展，支持更多停止短语"
    },
    {
      "title": "Crittora使OpenClaw企业就绪",
      "category": "AI-企业应用",
      "priority": "⭐⭐⭐⭐⭐⭐⭐",
      "source": "https://finance.yahoo.com/news/crittora-makes-openclaw-enterprise-ready-155800602.html",
      "description": "质量分数7.0，通过消除自主代理中的环境权限使OpenClaw企业就绪"
    },
    {
      "title": "Cursor AI编码代理重大更新",
      "category": "AI-编程工具",
      "priority": "⭐⭐",
      "source": "https://www.cnbc.com/2026/02/24/cursor-announces-major-update-as-ai-coding-agent-battle-heats-up.html",
      "description": "质量分数2.0，AI编码代理可以测试自己的更改并通过视频、日志和截图记录工作"
    },
    {
      "title": "AI Updates Today (February 2026)",
      "category": "AI-行业动态",
      "priority": "⭐⭐⭐⭐⭐⭐⭐",
      "source": "https://llm-stats.com/llm-updates",
      "description": "质量分数7.0，跟踪最新的LLM发布、API变更、新功能"
    },
    {
      "title": "I'm helping my dog vibe code games",
      "category": "狗狗-科技项目",
      "priority": "⭐⭐⭐⭐⭐",
      "source": "https://www.calebleak.com/posts/dog-game/",
      "description": "质量分数5.0，帮助狗狗编写游戏代码的有趣项目"
    }
  ]
};

fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
console.log('✅ 状态文件已更新');
