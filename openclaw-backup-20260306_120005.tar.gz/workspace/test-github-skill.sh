#!/bin/bash
# GitHub技能测试脚本

echo "=== GitHub技能安装测试 ==="
echo "安装位置: /root/.openclaw/workspace/skills/github/"
echo ""

# 检查技能文件
echo "📁 技能文件:"
ls -la /root/.openclaw/workspace/skills/github/
echo ""

# 显示技能文档
echo "📖 技能文档内容:"
cat /root/.openclaw/workspace/skills/github/SKILL.md
echo ""

# 检查gh CLI
echo "🔧 gh CLI状态:"
which gh
gh --version
echo ""

# 检查认证状态
echo "🔐 GitHub认证状态:"
gh auth status 2>&1 || echo "未认证 - 需要运行: gh auth login"
echo ""

# 显示可用命令示例
echo "💡 可用命令示例:"
echo "1. 查看仓库信息:"
echo "   gh repo view owner/repo"
echo ""
echo "2. 列出issue:"
echo "   gh issue list --repo owner/repo --limit 5"
echo ""
echo "3. 查看PR状态:"
echo "   gh pr checks <pr-number> --repo owner/repo"
echo ""
echo "4. 查看CI运行:"
echo "   gh run list --repo owner/repo --limit 5"
echo ""
echo "5. 使用API查询:"
echo "   gh api repos/owner/repo"
echo ""

# 显示安装的元数据
echo "📋 技能元数据:"
cat /root/.openclaw/workspace/skills/github/_meta.json
echo ""

echo "✅ GitHub技能安装完成！"
echo "下一步: 运行 'gh auth login' 配置GitHub认证"