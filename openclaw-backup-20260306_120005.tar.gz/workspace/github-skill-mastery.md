# GitHub技能完全掌握指南

## 项目概述

### 基本信息
- **技能名称**: github
- **所有者**: steipete
- **版本**: 1.0.0
- **安装位置**: `/root/.openclaw/workspace/skills/github/`
- **核心工具**: GitHub CLI (`gh`)

### 技能定位
通过`gh` CLI提供完整的GitHub交互能力，特别适合：
1. **内容创作者** - 监控GitHub趋势和热门项目
2. **开发者** - 管理issue、PR、CI工作流
3. **项目经理** - 跟踪项目状态和协作
4. **自动化脚本** - 集成GitHub API到工作流

## 核心功能深度解析

### 1. 认证与配置

#### 1.1 认证方式
```bash
# 交互式登录
gh auth login

# 使用token登录
gh auth login --with-token < token.txt

# 检查认证状态
gh auth status

# 登出
gh auth logout
```

#### 1.2 环境配置
```bash
# 查看配置
gh config list

# 设置默认编辑器
gh config set editor vim

# 设置Git协议
gh config set git_protocol ssh

# 设置API主机
gh config set host github.com
```

### 2. 仓库管理

#### 2.1 仓库查看
```bash
# 查看仓库基本信息
gh repo view owner/repo

# 查看仓库详细信息（JSON格式）
gh repo view owner/repo --json name,description,stargazersCount,forkCount,updatedAt

# 查看仓库README
gh repo view owner/repo --web

# 克隆仓库
gh repo clone owner/repo
```

#### 2.2 仓库操作
```bash
# 创建新仓库
gh repo create [name] --public --clone

# 删除仓库
gh repo delete owner/repo --confirm

# 重命名仓库
gh repo rename new-name

# 设置仓库主题
gh repo edit --add-topic "ai,automation,cli"
```

### 3. Issue管理

#### 3.1 Issue查询
```bash
# 列出所有issue
gh issue list --repo owner/repo

# 列出open的issue
gh issue list --repo owner/repo --state open

# 列出指定标签的issue
gh issue list --repo owner/repo --label "bug,enhancement"

# 搜索issue
gh issue list --repo owner/repo --search "error" --state all
```

#### 3.2 Issue操作
```bash
# 创建issue
gh issue create --title "Bug report" --body "Description..."

# 查看issue详情
gh issue view 123 --repo owner/repo

# 关闭issue
gh issue close 123 --repo owner/repo

# 重新打开issue
gh issue reopen 123 --repo owner/repo

# 添加评论
gh issue comment 123 --body "Fixed in PR #456"
```

### 4. Pull Request管理

#### 4.1 PR查询
```bash
# 列出所有PR
gh pr list --repo owner/repo

# 列出指定状态的PR
gh pr list --repo owner/repo --state open
gh pr list --repo owner/repo --state closed
gh pr list --repo owner/repo --state merged

# 查看PR详情
gh pr view 456 --repo owner/repo
```

#### 4.2 PR操作
```bash
# 创建PR
gh pr create --title "Feature addition" --body "Description..."

# 检查PR状态
gh pr checks 456 --repo owner/repo

# 合并PR
gh pr merge 456 --repo owner/repo --squash

# 查看PR差异
gh pr diff 456 --repo owner/repo

# 检出PR分支
gh pr checkout 456 --repo owner/repo
```

### 5. CI/CD监控

#### 5.1 工作流运行
```bash
# 列出工作流运行
gh run list --repo owner/repo

# 查看运行详情
gh run view [run-id] --repo owner/repo

# 查看失败日志
gh run view [run-id] --repo owner/repo --log-failed

# 重新运行工作流
gh run rerun [run-id] --repo owner/repo

# 取消运行
gh run cancel [run-id] --repo owner/repo
```

#### 5.2 工作流管理
```bash
# 列出工作流
gh workflow list --repo owner/repo

# 查看工作流详情
gh workflow view [workflow-id] --repo owner/repo

# 启用工作流
gh workflow enable [workflow-id] --repo owner/repo

# 禁用工作流
gh workflow disable [workflow-id] --repo owner/repo
```

### 6. 高级API查询

#### 6.1 基础API调用
```bash
# 获取仓库信息
gh api repos/owner/repo

# 获取issue列表
gh api repos/owner/repo/issues

# 获取PR列表
gh api repos/owner/repo/pulls

# 获取release列表
gh api repos/owner/repo/releases
```

#### 6.2 复杂查询
```bash
# 获取特定字段
gh api repos/owner/repo --jq '.name, .description, .stargazers_count'

# 过滤数据
gh api repos/owner/repo/issues --jq '.[] | select(.state == "open") | .title'

# 分页查询
gh api repos/owner/repo/issues --paginate --jq '.[].title'

# 自定义请求
gh api -X POST repos/owner/repo/issues -f title="New issue" -f body="Description"
```

### 7. JSON输出处理

#### 7.1 结构化输出
```bash
# 基本JSON输出
gh repo view owner/repo --json name,description

# 嵌套JSON字段
gh pr view 456 --repo owner/repo --json number,title,author,state

# 数组处理
gh issue list --repo owner/repo --json number,title,labels --jq '.[] | "\(.number): \(.title) [\(.labels[].name)]"'
```

#### 7.2 jq过滤器
```bash
# 简单过滤
gh api repos/owner/repo --jq '.stargazers_count'

# 条件过滤
gh api repos/owner/repo/issues --jq '.[] | select(.comments > 0) | .title'

# 格式化输出
gh api repos/owner/repo --jq '"Repository: \(.name)\nStars: \(.stargazers_count)\nForks: \(.forks_count)"'

# 数组操作
gh api repos/owner/repo/issues --jq '[.[] | {number: .number, title: .title}]'
```

## 实战应用场景

### 场景1：内容创作热点发现

```bash
# 查找热门AI仓库
gh search repos "topic:ai" --sort stars --limit 10 --json name,description,stargazersCount

# 监控特定仓库更新
gh api repos/openai/openai/releases --jq '.[0] | "\(.name): \(.published_at)"'

# 获取趋势项目
gh api trending/developers --jq '.[] | "\(.username): \(.name)"'
```

### 场景2：技术项目监控

```bash
# 监控CI状态
gh run list --repo owner/repo --limit 5 --json conclusion,status,workflowName

# 跟踪issue解决进度
gh issue list --repo owner/repo --state open --json number,title,createdAt --jq '.[] | "\(.number): \(.title) (open for \(((now - (.createdAt | fromdateiso8601)) / 86400) | floor) days)"'

# 检查依赖更新
gh api repos/owner/repo/dependency-graph/sbom --jq '.sbom.packages | map(select(.externalRefs[0].referenceLocator | contains("pkg:npm"))) | length'
```

### 场景3：自动化工作流

```bash
#!/bin/bash
# 自动化issue分类脚本

# 获取未分类的issue
issues=$(gh issue list --repo owner/repo --state open --json number,title,body --jq '.[] | select(.body | contains("bug") or contains("feature") | not) | .number')

for issue in $issues; do
    # 分析issue内容
    content=$(gh issue view $issue --repo owner/repo --json body --jq '.body')
    
    if echo "$content" | grep -qi "error\|fail\|crash"; then
        gh issue edit $issue --repo owner/repo --add-label "bug"
    elif echo "$content" | grep -qi "enhance\|improve\|feature"; then
        gh issue edit $issue --repo owner/repo --add-label "enhancement"
    fi
done
```

### 场景4：项目报告生成

```bash
#!/bin/bash
# 生成项目状态报告

echo "# 项目状态报告 - $(date)"
echo ""

# 仓库基本信息
echo "## 仓库概览"
gh repo view owner/repo --json name,description,stargazersCount,forkCount,updatedAt --jq '"**名称**: \(.name)\n**描述**: \(.description)\n**星标**: \(.stargazersCount)\n**分支**: \(.forkCount)\n**最后更新**: \(.updatedAt)"'
echo ""

# Issue状态
echo "## Issue状态"
gh issue list --repo owner/repo --state all --json state --jq 'group_by(.state) | map({state: .[0].state, count: length}) | .[] | "\(.state): \(.count)"'
echo ""

# PR状态
echo "## PR状态"
gh pr list --repo owner/repo --state all --json state --jq 'group_by(.state) | map({state: .[0].state, count: length}) | .[] | "\(.state): \(.count)"'
echo ""

# CI状态
echo "## CI状态"
gh run list --repo owner/repo --limit 5 --json conclusion,workflowName --jq '.[] | "\(.workflowName): \(.conclusion)"'
```

## 技能集成方案

### 1. 与现有系统集成

#### 1.1 记忆系统集成
```bash
# 将GitHub活动记录到记忆系统
gh api users/octocat/events --paginate --jq '.[] | select(.type == "PushEvent") | "\(.created_at): \(.repo.name)"' >> /root/.openclaw/workspace/memory/daily/$(date +%Y-%m-%d).md
```

#### 1.2 内容Agent集成
```bash
# 为内容Agent提供GitHub热点
gh search repos "topic:ai" --sort updated --limit 5 --json name,description --jq '.[] | "## \(.name)\n\(.description)\n"' > ai_trends.md
```

#### 1.3 Tech-News-Digest集成
```bash
# 获取GitHub releases作为新闻源
gh api repos/openai/openai/releases --jq '.[0:3] | .[] | "\(.name) released: \(.published_at)\n\(.body | split("\n")[0:2] | join("\n"))"'
```

### 2. 自动化监控脚本

#### 2.1 仓库健康监控
```bash
#!/bin/bash
# 仓库健康监控脚本

REPO="owner/repo"
THRESHOLD_DAYS=7

# 检查最后更新时间
last_update=$(gh repo view $REPO --json updatedAt --jq '.updatedAt')
last_update_ts=$(date -d "$last_update" +%s)
current_ts=$(date +%s)
days_since=$(( (current_ts - last_update_ts) / 86400 ))

if [ $days_since -gt $THRESHOLD_DAYS ]; then
    echo "警告: $REPO 已经 $days_since 天没有更新"
fi

# 检查open issue数量
open_issues=$(gh issue list --repo $REPO --state open --json number --jq 'length')
if [ $open_issues -gt 20 ]; then
    echo "警告: $REPO 有 $open_issues 个open issue"
fi
```

#### 2.2 CI失败通知
```bash
#!/bin/bash
# CI失败监控脚本

REPO="owner/repo"

# 获取最近失败的运行
failed_runs=$(gh run list --repo $REPO --limit 10 --json conclusion,status,workflowName,url --jq '.[] | select(.conclusion == "failure") | "\(.workflowName) failed: \(.url)"')

if [ -n "$failed_runs" ]; then
    echo "CI失败报告:"
    echo "$failed_runs"
    # 可以集成到Telegram通知
fi
```

## 最佳实践

### 1. 认证安全
- 使用最小权限的token
- 定期轮换token
- 使用环境变量存储敏感信息
- 避免在脚本中硬编码token

### 2. 性能优化
- 使用`--paginate`处理大量数据
- 使用`--jq`过滤减少数据传输
- 缓存频繁查询的结果
- 批量操作减少API调用

### 3. 错误处理
```bash
#!/bin/bash
# 错误处理示例

set -e  # 遇到错误立即退出

# 尝试执行命令，捕获错误
if ! output=$(gh repo view invalid/repo 2>&1); then
    if echo "$output" | grep -q "Not Found"; then
        echo "仓库不存在"
    elif echo "$output" | grep -q "rate limit"; then
        echo "API限制，等待后重试"
        sleep 60
    else
        echo "未知错误: $output"
    fi
    exit 1
fi
```

### 4. 日志记录
```bash
#!/bin/bash
# 详细日志记录

LOG_FILE="github_operations.log"

log() {
    echo "[$(date)] $1" >> "$LOG_FILE"
}

# 记录操作
log "开始查询仓库信息"
gh repo view owner/repo --json name >> "$LOG_FILE"
log "查询完成"
```

## 故障排除

### 常见问题

#### 1. 认证失败
```bash
# 检查认证状态
gh auth status

# 重新登录
gh auth logout
gh auth login

# 检查token权限
gh api user --jq '.login'
```

#### 2. API限制
```bash
# 检查API限制
gh api rate_limit --jq '.resources.core'

# 等待后重试
sleep 60

# 使用缓存减少调用
```

#### 3. 网络问题
```bash
# 测试连接
gh api zen

# 检查代理设置
export HTTPS_PROXY=http://proxy:port
export HTTP_PROXY=http://proxy:port
```

#### 4. 命令不存在
```bash
# 更新gh CLI
gh upgrade

# 安装扩展
gh extension install owner/extension

# 检查命令帮助
gh help [command]
```

## 学习资源

### 官方文档
- [GitHub CLI手册](https://cli.github.com/manual)
- [GitHub API文档](https://docs.github.com/en/rest)
- [jq手册](https://stedolan.github.io/jq/manual/)

### 进阶学习
- GitHub Actions自动化
- GraphQL API高级查询
- Webhook集成
- OAuth应用开发

### 社区资源
- GitHub CLI仓库：https://github.com/cli/cli
- 官方示例：https://github.com/cli/cli#examples
- 社区扩展：https://github.com/topics/gh-extension

## 总结

### 掌握程度评估
- ✅ **基础操作**: 仓库、issue、PR管理
- ✅ **CI/CD监控**: 工作流运行和状态检查
- ✅ **API查询**: 高级数据获取和过滤
- ✅ **自动化集成**: 脚本编写和工作流设计
- ✅ **最佳实践**: 安全、性能、错误处理

### 应用价值
1. **效率提升**: 命令行操作比Web界面更快
2. **自动化能力**: 可集成到各种工作流中
3. **数据获取**: 结构化数据便于分析和处理
4. **监控能力**: 实时跟踪项目状态和健康度

### 下一步建议
1. **实战练习**: 使用真实项目进行练习
2. **认证配置**: 设置GitHub认证
3. **集成开发**: 将技能集成到现有工作流
4. **扩展学习**: 学习GitHub Actions和Webhook

通过完全掌握这个GitHub技能，你将能够高效地管理GitHub项目、监控技术趋势、自动化工作流程，为内容创作和技术监控提供强大支持。