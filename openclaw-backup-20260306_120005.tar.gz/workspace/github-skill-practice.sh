#!/bin/bash
# GitHub技能实战练习脚本

set -e

echo "🚀 GitHub技能实战练习"
echo "======================"
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

# 检查gh CLI
check_gh_cli() {
    log_info "检查gh CLI..."
    if command -v gh &> /dev/null; then
        gh_version=$(gh --version | head -1)
        log_success "gh CLI已安装: $gh_version"
    else
        log_error "gh CLI未安装"
        exit 1
    fi
    echo ""
}

# 检查认证状态
check_auth_status() {
    log_info "检查GitHub认证状态..."
    if gh auth status &> /dev/null; then
        log_success "GitHub认证正常"
    else
        log_warning "GitHub未认证，部分功能受限"
        log_info "运行 'gh auth login' 进行认证"
    fi
    echo ""
}

# 练习1: 仓库信息查询
practice_repo_info() {
    log_info "练习1: 仓库信息查询"
    
    # 使用知名的开源仓库进行练习
    REPOS=(
        "openclaw/openclaw"
        "cli/cli"
        "microsoft/vscode"
        "facebook/react"
    )
    
    for repo in "${REPOS[@]}"; do
        echo "查询仓库: $repo"
        
        # 尝试获取基本信息
        if output=$(gh repo view "$repo" --json name,description,stargazersCount 2>/dev/null); then
            name=$(echo "$output" | jq -r '.name')
            desc=$(echo "$output" | jq -r '.description')
            stars=$(echo "$output" | jq -r '.stargazersCount')
            
            echo "  📦 名称: $name"
            echo "  📝 描述: ${desc:0:50}..."
            echo "  ⭐ 星标: $stars"
            log_success "查询成功"
        else
            log_warning "查询失败或需要认证"
        fi
        echo ""
    done
}

# 练习2: Issue和PR统计
practice_issue_pr_stats() {
    log_info "练习2: Issue和PR统计"
    
    # 使用不需要认证的公开API
    echo "分析 openclaw/openclaw 仓库:"
    
    # 尝试获取issue统计
    if command -v jq &> /dev/null; then
        # 使用GitHub API（公开访问）
        issues_url="https://api.github.com/repos/openclaw/openclaw"
        
        if curl -s "$issues_url" | jq -r '"  📊 仓库信息:", "    名称: \(.name)", "    描述: \(.description)", "    星标: \(.stargazers_count)", "    Fork: \(.forks_count)"' 2>/dev/null; then
            log_success "API查询成功"
        else
            log_warning "API查询失败"
        fi
    else
        log_warning "需要安装jq进行JSON解析"
    fi
    echo ""
}

# 练习3: 搜索功能
practice_search() {
    log_info "练习3: GitHub搜索"
    
    echo "搜索热门AI项目:"
    
    # 尝试搜索（需要认证）
    if gh auth status &> /dev/null; then
        if output=$(gh search repos "topic:ai" --sort stars --limit 3 --json name,stargazersCount 2>/dev/null); then
            echo "$output" | jq -r '.[] | "  🔍 \(.name) - ⭐ \(.stargazersCount)"'
            log_success "搜索成功"
        else
            log_warning "搜索失败"
        fi
    else
        log_info "需要认证才能使用搜索功能"
        echo "  运行 'gh auth login' 后重试"
    fi
    echo ""
}

# 练习4: CI状态检查
practice_ci_status() {
    log_info "练习4: CI状态检查"
    
    echo "检查GitHub Actions状态示例:"
    
    if gh auth status &> /dev/null; then
        # 尝试获取CI运行状态
        if output=$(gh api repos/openclaw/openclaw/actions/runs --jq '.workflow_runs[0:2] | .[] | "  ⚙️  \(.name): \(.conclusion) (\(.status))"' 2>/dev/null); then
            echo "$output"
            log_success "CI状态查询成功"
        else
            log_warning "CI状态查询失败"
        fi
    else
        log_info "需要认证才能访问Actions API"
    fi
    echo ""
}

# 练习5: 创建自动化脚本
practice_automation() {
    log_info "练习5: 创建自动化监控脚本"
    
    cat > /tmp/github_monitor.sh << 'EOF'
#!/bin/bash
# GitHub仓库监控脚本

set -e

REPO="${1:-openclaw/openclaw}"
LOG_FILE="/tmp/github_monitor.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "开始监控仓库: $REPO"

# 检查仓库是否存在
if ! gh repo view "$REPO" --json name &> /dev/null; then
    log "错误: 仓库 $REPO 不存在或无法访问"
    exit 1
fi

# 获取仓库信息
info=$(gh repo view "$REPO" --json name,description,stargazersCount,updatedAt 2>/dev/null || echo "{}")

if [ "$info" != "{}" ]; then
    name=$(echo "$info" | jq -r '.name')
    stars=$(echo "$info" | jq -r '.stargazersCount')
    updated=$(echo "$info" | jq -r '.updatedAt')
    
    log "仓库: $name"
    log "星标: $stars"
    log "最后更新: $updated"
    
    # 检查更新频率
    updated_ts=$(date -d "$updated" +%s)
    current_ts=$(date +%s)
    days_since=$(( (current_ts - updated_ts) / 86400 ))
    
    if [ $days_since -gt 30 ]; then
        log "警告: 仓库已经 $days_since 天没有更新"
    fi
else
    log "警告: 无法获取仓库详细信息"
fi

log "监控完成"
EOF
    
    chmod +x /tmp/github_monitor.sh
    log_success "创建监控脚本: /tmp/github_monitor.sh"
    echo "  使用方式: ./github_monitor.sh [owner/repo]"
    echo ""
}

# 练习6: JSON数据处理
practice_json_processing() {
    log_info "练习6: JSON数据处理练习"
    
    if ! command -v jq &> /dev/null; then
        log_warning "请先安装jq: apt-get install jq 或 brew install jq"
        return
    fi
    
    echo "创建JSON数据处理示例:"
    
    cat > /tmp/json_example.json << 'EOF'
{
  "repositories": [
    {
      "name": "openclaw",
      "stars": 1500,
      "language": "TypeScript",
      "updated": "2026-02-25T10:30:00Z"
    },
    {
      "name": "cli",
      "stars": 45000,
      "language": "Go",
      "updated": "2026-02-24T15:45:00Z"
    },
    {
      "name": "vscode",
      "stars": 158000,
      "language": "TypeScript",
      "updated": "2026-02-25T08:20:00Z"
    }
  ]
}
EOF
    
    echo "示例数据已保存到 /tmp/json_example.json"
    echo ""
    
    echo "jq练习命令:"
    echo "1. 提取所有仓库名称:"
    echo "   jq '.repositories[].name' /tmp/json_example.json"
    echo ""
    echo "2. 过滤TypeScript仓库:"
    echo "   jq '.repositories[] | select(.language == \"TypeScript\") | .name' /tmp/json_example.json"
    echo ""
    echo "3. 计算总星标数:"
    echo "   jq '[.repositories[].stars] | add' /tmp/json_example.json"
    echo ""
    echo "4. 格式化输出:"
    echo "   jq '.repositories[] | \"\(.name): \(.stars) stars\"' /tmp/json_example.json"
    
    log_success "JSON处理练习准备完成"
    echo ""
}

# 练习7: 错误处理
practice_error_handling() {
    log_info "练习7: 错误处理练习"
    
    echo "创建错误处理脚本示例:"
    
    cat > /tmp/error_handling.sh << 'EOF'
#!/bin/bash
# GitHub命令错误处理示例

set -euo pipefail

# 函数：安全执行GitHub命令
safe_gh_command() {
    local command="$1"
    local max_retries=3
    local retry_count=0
    
    while [ $retry_count -lt $max_retries ]; do
        if output=$(eval "$command" 2>&1); then
            echo "$output"
            return 0
        else
            retry_count=$((retry_count + 1))
            
            # 检查错误类型
            if echo "$output" | grep -q "rate limit"; then
                echo "API限制，等待60秒后重试 ($retry_count/$max_retries)..." >&2
                sleep 60
            elif echo "$output" | grep -q "Not Found"; then
                echo "错误: 资源未找到" >&2
                return 1
            elif echo "$output" | grep -q "Bad credentials"; then
                echo "错误: 认证失败" >&2
                return 1
            else
                echo "未知错误，等待10秒后重试 ($retry_count/$max_retries)..." >&2
                sleep 10
            fi
        fi
    done
    
    echo "错误: 命令失败，已达到最大重试次数" >&2
    return 1
}

# 使用示例
echo "尝试查询仓库信息..."
if result=$(safe_gh_command "gh repo view openclaw/openclaw --json name 2>/dev/null"); then
    echo "成功: $result"
else
    echo "查询失败"
fi

echo ""
echo "尝试查询不存在的仓库..."
if result=$(safe_gh_command "gh repo view invalid/invalid --json name 2>/dev/null"); then
    echo "成功: $result"
else
    echo "预期中的失败"
fi
EOF
    
    chmod +x /tmp/error_handling.sh
    log_success "创建错误处理脚本: /tmp/error_handling.sh"
    echo ""
}

# 主函数
main() {
    echo "📚 GitHub技能实战练习开始"
    echo "=========================="
    echo ""
    
    check_gh_cli
    check_auth_status
    
    # 执行练习
    practice_repo_info
    practice_issue_pr_stats
    practice_search
    practice_ci_status
    practice_automation
    practice_json_processing
    practice_error_handling
    
    echo "🎉 练习完成！"
    echo ""
    echo "📋 生成的脚本文件:"
    echo "  1. /tmp/github_monitor.sh - 仓库监控脚本"
    echo "  2. /tmp/error_handling.sh - 错误处理脚本"
    echo "  3. /tmp/json_example.json - JSON数据示例"
    echo ""
    echo "💡 下一步建议:"
    echo "  1. 运行 'gh auth login' 配置完整认证"
    echo "  2. 使用真实项目练习各种命令"
    echo "  3. 将GitHub技能集成到工作流中"
    echo "  4. 学习GitHub Actions自动化"
    echo ""
    echo "🔧 已掌握的核心技能:"
    echo "  ✅ 仓库信息查询"
    echo "  ✅ Issue/PR统计"
    echo "  ✅ GitHub搜索"
    echo "  ✅ CI状态监控"
    echo "  ✅ 自动化脚本编写"
    echo "  ✅ JSON数据处理"
    echo "  ✅ 错误处理机制"
    echo ""
    echo "🚀 现在你可以高效地使用GitHub CLI进行开发和管理了！"
}

# 执行主函数
main "$@"