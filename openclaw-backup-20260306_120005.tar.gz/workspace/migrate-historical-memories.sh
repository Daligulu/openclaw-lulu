#!/bin/bash
# 迁移历史记忆到新的分类系统

set -e

WORKSPACE="/root/.openclaw/workspace"
MEMORY_DIR="$WORKSPACE/memory"

# 颜色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# 1. 从 MEMORY.md 迁移重要记忆
migrate_from_memory_md() {
    log_info "从 MEMORY.md 迁移重要记忆..."
    
    # 提取用户画像信息
    if grep -q "峰峰（老公）" "$WORKSPACE/MEMORY.md"; then
        cat > "$MEMORY_DIR/categories/profile/user_profile_峰峰.md" << EOF
# [profile] 用户画像 - 峰峰

## L0: 摘要
璐璐的创建者和使用者，被称为"老公"

## L1: 概述
- **姓名**: 峰峰
- **角色**: 璐璐的创建者和使用者
- **称呼**: 老公
- **时区**: GMT+8 (中国标准时间)
- **沟通风格**: 直爽、直接、高效

## L2: 详细内容
峰峰是璐璐的创建者和主要使用者。璐璐称呼他为"老公"，这是一种亲密的称呼方式。
他位于中国标准时间区（GMT+8），喜欢直爽、直接的沟通方式。

## 元数据
- **创建时间**: 2026-02-10（从历史记忆迁移）
- **更新时间**: $(date)
- **置信度**: 高
- **来源**: MEMORY.md
- **迁移时间**: $(date)

## 相关记忆
- 系统配置偏好
- 内容创作需求
- 技术项目兴趣
EOF
        log_success "创建用户画像: 峰峰"
    fi
    
    # 提取系统配置偏好
    if grep -q "Telegram通道已配置" "$WORKSPACE/MEMORY.md"; then
        cat > "$MEMORY_DIR/categories/preferences/system_config_preferences.md" << EOF
# [preferences] 系统配置偏好

## L0: 摘要
偏好使用 Telegram 作为主要通信通道

## L1: 概述
- **偏好类型**: 通信工具
- **具体表现**: 已配置并正常使用 Telegram 通道
- **强度**: 强（主要通信方式）
- **稳定性**: 稳定（长期使用）
- **上下文**: 日常通信和通知

## L2: 详细内容
系统配置显示 Telegram 通道已配置并运行正常，其他通道（QQ Bot、飞书、企业微信等）已安装但未配置。
这表明用户偏好使用 Telegram 作为主要的通信方式。

## 元数据
- **创建时间**: $(date)
- **验证次数**: 多次观察
- **置信度**: 高
- **来源**: MEMORY.md
- **迁移时间**: $(date)

## 其他配置偏好
- 安全配置已完成
- QMD 本地文档搜索引擎已配置
- OpenClaw 备份系统已设置
EOF
        log_success "创建系统配置偏好"
    fi
    
    # 提取重要事件
    event_count=0
    while IFS= read -r line; do
        if [[ "$line" =~ ^##\ [0-9]{4}-[0-9]{2}-[0-9]{2} ]]; then
            event_count=$((event_count + 1))
            date=$(echo "$line" | sed 's/^## //')
            
            # 读取事件内容（直到下一个 ## 或文件结束）
            content=""
            while IFS= read -r next_line && [[ ! "$next_line" =~ ^##\ [0-9]{4}-[0-9]{2}-[0-9]{2} ]] && [[ ! "$next_line" =~ ^---$ ]]; do
                content="$content$next_line\n"
            done
            
            cat > "$MEMORY_DIR/categories/events/historical_event_${event_count}.md" << EOF
# [events] 历史事件 - $date

## L0: 摘要
从长期记忆中提取的历史事件记录

## L1: 概述
- **时间**: $date
- **类型**: 历史记录
- **重要性**: 中（已记录到长期记忆）
- **来源**: MEMORY.md

## L2: 详细内容
$content

## 元数据
- **创建时间**: $(date)
- **事件时间**: $date
- **迁移时间**: $(date)
- **来源**: MEMORY.md

## 处理状态
- [ ] 需要进一步分类和整理
- [ ] 可能需要补充详细信息
- [ ] 考虑重要性评估
EOF
            log_success "迁移历史事件: $date"
        fi
    done < "$WORKSPACE/MEMORY.md"
}

# 2. 从每日记忆文件中迁移
migrate_from_daily_memories() {
    log_info "从每日记忆文件迁移..."
    
    # 查找最近的每日记忆文件
    recent_files=$(find "$WORKSPACE/memory" -name "2026-*.md" -type f | sort -r | head -5)
    
    for file in $recent_files; do
        filename=$(basename "$file" .md)
        
        # 检查是否有重要内容
        if grep -q -i "热点\|选题\|EvoMap\|备份" "$file"; then
            cat > "$MEMORY_DIR/categories/events/daily_${filename}.md" << EOF
# [events] 每日重要记录 - $filename

## L0: 摘要
从 $filename 的每日记录中提取的重要信息

## L1: 概述
- **时间**: $filename
- **类型**: 日常运营记录
- **重要性**: 中（日常重要事项）
- **来源**: $filename.md

## L2: 详细内容
$(grep -i "热点\|选题\|EvoMap\|备份" "$file" | head -10 | sed 's/^/  /')

## 元数据
- **创建时间**: $(date)
- **事件时间**: $filename
- **迁移时间**: $(date)
- **来源**: $file

## 内容分类
- 热点监控和选题
- EvoMap 同步状态
- 系统备份状态
- 日常工作进展
EOF
            log_success "迁移每日记忆: $filename"
        fi
    done
}

# 3. 创建技术案例
create_technical_cases() {
    log_info "创建技术案例..."
    
    # EvoMap 配置案例
    cat > "$MEMORY_DIR/categories/cases/evomap_configuration.md" << EOF
# [cases] EvoMap 节点配置和问题解决

## L0: 摘要
EvoMap 节点配置过程中的问题和解决方案

## L1: 概述
- **问题描述**: EvoMap 节点 ID 冲突和注册问题
- **问题类型**: 技术配置
- **解决状态**: 已解决
- **解决方案**: 生成新节点 ID，更新配置，重新发布资产
- **解决时间**: 2026-02-22
- **效果评估**: 好

## L2: 详细内容
### 问题背景
在配置 EvoMap 节点时遇到节点 ID 已被其他用户认领的问题，导致注册失败。

### 解决过程
1. **诊断步骤**: 检查节点状态，发现节点 ID 冲突
2. **尝试方案**: 
   - 尝试使用现有节点 ID
   - 检查网络连接和配置
3. **最终方案**:
   - 生成新节点 ID: node_d97fd8ac1f570034
   - 更新所有配置文件
   - 重新发布所有资产
4. **验证方法**: 检查节点注册状态和资产发布状态

### 根本原因分析
- **直接原因**: 节点 ID 已被其他用户使用
- **根本原因**: EvoMap Hub 的节点 ID 分配机制
- **系统性因素**: 需要唯一的节点标识符

## 元数据
- **创建时间**: $(date)
- **解决时间**: 2026-02-22
- **复杂度**: 中
- **可复用性**: 高（类似配置问题）
- **相关技术**: EvoMap, 节点配置, API 集成
- **来源**: 历史配置记录

## 知识沉淀
### 最佳实践
1. 每次配置时生成新的唯一节点 ID
2. 及时更新所有相关配置文件
3. 验证节点状态后再进行资产发布

### 避免的陷阱
1. 不要重复使用可能已被占用的节点 ID
2. 确保网络连接正常
3. 定期检查节点状态

### 快速参考
```bash
# 检查节点状态
curl https://evomap.ai/api/nodes/{node_id}

# 更新配置
sed -i 's/old_node_id/new_node_id/g' config-file.json
```
EOF
    log_success "创建技术案例: EvoMap 配置"
    
    # Agent-Reach 安装案例
    cat > "$MEMORY_DIR/categories/cases/agent_reach_installation.md" << EOF
# [cases] Agent-Reach 安装和 Bilibili 通道问题

## L0: 摘要
Agent-Reach 安装成功，但 Bilibili 视频读取需要代理

## L1: 概述
- **问题描述**: Bilibili 视频读取失败，HTTP 412 错误
- **问题类型**: 网络限制/代理配置
- **解决状态**: 部分解决（搜索功能正常）
- **解决方案**: 使用 Exa 搜索作为回退，Bilibili 搜索功能正常
- **解决时间**: 2026-02-25
- **效果评估**: 中（视频读取仍需代理）

## L2: 详细内容
### 问题背景
安装 Agent-Reach 后，Bilibili 视频读取功能因服务器 IP 被 Bilibili 屏蔽而失败。

### 解决过程
1. **诊断步骤**: 
   - 测试 Bilibili 视频读取，返回 HTTP 412
   - 检查代理配置
   - 测试其他通道功能
2. **尝试方案**:
   - 配置代理服务器（不可用）
   - 直接 yt-dlp 访问（同样失败）
3. **最终方案**:
   - 使用 Exa 搜索作为 Bilibili 搜索的回退
   - Bilibili 搜索功能正常，可用于内容发现
   - 视频读取功能标记为需要代理
4. **验证方法**: 测试 Bilibili 搜索功能，验证结果准确性

### 根本原因分析
- **直接原因**: 服务器 IP 被 Bilibili 屏蔽
- **根本原因**: Bilibili 的反爬虫机制
- **系统性因素**: 需要有效的代理服务器

## 元数据
- **创建时间**: $(date)
- **解决时间**: 2026-02-25
- **复杂度**: 中
- **可复用性**: 高（类似平台限制问题）
- **相关技术**: Agent-Reach, Bilibili API, 代理配置, Exa 搜索
- **来源**: Agent-Reach 安装记录

## 知识沉淀
### 最佳实践
1. 多通道回退机制设计
2. 功能降级确保核心功能可用
3. 清晰的错误处理和用户反馈

### 避免的陷阱
1. 不要依赖单一数据源
2. 考虑平台限制和反爬虫机制
3. 设计优雅的降级方案

### 快速参考
```bash
# 测试 Bilibili 搜索
agent-reach search-bilibili "关键词"

# 检查通道状态
agent-reach status
```
EOF
    log_success "创建技术案例: Agent-Reach 安装"
}

# 4. 创建模式记忆
create_pattern_memories() {
    log_info "创建模式记忆..."
    
    # 内容创作模式
    cat > "$MEMORY_DIR/categories/patterns/content_creation_workflow.md" << EOF
# [patterns] 内容创作工作流模式

## L0: 摘要
内容 Agent 的标准化创作工作流程

## L1: 概述
- **模式类型**: 工作流程
- **适用场景**: AI/狗狗/NBA 内容创作
- **使用频率**: 高（每日执行）
- **效果评估**: 好（系统化产出）
- **可复用性**: 高

## L2: 详细内容
### 工作流步骤
1. **素材收集**
   - 搜索相关资讯和数据（串行搜索避免限制）
   - 从记忆库找相关经历
   - 拉取技术文档和开源项目信息

2. **按峰峰风格写初稿**
   - 角色定位：理性、冷静、长期主义的深度思考型博主
   - 核心目标：帮读者看到表象背后的结构
   - 写作原则：不制造焦虑，不贩卖成功学
   - 表达风格：多用短句，减少从句，控制形容词

3. **自动推飞书**
   - 使用飞书 API 创建文档
   - 解析 Markdown 转换为飞书块格式
   - 分批写入内容
   - 生成文档链接

### 质量控制
- 信息密度标准：每一段必须产生认知增量
- 去 AI 味控制：避免过度工整的分点
- 输出前自检：检查废话、逻辑跳跃、禁用词

## 元数据
- **创建时间**: $(date)
- **验证次数**: 多次成功执行
- **置信度**: 高
- **来源**: 内容 Agent 工作流文档
- **相关技能**: 内容创作，飞书 API，Markdown 处理

## 应用场景
1. 每日选题生成
2. 热点内容创作
3. 专题深度文章
4. 多平台内容分发

## 变体和优化
- 可根据热点类型调整搜索策略
- 可根据平台特点调整表达风格
- 可集成更多数据源和分析工具
EOF
    log_success "创建模式记忆: 内容创作工作流"
    
    # 记忆维护模式
    cat > "$MEMORY_DIR/categories/patterns/memory_maintenance_pattern.md" << EOF
# [patterns] 记忆维护和整理模式

## L0: 摘要
系统化的记忆维护和知识管理方法

## L1: 概述
- **模式类型**: 维护流程
- **适用场景**: 知识积累和系统维护
- **使用频率**: 每日/定期
- **效果评估**: 好（保持系统健康）
- **可复用性**: 高

## L2: 详细内容
### 维护周期
1. **每日维护**
   - 创建当日记忆文件
   - 处理昨日重要记忆
   - 更新长期记忆

2. **定期整理**
   - 每周生成摘要
   - 每月清理旧文件
   - 每季度知识复盘

3. **按需优化**
   - 系统升级时迁移记忆
   - 发现问题时创建案例
   - 识别模式时记录模式

### 工具和方法
- 自动化脚本处理重复任务
- 模板化记录确保一致性
- 分类存储便于检索
- 标签系统支持灵活搜索

## 元数据
- **创建时间**: $(date)
- **验证次数**: 长期运行验证
- **置信度**: 高
- **来源**: 记忆系统运行经验
- **相关技能**: Shell 脚本，文件管理，知识管理

## 最佳实践
1. 自动化尽可能多的步骤
2. 保持向后兼容性
3. 定期评估和改进
4. 文档化所有流程

## 扩展应用
1. 项目知识管理
2. 个人学习系统
3. 团队协作知识库
4. 技术债务管理
EOF
    log_success "创建模式记忆: 记忆维护模式"
}

# 主函数
main() {
    log_info "开始迁移历史记忆到分类系统"
    log_info "========================================"
    
    # 确保目录存在
    mkdir -p "$MEMORY_DIR/categories"/{profile,preferences,entities,events,cases,patterns}
    
    migrate_from_memory_md
    migrate_from_daily_memories
    create_technical_cases
    create_pattern_memories
    
    log_info "========================================"
    
    # 显示迁移结果
    echo -e "${GREEN}迁移完成统计:${NC}"
    for category in profile preferences entities events cases patterns; do
        count=$(find "$MEMORY_DIR/categories/$category" -name "*.md" 2>/dev/null | wc -l)
        echo "- $category: $count 个记忆"
    done
    
    total=$(find "$MEMORY_DIR/categories" -name "*.md" 2>/dev/null | wc -l)
    echo -e "\n${GREEN}总计:${NC} $total 个分类记忆"
    
    echo -e "\n${YELLOW}下一步建议:${NC}"
    echo "1. 运行增强版记忆维护: ./memory-maintenance-enhanced.sh"
    echo "2. 测试记忆搜索: ./memory-search.sh --summary"
    echo "3. 审核迁移的记忆，补充详细信息"
    echo "4. 开始使用新的分类系统记录新记忆"
}

# 执行主函数
main "$@"