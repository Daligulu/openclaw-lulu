#!/bin/bash
# 旧版记忆维护脚本（保持向后兼容）
# 新的增强版脚本在 memory-maintenance-enhanced.sh

WORKSPACE="/root/.openclaw/workspace"
TODAY=$(date +%Y-%m-%d)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)

echo "🧠 开始每日记忆整理（旧版兼容模式） - $(date)"

# 1. 检查并创建记忆目录
if [ ! -d "$WORKSPACE/memory" ]; then
    mkdir -p "$WORKSPACE/memory"
    echo "✅ 创建记忆目录"
fi

# 2. 创建今天的记忆文件（如果不存在）
if [ ! -f "$WORKSPACE/memory/$TODAY.md" ]; then
    echo "# $TODAY 记忆日志" > "$WORKSPACE/memory/$TODAY.md"
    echo "创建时间: $(date)" >> "$WORKSPACE/memory/$TODAY.md"
    echo "---" >> "$WORKSPACE/memory/$TODAY.md"
    echo "✅ 创建今日记忆文件"
fi

# 3. 检查昨天的记忆文件，提取重要内容到长期记忆
if [ -f "$WORKSPACE/memory/$YESTERDAY.md" ]; then
    echo "📅 检查昨日记忆文件: $YESTERDAY.md"
    
    # 提取重要内容
    IMPORTANT_CONTENT=$(grep -E "(重要|决策|教训|发现|TODO|FIXME)" "$WORKSPACE/memory/$YESTERDAY.md" | head -10)
    
    if [ ! -z "$IMPORTANT_CONTENT" ]; then
        echo "📝 发现重要内容，更新长期记忆..."
        echo "" >> "$WORKSPACE/MEMORY.md"
        echo "## $YESTERDAY 重要记忆" >> "$WORKSPACE/MEMORY.md"
        echo "$IMPORTANT_CONTENT" >> "$WORKSPACE/MEMORY.md"
        echo "---" >> "$WORKSPACE/MEMORY.md"
    fi
fi

# 4. 清理旧记忆文件（保留最近30天）
find "$WORKSPACE/memory" -name "*.md" -mtime +30 -delete
echo "🧹 清理30天前的旧记忆文件"

# 5. 检查记忆文件大小
MEMORY_SIZE=$(du -sh "$WORKSPACE/memory" 2>/dev/null | cut -f1 || echo "0")
MEMORY_COUNT=$(find "$WORKSPACE/memory" -name "*.md" 2>/dev/null | wc -l)
echo "📊 记忆统计: $MEMORY_COUNT 个文件，总大小 $MEMORY_SIZE"

echo "✅ 记忆整理完成 - $(date)"
echo ""
echo "💡 提示：新的增强版记忆系统已可用"
echo "     运行: ./memory-maintenance-enhanced.sh"
echo "     搜索: ./memory-search.sh"