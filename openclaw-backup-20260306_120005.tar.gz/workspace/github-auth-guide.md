# GitHub认证配置指南

## 认证重要性
GitHub CLI (`gh`) 需要认证才能访问完整的API功能，包括：
- 私有仓库访问
- 搜索功能
- Actions API
- 仓库管理操作
- 更高的API限制

## 认证方式

### 方式1：交互式登录（推荐）
```bash
# 启动交互式登录流程
gh auth login

# 选择GitHub.com
# 选择HTTPS或SSH协议
# 选择认证方式（浏览器或token）
```

### 方式2：使用Personal Access Token (PAT)
```bash
# 1. 在GitHub创建PAT
#   访问：https://github.com/settings/tokens
#   权限建议：repo, read:org, workflow

# 2. 使用token登录
echo "你的_PAT_令牌" | gh auth login --with-token

# 或从文件读取
gh auth login --with-token < token.txt
```

### 方式3：环境变量
```bash
# 设置环境变量
export GH_TOKEN="你的_PAT_令牌"

# 验证认证
gh auth status
```

## 认证步骤详解

### 步骤1：创建Personal Access Token
1. 访问 https://github.com/settings/tokens
2. 点击 "Generate new token (classic)"
3. 设置token名称：`OpenClaw-GitHub-CLI`
4. 选择权限：
   - ✅ `repo` (完全控制仓库)
   - ✅ `read:org` (读取组织信息)
   - ✅ `workflow` (GitHub Actions)
   - ✅ `read:user` (读取用户信息)
5. 点击 "Generate token"
6. **立即复制token**（只显示一次）

### 步骤2：配置gh CLI
```bash
# 使用token登录
gh auth login --with-token
# 粘贴刚才复制的token
# 按Ctrl+D结束输入

# 验证配置
gh auth status

# 测试功能
gh repo view openclaw/openclaw --json name
```

### 步骤3：持久化配置
```bash
# 查看当前配置
gh config list

# 设置默认配置
gh config set editor vim
gh config set git_protocol ssh
gh config set prompt enabled

# 保存到文件
gh auth status --show-token > ~/.github-token-backup.txt
```

## 认证验证

### 基本验证
```bash
# 检查认证状态
gh auth status

# 输出示例：
# ✓ Logged in to github.com as username (oauth2)
# ✓ Git operations for github.com configured to use ssh protocol.
# ✓ Token: *******************
```

### 功能测试
```bash
# 测试私有仓库访问
gh repo view owner/private-repo --json name 2>/dev/null && echo "✅ 私有仓库访问正常"

# 测试搜索功能
gh search repos "topic:ai" --limit 1 --json name 2>/dev/null && echo "✅ 搜索功能正常"

# 测试API访问
gh api user --jq '.login' 2>/dev/null && echo "✅ API访问正常"
```

## 多账户管理

### 添加多个账户
```bash
# 添加企业GitHub账户
gh auth login --hostname github.company.com

# 切换账户
gh auth status --hostname github.com
gh auth status --hostname github.company.com
```

### 账户切换
```bash
# 查看所有认证的主机
gh auth status --show-all

# 使用特定主机的token
export GH_HOST=github.company.com
export GH_TOKEN=企业token

# 或使用配置文件
echo "github.com:
  oauth_token: 个人token
github.company.com:
  oauth_token: 企业token" > ~/.config/gh/hosts.yml
```

## 安全最佳实践

### 1. Token管理
```bash
# 定期轮换token（每90天）
# 1. 创建新token
# 2. 更新gh配置
gh auth logout
gh auth login --with-token < new-token.txt

# 3. 删除旧token
```

### 2. 最小权限原则
- 只授予必要的权限
- 避免使用`delete_repo`等危险权限
- 定期审查token权限

### 3. 安全存储
```bash
# 加密存储token
gpg --encrypt --recipient your-email token.txt

# 环境变量保护
echo "export GH_TOKEN=\"你的token\"" >> ~/.bashrc
chmod 600 ~/.bashrc
```

### 4. 监控和审计
```bash
# 查看token使用记录
gh api /settings/tokens --jq '.[] | "\(.name): last used \(.last_used_at)"'

# 检查可疑活动
gh api /users/username/events --jq '.[0:5] | .[] | "\(.created_at): \(.type) on \(.repo.name)"'
```

## 故障排除

### 常见问题

#### 1. 认证失败
```bash
# 错误：Bad credentials
# 解决：重新登录或更新token
gh auth logout
gh auth login
```

#### 2. 权限不足
```bash
# 错误：Resource not accessible by integration
# 解决：检查token权限，可能需要admin权限
```

#### 3. API限制
```bash
# 错误：API rate limit exceeded
# 解决：等待或使用认证token提高限制
gh api rate_limit --jq '.resources.core'
```

#### 4. 网络问题
```bash
# 错误：Could not resolve host
# 解决：检查网络或使用代理
export HTTPS_PROXY=http://proxy:port
export HTTP_PROXY=http://proxy:port
```

### 调试命令
```bash
# 详细错误信息
gh auth status --verbose

# 调试模式
export GH_DEBUG=1
gh repo view owner/repo

# 查看原始API响应
gh api /user --header "Accept: application/vnd.github.v3+json" --verbose
```

## 自动化配置脚本

### 一键配置脚本
```bash
#!/bin/bash
# github-auth-setup.sh

set -e

echo "🔐 GitHub认证配置脚本"
echo "======================"

# 检查是否已认证
if gh auth status &> /dev/null; then
    echo "✅ GitHub已认证"
    gh auth status
    exit 0
fi

echo "请选择认证方式:"
echo "1. 交互式登录（推荐）"
echo "2. 使用现有token"
read -p "选择 (1/2): " choice

case $choice in
    1)
        echo "启动交互式登录..."
        gh auth login
        ;;
    2)
        read -sp "请输入GitHub Personal Access Token: " token
        echo
        echo "$token" | gh auth login --with-token
        ;;
    *)
        echo "无效选择"
        exit 1
        ;;
esac

# 验证配置
if gh auth status &> /dev/null; then
    echo "✅ GitHub认证配置成功！"
    
    # 测试功能
    echo "测试基本功能..."
    if gh api /user --jq '.login' &> /dev/null; then
        echo "✅ API访问正常"
    fi
else
    echo "❌ 认证配置失败"
    exit 1
fi
```

### 环境检查脚本
```bash
#!/bin/bash
# github-env-check.sh

echo "🔧 GitHub环境检查"
echo "================="

# 检查gh CLI
if command -v gh &> /dev/null; then
    echo "✅ gh CLI已安装: $(gh --version | head -1)"
else
    echo "❌ gh CLI未安装"
    echo "   安装: https://github.com/cli/cli#installation"
    exit 1
fi

# 检查认证
if gh auth status &> /dev/null; then
    echo "✅ GitHub已认证"
    gh auth status | head -2
else
    echo "⚠️  GitHub未认证"
    echo "   运行: gh auth login"
fi

# 检查jq（JSON处理）
if command -v jq &> /dev/null; then
    echo "✅ jq已安装: $(jq --version)"
else
    echo "⚠️  jq未安装（建议安装以便处理JSON输出）"
    echo "   安装: sudo apt-get install jq 或 brew install jq"
fi

# 检查API限制
if gh auth status &> /dev/null; then
    echo "📊 API限制状态:"
    gh api /rate_limit --jq '.resources.core | "  剩余: \(.remaining)/\(.limit) 重置: \(.reset)"'
fi

echo ""
echo "💡 建议:"
echo "  1. 确保token有足够权限"
echo "  2. 定期轮换token（每90天）"
echo "  3. 使用jq处理JSON输出"
echo "  4. 监控API使用情况"
```

## 集成到工作流

### 1. CI/CD集成
```yaml
# GitHub Actions示例
name: CI
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm test
      - name: Upload coverage
        run: |
          gh api repos/${{ github.repository }}/code-scanning/alerts \
            -X POST \
            -f tool_name="test-coverage" \
            -f results="@coverage.json"
```

### 2. 本地开发集成
```bash
#!/bin/bash
# pre-commit-check.sh

# 检查关联的issue
current_branch=$(git branch --show-current)
if [[ $current_branch =~ ^issue-[0-9]+ ]]; then
    issue_num=${current_branch#issue-}
    
    # 检查issue状态
    issue_state=$(gh issue view $issue_num --json state --jq '.state')
    
    if [ "$issue_state" != "open" ]; then
        echo "❌ 关联的issue #$issue_num 已关闭"
        echo "   请更新分支名称或重新打开issue"
        exit 1
    fi
fi
```

### 3. 监控集成
```bash
#!/bin/bash
# daily-github-report.sh

# 生成每日GitHub活动报告
REPORT_FILE="github-report-$(date +%Y-%m-%d).md"

echo "# GitHub活动报告 - $(date)" > "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

# 仓库状态
echo "## 仓库状态" >> "$REPORT_FILE"
gh repo list --limit 5 --json name,updatedAt,pushedAt >> "$REPORT_FILE"

# PR状态
echo "## PR状态" >> "$REPORT_FILE"
gh pr list --state open --limit 5 --json number,title,createdAt >> "$REPORT_FILE"

# CI状态
echo "## CI状态" >> "$REPORT_FILE"
gh run list --limit 3 --json conclusion,workflowName,createdAt >> "$REPORT_FILE"
```

## 总结

### 认证状态检查表
- [ ] gh CLI已安装
- [ ] 有效的GitHub认证
- [ ] 足够的API权限
- [ ] 正确的环境配置
- [ ] 安全存储的token

### 下一步行动
1. **立即配置**: 运行 `gh auth login`
2. **权限验证**: 测试关键功能
3. **安全加固**: 实施最佳实践
4. **集成开发**: 将认证集成到工作流

### 资源链接
- [GitHub CLI官方文档](https://cli.github.com/manual)
- [Personal Access Token管理](https://github.com/settings/tokens)
- [GitHub API文档](https://docs.github.com/en/rest)
- [OAuth应用指南](https://docs.github.com/en/apps/oauth-apps)

通过正确配置GitHub认证，你将能够充分利用`gh` CLI的所有功能，提高开发效率和工作流自动化水平。